import type { Digits } from '@/core/format';
import type { DisplayPrefs } from '@/core/display';

export interface Prefs extends DisplayPrefs { digits: Digits; theme: 'auto' | 'light' | 'dark' }
export const DEFAULT_PREFS: Prefs = { currency: 'IRT', goldUnit: 'gram', digits: 'fa', theme: 'auto' };
export const PREFS_COOKIE = 'bz_prefs';

export function parsePrefs(raw: string | undefined): Prefs {
  if (!raw) return DEFAULT_PREFS;
  try {
    const p = JSON.parse(decodeURIComponent(raw)) as Partial<Prefs>;
    return {
      currency: p.currency === 'IRR' ? 'IRR' : 'IRT',
      goldUnit: p.goldUnit === 'mesghal' || p.goldUnit === 'kilogram' ? p.goldUnit : 'gram',
      digits: p.digits === 'en' ? 'en' : 'fa',
      theme: p.theme === 'light' || p.theme === 'dark' ? p.theme : 'auto',
    };
  } catch { return DEFAULT_PREFS; }
}
export const serializePrefs = (p: Prefs): string => encodeURIComponent(JSON.stringify(p));
