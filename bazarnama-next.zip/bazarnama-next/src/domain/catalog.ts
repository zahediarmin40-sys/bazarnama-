import type { Asset } from '../core/types.ts';

/** Static catalog: names, units, specs. It contains NO prices. Demo seeds live in server/providers/demo.ts. */
const gold: Asset[] = [
  ...([[24, '۲۴ عیار'], [22, '۲۲ عیار'], [21, '۲۱ عیار'], [18, '۱۸ عیار'], [17, '۱۷ عیار'], [14, '۱۴ عیار']] as const).map(([k, l]) => ({
    id: `gold-${k}`, category: 'gold' as const, group: 'gold' as const, name: `طلای ${l}`, tag: `${k}K`, purity: k, unit: 'gram' as const, currency: 'IRT' as const, marketType: 'free-local' as const,
    aliases: ['طلا', 'gold', `طلا${k}`, `${k}عیار`, `${k}k`, 'گرم طلا'],
  })),
  { id: 'gold-melt', category: 'gold', group: 'gold', name: 'طلای آب‌شده', tag: 'آبشده', purity: 18, unit: 'gram', currency: 'IRT', marketType: 'free-local', aliases: ['آبشده', 'طلای آب شده', 'مظنه آبشده', 'melted gold'] },
];

const coinDefs: ReadonlyArray<[string, string, number, readonly string[]]> = [
  ['emami', 'سکه امامی (طرح جدید)', 8.133, ['تمام سکه', 'امامی', 'emami', 'سکه']],
  ['old', 'تمام سکه (طرح قدیم)', 8.133, ['تمام سکه', 'طرح قدیم', 'سکه']],
  ['half', 'نیم سکه', 4.0665, ['نیم', 'نیمسکه', 'سکه']],
  ['quarter', 'ربع سکه', 2.03325, ['ربع', 'ربعسکه', 'سکه']],
  ['gram', 'سکه گرمی', 1, ['گرمی', 'سکه']],
];
const coins: Asset[] = coinDefs.map(([k, name, w, aliases]) => ({
  id: `coin-${k}`, category: 'coin', group: 'coin', name, unit: 'piece', currency: 'IRT', marketType: 'free-local', aliases,
  spec: { weightG: w, purity: 900, fineG: (w * 900) / 1000 },
}));

const BASE_FX: ReadonlyArray<[string, string, readonly string[]]> = [
  ['USD', 'دلار آمریکا', ['dollar', 'دلار', 'usd', '$']], ['USDT', 'تتر (USDT)', ['tether', 'تتر', 'usdt']], ['EUR', 'یورو', ['euro', 'یورو']], ['GBP', 'پوند انگلیس', ['pound', 'پوند', 'gbp']],
  ['AED', 'درهم امارات', ['dirham', 'درهم', 'aed']], ['TRY', 'لیر ترکیه', ['lira', 'لیر', 'try']], ['CAD', 'دلار کانادا', ['cad']],
  ['AUD', 'دلار استرالیا', ['aud']], ['CHF', 'فرانک سوئیس', ['franc', 'فرانک', 'chf']], ['JPY', 'ین ژاپن', ['yen', 'ین', 'jpy']], ['CNY', 'یوان چین', ['yuan', 'یوان', 'cny']],
];
/** Every currency NerkhAra publishes (docs: https://nerkhara.com/en/api/, 44 fiat + USDT). Prices are per ONE unit of the currency. */
const MORE_FX: ReadonlyArray<[string, string, readonly string[]]> = [
  ['QAR', 'ریال قطر', ['qatar', 'قطر']], ['SAR', 'ریال عربستان', ['saudi', 'عربستان', 'ریال سعودی']], ['KWD', 'دینار کویت', ['kuwait', 'کویت']],
  ['OMR', 'ریال عمان', ['oman', 'عمان']], ['BHD', 'دینار بحرین', ['bahrain', 'بحرین']], ['IQD', 'دینار عراق', ['iraq', 'عراق']],
  ['LBP', 'لیره لبنان', ['lebanon', 'لبنان', 'لیر لبنان']], ['SYP', 'لیره سوریه', ['syria', 'سوریه', 'لیر سوریه']], ['AFN', 'افغانی افغانستان', ['afghani', 'افغانی', 'افغانستان']],
  ['DKK', 'کرون دانمارک', ['denmark', 'کرون', 'دانمارک']], ['SEK', 'کرون سوئد', ['sweden', 'کرون', 'سوئد']], ['NOK', 'کرون نروژ', ['norway', 'کرون', 'نروژ']],
  ['NZD', 'دلار نیوزیلند', ['nzd', 'نیوزیلند', 'zealand']], ['RUB', 'روبل روسیه', ['rouble', 'ruble', 'روبل', 'روسیه']], ['INR', 'روپیه هند', ['rupee', 'روپیه', 'هند']],
  ['PKR', 'روپیه پاکستان', ['rupee', 'روپیه', 'پاکستان']], ['MYR', 'رینگیت مالزی', ['ringgit', 'رینگیت', 'مالزی']], ['SGD', 'دلار سنگاپور', ['sgd', 'سنگاپور']],
  ['HKD', 'دلار هنگ‌کنگ', ['hkd', 'هنگ کنگ', 'هنگکنگ']], ['THB', 'بات تایلند', ['baht', 'بات', 'تایلند']], ['IDR', 'روپیه اندونزی', ['rupiah', 'روپیه', 'اندونزی']],
  ['KRW', 'وون کره جنوبی', ['won', 'وون', 'کره']], ['AZN', 'منات آذربایجان', ['manat', 'منات', 'آذربایجان']], ['AMD', 'درام ارمنستان', ['dram', 'درام', 'ارمنستان']],
  ['GEL', 'لاری گرجستان', ['lari', 'لاری', 'گرجستان']], ['KGS', 'سوم قرقیزستان', ['som', 'سوم', 'قرقیزستان']], ['UZS', 'سوم ازبکستان', ['som', 'سوم', 'ازبکستان']],
  ['TJS', 'سامانی تاجیکستان', ['somoni', 'سامانی', 'تاجیکستان']], ['TMT', 'منات ترکمنستان', ['manat', 'منات', 'ترکمنستان']], ['KZT', 'تنگه قزاقستان', ['tenge', 'تنگه', 'قزاقستان']],
  ['BRL', 'ریال برزیل', ['real', 'برزیل']], ['MXN', 'پزو مکزیک', ['peso', 'پزو', 'مکزیک']], ['ZAR', 'رند آفریقای جنوبی', ['rand', 'رند', 'آفریقا']], ['UAH', 'گریونا اوکراین', ['hryvnia', 'گریونا', 'اوکراین']],
];
export const FX_CURRENCIES: ReadonlyArray<[string, string, readonly string[]]> = [...BASE_FX, ...MORE_FX];
/** Currencies that also have a separate exchange-centre line (the original set; extra currencies are free-market only). */
const EXCHANGE_CODES = new Set(['USD', 'EUR', 'GBP', 'AED', 'TRY', 'CAD', 'AUD', 'CHF', 'JPY', 'CNY']);
const fx: Asset[] = FX_CURRENCIES.flatMap(([code, name, aliases]) => {
  const l = code.toLowerCase();
  const out: Asset[] = [{ id: `fx-${l}-free`, category: 'fx', group: code === 'USD' ? 'usd-free' : 'fx-free', name, code, fxName: name, unit: 'fx', currency: 'IRT', marketType: 'free', aliases } as Asset];
  if (EXCHANGE_CODES.has(code)) out.push({ id: `fx-${l}-ex`, category: 'fx', group: 'fx-exchange', name, code, fxName: name, unit: 'fx', currency: 'IRT', marketType: 'exchange', aliases } as Asset);
  return out;
});
/** USD cash at bank exchange houses (NerkhAra id usd-bank-cash). */
fx.push({ id: 'fx-usd-cash', category: 'fx', group: 'fx-exchange', name: 'دلار نقدی (صرافی بانکی)', code: 'USD', fxName: 'دلار آمریکا', unit: 'fx', currency: 'IRT', marketType: 'cash', aliases: ['دلار نقدی', 'صرافی', 'cash'] } as Asset);

const world: Asset[] = [{
  id: 'gold-ounce', category: 'world', group: 'world-metals', name: 'اونس جهانی طلا', unit: 'ounce', currency: 'USD', marketType: 'world', aliases: ['gold ounce', 'xau', 'اونس طلا', 'اونس'],
}];

export const ASSETS: readonly Asset[] = [...gold, ...coins, ...fx, ...world];
const index = new Map(ASSETS.map((a) => [a.id, a]));
export const getAsset = (id: string): Asset | undefined => index.get(id);
export const mustAsset = (id: string): Asset => { const a = index.get(id); if (!a) throw new Error(`unknown asset ${id}`); return a; };

export const GOLD_IDS = gold.map((a) => a.id);
export const COIN_IDS = coins.map((a) => a.id);
export const METAL_IDS = world.map((a) => a.id);
export const fxIds = (type: 'free' | 'exchange'): string[] => type === 'free'
  ? FX_CURRENCIES.map(([c]) => `fx-${c.toLowerCase()}-free`)
  : [...FX_CURRENCIES.filter(([c]) => EXCHANGE_CODES.has(c)).map(([c]) => `fx-${c.toLowerCase()}-ex`), 'fx-usd-cash'];
export const SNAPSHOT_IDS = ['gold-18', 'coin-emami', 'fx-usd-free', 'fx-eur-free', 'fx-usdt-free'];
