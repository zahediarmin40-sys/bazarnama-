export interface NavItem { href: string; label: string }

/** Navigation is intentionally limited to the product's core: gold, coins and currencies. */
export const NAV: readonly NavItem[] = [
  { href: '/', label: 'خانه' },
  { href: '/gold', label: 'قیمت طلا' },
  { href: '/coins', label: 'قیمت سکه' },
  { href: '/currency', label: 'قیمت ارز' },
  { href: '/all', label: 'جدول قیمت‌ها' },
  { href: '/charts', label: 'نمودارها' },
  { href: '/tools', label: 'محاسبه‌گر' },
  { href: '/news', label: 'اخبار اقتصادی' },
  { href: '/about', label: 'درباره ما' },
];

export interface Phase2Section { title: string; columns: string[]; filters: string[]; note?: string }
/** No unrelated market categories are exposed in this product. */
export const PHASE2: Record<string, Phase2Section> = {};

export const MARKET_LABEL: Record<string, string> = { 'free-local': 'بازار آزاد (ایران)', free: 'بازار آزاد', exchange: 'مرکز مبادله', official: 'رسمی', transfer: 'حواله', cash: 'نقدی', world: 'قیمت بین‌المللی', calculated: 'محاسبه‌شده' };
export const UNIT_LABEL: Record<string, string> = { gram: 'گرم', mesghal: 'مثقال', kilogram: 'کیلوگرم', ounce: 'اونس', piece: 'عدد' };
export const CURRENCY_LABEL: Record<string, string> = { IRT: 'تومان', IRR: 'ریال', USD: 'دلار' };
export const STATUS_LABEL: Record<string, string> = { live: 'زنده', delayed: 'با تأخیر', stale: 'قدیمی (بدون بروزرسانی)', indicative: 'تقریبی', unavailable: 'در انتظار داده' };

export const METHOD_LABEL: Record<string, string> = { average: 'میانگین چند منبع', lead: 'منبع اصلی', derived: 'محاسبه‌شده از دلار و نرخ جهانی', 'volume-weighted': 'میانگین وزنی بر حجم', published: 'انتشار روزانه توسط نهاد منبع' };
