export interface NavItem { href: string; label: string }
export const NAV: readonly NavItem[] = [
  { href: '/', label: 'نمای کلی' }, { href: '/gold', label: 'طلا و سکه' }, { href: '/currency', label: 'ارز' },
  { href: '/vehicles', label: 'خودرو' }, { href: '/mobile', label: 'موبایل و فناوری' }, { href: '/housing', label: 'مسکن' },
  { href: '/iron', label: 'آهن و مصالح' }, { href: '/global', label: 'بازارهای جهانی' }, { href: '/agri', label: 'کشاورزی و کالاها' },
  { href: '/news', label: 'اخبار' }, { href: '/tools', label: 'ابزارها' }, { href: '/data', label: 'درباره داده‌ها' },
];

export interface Phase2Section { title: string; columns: string[]; filters: string[]; note?: string }
export const PHASE2: Record<string, Phase2Section> = {
  vehicles: { title: 'خودرو', columns: ['مدل / تیپ', 'قیمت اعلامی', 'نوع قیمت (کارخانه یا بازار)', 'تغییر', 'تاریخ بروزرسانی'], filters: ['داخلی یا وارداتی', 'برند و مدل', 'سال ساخت'], note: 'قیمت کارخانه و برآورد بازار جدا نمایش داده می‌شود.' },
  mobile: { title: 'موبایل و فناوری', columns: ['برند و مدل', 'حافظه / نسخه', 'بازه قیمت', 'فروشنده یا منبع', 'تاریخ بروزرسانی'], filters: ['برند', 'حافظه', 'نسخه'], note: 'نسخه‌های مختلف یک مدل در یک قیمت ادغام نمی‌شوند.' },
  housing: { title: 'مسکن', columns: ['منطقه', 'نوع ملک', 'مبنای قیمت (هر متر مربع)', 'قیمت', 'تاریخ'], filters: ['شهر و منطقه', 'نوع ملک', 'متراژ'], note: 'قیمت پیشنهادی آگهی‌ها معادل قیمت معامله‌ی انجام‌شده نیست.' },
  iron: { title: 'آهن و مصالح ساختمانی', columns: ['محصول', 'مشخصات / گرید', 'محل', 'واحد', 'ارز', 'منبع', 'تاریخ'], filters: ['محصول', 'گرید', 'محل', 'واحد'] },
  agri: { title: 'کشاورزی و کالاها', columns: ['محصول', 'گرید', 'محل', 'واحد', 'ارز', 'منبع', 'تاریخ'], filters: ['محصول', 'گرید', 'محل', 'واحد'] },
};

export const GLOBAL_SECTIONS: ReadonlyArray<{ title: string; items: string[] | null }> = [
  { title: 'ارزهای جهانی', items: ['EUR/USD', 'GBP/USD', 'USD/JPY'] }, { title: 'رمزارزها', items: ['بیت‌کوین', 'اتریوم'] },
  { title: 'شاخص‌های بورس', items: ['S&P 500', 'داو جونز', 'داکس'] }, { title: 'انرژی', items: ['نفت برنت', 'نفت خام WTI', 'گاز طبیعی'] },
  { title: 'فلزات گرانبها و پایه', items: null }, { title: 'محصولات کشاورزی', items: ['گندم', 'ذرت', 'سویا'] },
];

export const MARKET_LABEL: Record<string, string> = { 'free-local': 'بازار آزاد (ایران)', free: 'بازار آزاد', exchange: 'مرکز مبادله', official: 'رسمی', transfer: 'حواله', cash: 'نقدی', world: 'قیمت بین‌المللی', calculated: 'محاسبه‌شده' };
export const UNIT_LABEL: Record<string, string> = { gram: 'گرم', mesghal: 'مثقال', kilogram: 'کیلوگرم', ounce: 'اونس', piece: 'عدد' };
export const CURRENCY_LABEL: Record<string, string> = { IRT: 'تومان', IRR: 'ریال', USD: 'دلار' };
export const STATUS_LABEL: Record<string, string> = { live: 'زنده', delayed: 'با تأخیر', stale: 'قدیمی (بدون بروزرسانی)', indicative: 'تقریبی', unavailable: 'ناموجود' };

export const METHOD_LABEL: Record<string, string> = { average: 'میانگین چند منبع', lead: 'منبع اصلی', derived: 'محاسبه‌شده از دلار و نرخ جهانی', 'volume-weighted': 'میانگین وزنی بر حجم', published: 'انتشار روزانه توسط نهاد منبع' };
