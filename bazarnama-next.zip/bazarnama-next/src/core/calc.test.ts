import test from 'node:test';
import assert from 'node:assert/strict';
import { purityOf, finenessOf, pureGoldGrams, equivalentWeight, scaleKaratPrice, goldQuote } from './calc.ts';

const near = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-6, `${a} != ${b}`);

test('karat purity and fineness', () => {
  assert.equal(purityOf(24), 1);
  assert.equal(purityOf(18), 0.75);
  assert.equal(finenessOf(18), 750);
  assert.equal(finenessOf(22), 917);
  assert.throws(() => purityOf(0));
  assert.throws(() => purityOf(25));
});
test('pure gold content and karat equivalence', () => {
  near(pureGoldGrams(10, 18), 7.5);
  near(equivalentWeight(10, 18, 24), 7.5);
  near(equivalentWeight(7.5, 24, 18), 10);
  near(equivalentWeight(10, 18, 21), 8.571428571);
});
test('karat price scaling', () => {
  near(scaleKaratPrice(4_000_000, 24, 18), 3_000_000);
  near(scaleKaratPrice(3_000_000, 18, 24), 4_000_000);
});
test('worked gold quote', () => {
  const q = goldQuote(10, 1_000_000, { wage: { type: 'percent', value: 10 }, profitPct: 7, taxPct: 10 });
  near(q.raw, 10_000_000);
  near(q.wage, 1_000_000);
  near(q.profit, 770_000);
  near(q.tax, 177_000);
  near(q.total, 11_947_000);
  near(goldQuote(2, 1_000_000, { wage: { type: 'perGram', value: 50_000 } }).total, 2_100_000);
  near(goldQuote(3, 500).total, 1500);
});
