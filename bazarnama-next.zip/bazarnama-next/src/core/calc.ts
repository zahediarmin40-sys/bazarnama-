import { massFactor, type MassUnit } from './units.ts';

export const goldValue = (weight: number, unit: MassUnit, pricePerGram: number): number => weight * massFactor(unit) * pricePerGram;

/** Converts via Toman. Result is a CALCULATED value and must be labelled as such in the UI. */
export function convertViaToman(amount: number, fromTomanPerUnit: number, toTomanPerUnit: number): number {
  if (!(fromTomanPerUnit > 0) || !(toTomanPerUnit > 0)) throw new Error('invalid rate');
  return (amount * fromTomanPerUnit) / toTomanPerUnit;
}

/** Gold purity as a fraction of pure gold: karat / 24 (18K = 0.75). */
export const KARAT_MAX = 24;
export const purityOf = (karat: number): number => {
  if (!(karat > 0) || karat > KARAT_MAX) throw new Error('invalid karat');
  return karat / KARAT_MAX;
};
/** Fineness in parts per thousand (18K -> 750). */
export const finenessOf = (karat: number): number => Math.round(purityOf(karat) * 1000);

/** Grams of pure (24K) gold contained in `grams` of `karat` gold. */
export const pureGoldGrams = (grams: number, karat: number): number => grams * purityOf(karat);

/** How many grams of `toKarat` gold hold the same pure gold as `grams` of `fromKarat` gold. */
export const equivalentWeight = (grams: number, fromKarat: number, toKarat: number): number =>
  (grams * purityOf(fromKarat)) / purityOf(toKarat);

/** Price per gram of another karat, scaled linearly from a known karat price. CALCULATED: label it in the UI. */
export const scaleKaratPrice = (knownPricePerGram: number, knownKarat: number, targetKarat: number): number =>
  (knownPricePerGram * purityOf(targetKarat)) / purityOf(knownKarat);

export type WageSpec = { type: 'percent' | 'perGram'; value: number };
export interface GoldQuote { raw: number; wage: number; profit: number; tax: number; total: number }

/**
 * Retail price of worked gold. Wage is a percent of the raw value or an amount per gram;
 * profit applies to raw + wage; tax applies to wage + profit only (not to the gold itself).
 * Every rate is an explicit input: nothing is assumed here.
 */
export function goldQuote(grams: number, pricePerGram: number, o: { wage?: WageSpec; profitPct?: number; taxPct?: number } = {}): GoldQuote {
  const raw = grams * pricePerGram;
  const wage = !o.wage ? 0 : o.wage.type === 'percent' ? (raw * o.wage.value) / 100 : grams * o.wage.value;
  const profit = ((raw + wage) * (o.profitPct ?? 0)) / 100;
  const tax = ((wage + profit) * (o.taxPct ?? 0)) / 100;
  return { raw, wage, profit, tax, total: raw + wage + profit + tax };
}
