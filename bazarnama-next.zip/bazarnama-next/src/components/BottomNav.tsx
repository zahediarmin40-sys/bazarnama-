'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const ITEMS: ReadonlyArray<[string, string, string]> = [
  ['/', 'خانه', 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z'],
  ['/gold', 'طلا', 'M4 18l3-9h10l3 9zM9 9l1-4h4l1 4'],
  ['/coins', 'سکه', 'M12 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm0 4v8m-3-5h6'],
  ['/currency', 'دلار', 'M4 8h13l-3-3M20 16H7l3 3'],
  ['/calculator', 'ماشین‌حساب', 'M6 3h12v18H6zM8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01'],
  ['/all', 'قیمت‌ها', 'M4 6h16M4 12h16M4 18h16'],
];
export function BottomNav() {
  const p = usePathname();
  const route = p.startsWith('/asset/') ? (p.includes('coin-') ? '/coins' : p.includes('fx-') ? '/currency' : '/gold') : p;
  const current = ITEMS.some(([href]) => href === route) ? route : '/all';
  return <nav className="bn" aria-label="ناوبری سریع">{ITEMS.map(([h, t, d]) => (
    <Link key={h} href={h} aria-current={h === current ? 'page' : undefined}>
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d} /></svg>{t}
    </Link>
  ))}</nav>;
}
