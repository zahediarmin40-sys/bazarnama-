'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import type { HistoryPoint } from '@/core/store';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { decimals, Percent, unitText } from './view-helpers';

function MiniTrend({ points, down }: { points: readonly HistoryPoint[]; down: boolean }) {
  if (points.length < 2) return null;
  const values = points.map((point) => point.p);
  const min = Math.min(...values);
  const range = Math.max(...values) - min || 1;
  const path = values.map((value, index) => `${index ? 'L' : 'M'}${(4 + (112 * index) / Math.max(1, values.length - 1)).toFixed(1)} ${(30 - (24 * (value - min)) / range).toFixed(1)}`).join(' ');
  return <svg className={`trendline ${down ? 'is-down' : 'is-up'}`} viewBox="0 0 120 34" aria-hidden="true"><path d={path} /></svg>;
}

export function Snapshot({ ids, initial }: { ids: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const [trends, setTrends] = useState<Record<string, readonly HistoryPoint[]>>({});
  const key = ids.join(',');
  useEffect(() => {
    let stopped = false;
    const load = async () => {
      const entries = await Promise.all(ids.map(async (id) => {
        try {
          const response = await fetch(`/api/history/${id}`, { cache: 'no-store' });
          if (!response.ok) return [id, []] as const;
          const payload = await response.json() as { points?: HistoryPoint[] };
          return [id, Array.isArray(payload.points) ? payload.points : []] as const;
        } catch { return [id, []] as const; }
      }));
      if (!stopped) setTrends(Object.fromEntries(entries));
    };
    void load();
    const timer = setInterval(load, 60_000);
    return () => { stopped = true; clearInterval(timer); };
    // ids are represented by a stable comma-separated key.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const { records, intervalSec, now } = useLivePrices(ids, initial);
  const d = prefs.digits;
  return (
    <div className="snap">
      {ids.map((id) => {
        const r = toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec);
        const badge = r.asset.category === 'coin' ? 'سکه' : r.asset.category === 'fx' ? (r.asset.code ?? 'ارز') : id === 'gold-ounce' ? 'XAU' : r.asset.tag ?? 'Au';
        return (
          <Link key={id} href={`/asset/${id}`}>
            <div className="snap-name"><div className="n">{r.asset.name}</div><span className="snap-icon">{badge}</span></div>
            <div className="p" style={r.status === 'stale' ? { opacity: 0.6 } : undefined}>{r.record ? <Num>{fmt(r.price, { digits: d, ...decimals(r) })}</Num> : '—'}</div>
            <div className="u">{r.record ? unitText(r, d) : '—'}</div>
            <div className="c"><Percent value={r.changePercent} digits={d} /> <StatusPill status={r.status} /></div>
            <MiniTrend points={trends[id] ?? []} down={(r.changePercent ?? 0) < 0} />
          </Link>
        );
      })}
    </div>
  );
}
