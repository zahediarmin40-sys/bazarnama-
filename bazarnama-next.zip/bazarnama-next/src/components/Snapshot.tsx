'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { HistoryPoint } from '@/core/store';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { AssetIcon } from './AssetIcon';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { Sparkline } from './Sparkline';
import { StatusPill } from './StatusPill';
import { decimals, Percent, unitText } from './view-helpers';

export function Snapshot({ ids, initial, history = {} }: { ids: readonly string[]; initial: PricesPayload; history?: Record<string, HistoryPoint[]> }) {
  const { prefs } = usePrefs();
  const { records, intervalSec, now } = useLivePrices(ids, initial);
  const [series, setSeries] = useState<Record<string, HistoryPoint[]>>(history);
  const d = prefs.digits;
  // Append each genuinely new tick to the sparkline; nothing is generated.
  useEffect(() => {
    setSeries((cur) => {
      let next = cur;
      for (const id of ids) {
        const r = records.get(id);
        if (!r || r.price === null) continue;
        const arr = cur[id] ?? [];
        if (arr.length && arr[arr.length - 1]!.t >= r.updatedAt) continue;
        if (next === cur) next = { ...cur };
        next[id] = [...arr, { t: r.updatedAt, p: r.price }].slice(-60);
      }
      return next;
    });
  }, [records, ids]);
  return <div className="snap">{ids.map((id) => {
    const row = toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec);
    return <Link key={id} href={`/asset/${id}`}><div className="snap-name"><div className="n">{row.asset.name}</div><AssetIcon category={row.asset.category} code={row.asset.code} id={id}/></div><div className="p" style={row.status === 'stale' ? { opacity: .6 } : undefined}>{row.record ? <Num>{fmt(row.price, { digits: d, ...decimals(row) })}</Num> : '—'}</div><div className="u">{row.record ? unitText(row, d) : '—'}</div><div className="c"><Percent value={row.changePercent} digits={d}/><StatusPill status={row.status}/></div><Sparkline points={series[id] ?? []}/></Link>;
  })}</div>;
}
