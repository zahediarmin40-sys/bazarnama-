'use client';
import Link from 'next/link';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { NotConnected } from './NotConnected';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { decimals, Percent, unitText } from './view-helpers';

export function Snapshot({ ids, initial }: { ids: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, mode, intervalSec, now } = useLivePrices(ids, initial);
  if (mode === 'none') return <NotConnected />;
  const d = prefs.digits;
  return (
    <div className="snap">
      {ids.map((id) => {
        const r = toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec);
        return (
          <Link key={id} href={`/asset/${id}`}>
            <div className="n">{r.asset.name}</div>
            <div className="p" style={r.status === 'stale' ? { opacity: 0.6 } : undefined}>{r.record ? <Num>{fmt(r.price, { digits: d, ...decimals(r) })}</Num> : '—'}</div>
            <div className="u">{r.record ? unitText(r, d) : '—'}</div>
            <div className="c"><Percent value={r.changePercent} digits={d} /> <StatusPill status={r.status} /></div>
          </Link>
        );
      })}
    </div>
  );
}
