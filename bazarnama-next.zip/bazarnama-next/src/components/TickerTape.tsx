'use client';
import Link from 'next/link';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { decimals } from './view-helpers';

/** Scrolling strip of live prices. Pauses on hover/focus; static + scrollable when the user prefers reduced motion. */
export function TickerTape({ ids, initial }: { ids: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, intervalSec, now } = useLivePrices(ids, initial);
  const d = prefs.digits;
  const items = ids.map((id) => toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec)).filter((r) => r.record && r.price !== null);
  if (!items.length) return null;
  const cell = (r: (typeof items)[number], key: string, hidden: boolean) => {
    const c = r.changePercent;
    const cls = c === null || c === 0 ? 'flat' : c > 0 ? 'up' : 'down';
    return <Link key={key} href={`/asset/${r.asset.id}`} className="tk" tabIndex={hidden ? -1 : undefined} aria-hidden={hidden || undefined}>
      <span className="tk-n">{r.asset.name}</span><b><Num>{fmt(r.price, { digits: d, ...decimals(r) })}</Num></b>
      {c !== null && <span className={`tk-c ${cls}`}>{c > 0 ? '▲' : c < 0 ? '▼' : '■'} <Num>{fmt(Math.abs(c), { digits: d, min: 1, max: 1 })}٪</Num></span>}
    </Link>;
  };
  return <div className="ticker" role="region" aria-label="نوار قیمت زنده"><div className="ticker-track">
    {items.map((r) => cell(r, r.asset.id, false))}
    {items.map((r) => cell(r, `${r.asset.id}-2`, true))}
  </div></div>;
}
