'use client';
import Link from 'next/link';
import { useState, type ReactNode } from 'react';
import { fmt } from '@/core/format';
import { toDisplay, type DisplayRow } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { MARKET_LABEL } from '@/domain/sections';
import { useLivePrices } from '@/hooks/useLivePrices';
import { NotConnected } from './NotConnected';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { agoText, Change, decimals, Percent, timeText, unitText } from './view-helpers';
import { copyToClipboard } from '@/lib/clipboard';
import { SpecBlock } from './SpecBlock';
import { MetaBlock } from './MetaBlock';

export function LiveTable({ ids, initial }: { ids: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, mode, intervalSec, now } = useLivePrices(ids, initial);
  const [open, setOpen] = useState<ReadonlySet<string>>(new Set());
  const [toast, setToast] = useState('');
  if (mode === 'none') return <NotConnected />;
  const d = prefs.digits;
  const rows = ids.map((id) => toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec));
  const toggle = (id: string) => setOpen((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const say = (m: string) => { setToast(m); setTimeout(() => setToast(''), 1800); };

  const copyPrice = async (r: DisplayRow) => {
    if (!r.record) return;
    const t = `${r.asset.name}: ${fmt(r.price, { digits: d, ...decimals(r) })} ${unitText(r, d)} — ${MARKET_LABEL[r.record?.marketType ?? r.asset.marketType]}${mode === 'demo' ? ' — نمایشی' : ''} — ${timeText(r.record.updatedAt, d)}`;
    say((await copyToClipboard(t)) ? 'کپی شد' : 'کپی انجام نشد');
  };
  const copyLink = async (id: string) => say((await copyToClipboard(`${location.origin}/asset/${id}`)) ? 'کپی شد' : 'کپی انجام نشد');

  return (
    <>
      <div className="tw">
        <table className="pt">
          <thead><tr><th>نام</th><th>قیمت</th><th className="sec">واحد</th><th className="sec">تغییر</th><th>درصد</th><th className="sec">نوع بازار</th><th className="sec">منبع</th><th className="sec">آخرین بروزرسانی</th><th>وضعیت</th></tr></thead>
          <tbody>
            {rows.map((r) => {
              const isOpen = open.has(r.asset.id);
              const dim = r.status === 'stale' ? 'dim' : '';
              return (
                <RowPair key={r.asset.id}>
                  <tr>
                    <td className="nm">
                      <button className="xp" type="button" aria-expanded={isOpen} aria-label={`جزئیات ${r.asset.name}`} onClick={() => toggle(r.asset.id)}>◂</button>
                      <Link href={`/asset/${r.asset.id}`}>{r.asset.name}</Link>{r.asset.tag && <span className="sub">{r.asset.tag}</span>}
                    </td>
                    <td className={`pr ${dim}`}>{r.record ? <Num>{fmt(r.price, { digits: d, ...decimals(r) })}</Num> : '—'}</td>
                    <td className="sec">{r.record ? unitText(r, d) : '—'}</td>
                    <td className={`sec ${dim}`}><Change value={r.change} row={r} digits={d} /></td>
                    <td className={dim}><Percent value={r.changePercent} digits={d} /></td>
                    <td className="sec">{MARKET_LABEL[r.record?.marketType ?? r.asset.marketType]}</td>
                    <td className="sec">{r.record?.source ?? '—'}</td>
                    <td className="sec">{r.record ? <>{timeText(r.record.updatedAt, d)} <span className="sub">{agoText(r.record.updatedAt, now, d)}</span></> : '—'}</td>
                    <td><StatusPill status={r.status} /></td>
                  </tr>
                  {isOpen && (
                    <tr className="dt"><td colSpan={9}>
                      {r.record ? (<>
                        <dl className="dg mobonly" style={{ marginBottom: 8 }}>
                          <div><dt>واحد</dt><dd>{unitText(r, d)}</dd></div><div><dt>تغییر</dt><dd><Change value={r.change} row={r} digits={d} /></dd></div>
                          <div><dt>نوع بازار</dt><dd>{MARKET_LABEL[r.record?.marketType ?? r.asset.marketType]}</dd></div><div><dt>منبع</dt><dd>{r.record.source}</dd></div><div><dt>آخرین بروزرسانی</dt><dd>{timeText(r.record.updatedAt, d)}</dd></div>
                        </dl>
                        <dl className="dg">
                          {r.low !== null && r.high !== null && (<><div><dt>کمترین امروز</dt><dd><Num>{fmt(r.low, { digits: d, ...decimals(r) })}</Num></dd></div><div><dt>بیشترین امروز</dt><dd><Num>{fmt(r.high, { digits: d, ...decimals(r) })}</Num></dd></div></>)}
                          <SpecBlock row={r} gold24={records.get('gold-24') ?? null} prefs={prefs} /><MetaBlock record={r.record} digits={d} />
                        </dl>
                        <div className="acts"><button className="btn" type="button" onClick={() => copyPrice(r)}>کپی قیمت</button><button className="btn" type="button" onClick={() => copyLink(r.asset.id)}>کپی پیوند اشتراک‌گذاری</button><Link className="btn" href={`/asset/${r.asset.id}`}>صفحه کامل</Link></div>
                      </>) : <p className="note">برای این ردیف داده‌ای از منبع دریافت نشده است.</p>}
                    </td></tr>
                  )}
                </RowPair>
              );
            })}
          </tbody>
        </table>
      </div>
      {toast && <div className="toast" role="status">{toast}</div>}
    </>
  );
}
const RowPair = ({ children }: { children: ReactNode }) => <>{children}</>;
