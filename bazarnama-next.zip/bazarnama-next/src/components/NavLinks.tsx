'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const group = (p: string): string => (['/coins', '/metals'].includes(p) ? '/gold' : p.startsWith('/asset/') ? (p.includes('fx-') ? '/currency' : '/gold') : p);

export function NavLinks({ items }: { items: ReadonlyArray<{ href: string; label: string }> }) {
  const cur = group(usePathname());
  return (<ul>{items.map((n) => (<li key={n.href}><Link href={n.href} aria-current={n.href === cur ? 'page' : undefined}>{n.label}</Link></li>))}</ul>);
}
