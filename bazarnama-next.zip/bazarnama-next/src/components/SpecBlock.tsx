import { convertIran } from '@/core/units';
import { fmt, fmtSigned } from '@/core/format';
import type { DisplayPrefs, DisplayRow } from '@/core/display';
import type { Digits } from '@/core/format';
import type { PriceRecord } from '@/core/types';
import { CURRENCY_LABEL } from '@/domain/sections';
import { Num } from './Num';

/** Coin spec + intrinsic value. Intrinsic value is CALCULATED (fine gold g x 24K gram price) and is labelled as such. */
export function SpecBlock({ row, gold24, prefs }: { row: DisplayRow; gold24: PriceRecord | null; prefs: DisplayPrefs & { digits: Digits } }) {
  const sp = row.asset.spec;
  if (!sp) return null;
  const d = prefs.digits;
  const calc = row.price !== null && gold24 && gold24.price !== null && row.currency !== 'USD'
    ? (() => { const intrinsic = convertIran(sp.fineG * gold24.price, 'IRT', prefs.currency); return { intrinsic, diff: row.price! - intrinsic }; })() : null;
  return (
    <>
      <div><dt>وزن (مرجع)</dt><dd><Num>{fmt(sp.weightG, { digits: d, max: 5 })}</Num> گرم</dd></div>
      <div><dt>عیار (مرجع)</dt><dd><Num>{fmt(sp.purity, { digits: d })}</Num></dd></div>
      <div><dt>طلای خالص</dt><dd><Num>{fmt(sp.fineG, { digits: d, max: 4 })}</Num> گرم</dd></div>
      {calc && (<>
        <div><dt>ارزش ذاتی <span className="sub">(محاسبه‌شده)</span></dt><dd><Num>{fmt(calc.intrinsic, { digits: d })}</Num> {CURRENCY_LABEL[prefs.currency]}</dd></div>
        <div><dt>مابه‌التفاوت با ارزش ذاتی <span className="sub">(محاسبه‌شده)</span></dt><dd><Num>{fmtSigned(calc.diff, { digits: d })}</Num> (<Num>{fmtSigned((calc.diff / calc.intrinsic) * 100, { digits: d, min: 1, max: 1 })}٪</Num>)</dd></div>
      </>)}
    </>
  );
}
