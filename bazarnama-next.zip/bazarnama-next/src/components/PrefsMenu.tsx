'use client';
import { usePrefs } from './PrefsProvider';

function Seg<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: ReadonlyArray<[T, string]>; onChange: (v: T) => void }) {
  return (
    <div>
      <label>{label}</label>
      <div className="seg" role="group" aria-label={label}>
        {options.map(([v, l]) => (<button key={v} type="button" aria-pressed={value === v} onClick={() => onChange(v)}>{l}</button>))}
      </div>
    </div>
  );
}
export function PrefsMenu() {
  const { prefs, set } = usePrefs();
  return (
    <details className="set">
      <summary>تنظیمات نمایش</summary>
      <div className="setbox">
        <Seg label="واحد پول (قیمت‌های ایران)" value={prefs.currency} options={[['IRT', 'تومان'], ['IRR', 'ریال']]} onChange={(currency) => set({ currency })} />
        <Seg label="ارقام" value={prefs.digits} options={[['fa', '۱۲۳ فارسی'], ['en', '123 لاتین']]} onChange={(digits) => set({ digits })} />
        <Seg label="پوسته" value={prefs.theme} options={[['auto', 'خودکار'], ['light', 'روشن'], ['dark', 'تیره']]} onChange={(theme) => set({ theme })} />
      </div>
    </details>
  );
}
