/** Pure SVG area chart (no chart library). */
export function Sparkline({ values, label }: { values: readonly number[]; label: string }) {
  const W = 600, H = 120, pad = 6;
  const max = Math.max(1, ...values);
  const x = (i: number) => pad + ((W - 2 * pad) * i) / Math.max(1, values.length - 1);
  const y = (v: number) => H - pad - ((H - 2 * pad) * v) / max;
  const line = values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join('');
  const area = `${line}L${x(values.length - 1).toFixed(1)} ${H - pad}L${x(0).toFixed(1)} ${H - pad}Z`;
  return (
    <svg className="adm-spark" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={label} preserveAspectRatio="none">
      <defs><linearGradient id="spk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--gold)" stopOpacity=".45" /><stop offset="100%" stopColor="var(--gold)" stopOpacity="0" /></linearGradient></defs>
      <path d={area} fill="url(#spk)" /><path d={line} fill="none" stroke="var(--gold)" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}
