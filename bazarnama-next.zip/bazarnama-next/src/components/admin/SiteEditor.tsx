'use client';
import { useState } from 'react';
import { Announcement } from '@/components/Announcement';
import { ASSETS } from '@/domain/catalog';
import type { SiteConfig } from '@/server/config/types';
import { Toggle } from './Toggle';

const MODULE_LABEL: Record<string, string> = { snapshot: 'نوار قیمت‌های کلیدی', tiles: 'کاشی دسته‌بندی‌ها', gold: 'جدول طلا', coins: 'جدول سکه', currency: 'جدول ارز', news: 'آخرین اخبار', tools: 'میانبر ابزارها' };
const TONES = [['info', 'اطلاع‌رسانی'], ['warning', 'هشدار'], ['success', 'خبر خوب']] as const;
const move = <T,>(a: T[], i: number, d: number): T[] => { const j = i + d; if (j < 0 || j >= a.length) return a; const n = [...a]; [n[i], n[j]] = [n[j] as T, n[i] as T]; return n; };
const PICKABLE = ASSETS.filter((a) => a.category !== 'fx' || a.marketType === 'free');

export function SiteEditor({ initial, canEdit }: { initial: SiteConfig; canEdit: boolean }) {
  const [c, setC] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const set = (p: Partial<SiteConfig>) => setC((x) => ({ ...x, ...p }));

  async function save() {
    setBusy(true); setMsg(null);
    try {
      const r = await fetch('/api/admin/config', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(c) });
      const j = (await r.json()) as { config?: SiteConfig; message?: string };
      if (r.ok && j.config) { setC(j.config); setMsg({ ok: true, text: 'تغییرات ذخیره شد و همین حالا روی سایت اعمال است.' }); } else setMsg({ ok: false, text: j.message ?? `خطا (${r.status})` });
    } finally { setBusy(false); }
  }
  async function reset() {
    if (!confirm('همه‌ی تنظیمات ظاهر سایت به حالت پیش‌فرض برگردد؟')) return;
    setBusy(true);
    try { const r = await fetch('/api/admin/config', { method: 'POST' }); const j = (await r.json()) as { config?: SiteConfig }; if (r.ok && j.config) { setC(j.config); setMsg({ ok: true, text: 'به حالت پیش‌فرض برگشت.' }); } } finally { setBusy(false); }
  }
  const toggleSnap = (id: string) => set({ snapshotIds: c.snapshotIds.includes(id) ? c.snapshotIds.filter((x) => x !== id) : [...c.snapshotIds, id] });

  return (
    <div className="adm-grid">
      {msg && <div className={`adm-msg ${msg.ok ? 'ok' : 'err'}`} role="status">{msg.text}</div>}
      <div className="adm-card">
        <h2>اطلاعیه‌ی بالای سایت</h2>
        <div className="adm-row" style={{ marginBottom: 12 }}><Toggle checked={c.announcement.enabled} label="نمایش اطلاعیه" disabled={!canEdit} onChange={(v) => set({ announcement: { ...c.announcement, enabled: v } })} /><span>{c.announcement.enabled ? 'روشن' : 'خاموش'}</span></div>
        <div className="adm-field"><label htmlFor="at">متن (حداکثر ۲۰۰ نویسه)</label><input id="at" value={c.announcement.text} maxLength={200} disabled={!canEdit} onChange={(e) => set({ announcement: { ...c.announcement, text: e.target.value } })} /></div>
        <div className="adm-field"><label htmlFor="ah">پیوند (اختیاری؛ با / یا https:// شروع شود)</label><input id="ah" dir="ltr" value={c.announcement.href} disabled={!canEdit} onChange={(e) => set({ announcement: { ...c.announcement, href: e.target.value } })} /></div>
        <div className="adm-chips" role="group" aria-label="لحن">{TONES.map(([k, l]) => <button key={k} type="button" className="adm-chip" aria-pressed={c.announcement.tone === k} disabled={!canEdit} onClick={() => set({ announcement: { ...c.announcement, tone: k } })}>{l}</button>)}</div>
        <div className="adm-preview" style={{ marginTop: 14 }}><small>پیش‌نمایش</small>{c.announcement.text ? <Announcement a={{ ...c.announcement, enabled: true, href: '' }} /> : <p className="note" style={{ padding: '0 .8rem .6rem' }}>متنی وارد نشده است.</p>}</div>
      </div>

      <div className="adm-card">
        <h2>چیدمان صفحه‌ی اصلی</h2>
        <ul className="adm-list">
          {c.homeModules.map((m, i) => (
            <li className="adm-item" key={m.id}>
              <Toggle checked={m.enabled} label={`نمایش ${MODULE_LABEL[m.id]}`} disabled={!canEdit} onChange={(v) => set({ homeModules: c.homeModules.map((x) => (x.id === m.id ? { ...x, enabled: v } : x)) })} />
              <span className="grow">{MODULE_LABEL[m.id]}</span>
              <button type="button" className="adm-mini" aria-label="بالا" disabled={!canEdit || i === 0} onClick={() => set({ homeModules: move(c.homeModules, i, -1) })}>↑</button>
              <button type="button" className="adm-mini" aria-label="پایین" disabled={!canEdit || i === c.homeModules.length - 1} onClick={() => set({ homeModules: move(c.homeModules, i, 1) })}>↓</button>
            </li>
          ))}
        </ul>
      </div>

      <div className="adm-card">
        <h2>منوی اصلی</h2>
        <ul className="adm-list">
          {c.nav.map((n, i) => (
            <li className="adm-item" key={n.href}>
              <Toggle checked={n.visible} label={`نمایش ${n.label}`} disabled={!canEdit || n.href === '/'} onChange={(v) => set({ nav: c.nav.map((x) => (x.href === n.href ? { ...x, visible: v } : x)) })} />
              <div className="grow"><input aria-label={`برچسب ${n.href}`} value={n.label} maxLength={30} disabled={!canEdit} onChange={(e) => set({ nav: c.nav.map((x) => (x.href === n.href ? { ...x, label: e.target.value } : x)) })} /></div>
              <span className="num note" style={{ margin: 0 }}>{n.href}</span>
              <button type="button" className="adm-mini" aria-label="بالا" disabled={!canEdit || i === 0} onClick={() => set({ nav: move(c.nav, i, -1) })}>↑</button>
              <button type="button" className="adm-mini" aria-label="پایین" disabled={!canEdit || i === c.nav.length - 1} onClick={() => set({ nav: move(c.nav, i, 1) })}>↓</button>
            </li>
          ))}
        </ul>
      </div>

      <div className="adm-card">
        <h2>نوار قیمت‌های کلیدی <span className="adm-pill">{c.snapshotIds.length} از ۶ (حداقل ۳)</span></h2>
        <div className="adm-chips">{PICKABLE.map((a) => <button key={a.id} type="button" className="adm-chip" aria-pressed={c.snapshotIds.includes(a.id)} disabled={!canEdit || (!c.snapshotIds.includes(a.id) && c.snapshotIds.length >= 6)} onClick={() => toggleSnap(a.id)}>{a.name}{a.tag ? ` ${a.tag}` : ''}</button>)}</div>
      </div>

      <div className="adm-card">
        <h2>یادداشت پاورقی</h2>
        <div className="adm-field"><textarea style={{ minHeight: 90 }} aria-label="یادداشت پاورقی" maxLength={300} value={c.footerNote} disabled={!canEdit} onChange={(e) => set({ footerNote: e.target.value })} /></div>
      </div>

      {canEdit && (
        <div className="adm-row" style={{ position: 'sticky', bottom: 14, background: 'var(--sf)', border: '1px solid var(--line)', borderRadius: 14, padding: 12, boxShadow: '0 8px 30px rgba(0,0,0,.14)' }}>
          <button type="button" className="adm-btn pri" disabled={busy} onClick={save}>ذخیره و انتشار</button>
          <button type="button" className="adm-btn danger" disabled={busy} onClick={reset}>بازگشت به پیش‌فرض</button>
        </div>
      )}
    </div>
  );
}
