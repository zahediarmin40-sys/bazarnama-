'use client';
import { useEffect, useRef, useState } from 'react';

interface Msg { role: 'user' | 'assistant'; content: string }
const CHIPS = ['قیمت طلای ۱۸ عیار الان چنده؟', 'ماشین حساب طلا چطور کار می‌کند؟', 'فرق دلار آزاد و مرکز مبادله چیست؟'];
const ERR: Record<string, string> = {
  'support-disabled': 'پشتیبان هوشمند هنوز فعال نشده است.',
  'too-many': 'تعداد پیام‌ها زیاد بود. چند دقیقه بعد دوباره امتحان کنید.',
  busy: 'ظرفیت پشتیبانی فعلاً پر است. کمی بعد دوباره امتحان کنید.',
};

/** Floating AI support assistant. Answers are plain text only (never HTML). */
export function SupportChat() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const end = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs, busy, open]);
  useEffect(() => { if (open) input.current?.focus(); }, [open]);
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, []);

  const send = async (raw: string) => {
    const content = raw.trim().slice(0, 1000);
    if (!content || busy) return;
    const next: Msg[] = [...msgs, { role: 'user', content }];
    setMsgs(next); setText(''); setErr(''); setBusy(true);
    try {
      const res = await fetch('/api/support', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ messages: next.slice(-12) }) });
      const j = (await res.json().catch(() => ({}))) as { reply?: string; error?: string };
      if (res.ok && j.reply) setMsgs([...next, { role: 'assistant', content: j.reply }]);
      else setErr(ERR[j.error ?? ''] ?? 'پاسخی دریافت نشد. دوباره تلاش کنید.');
    } catch { setErr('اتصال برقرار نشد. اینترنت خود را بررسی کنید.'); }
    finally { setBusy(false); }
  };

  return <div className="support" data-open={open || undefined}>
    {open && <div className="support-panel" role="dialog" aria-label="پشتیبان هوشمند بازارنما">
      <div className="support-head"><div><b>پشتیبان هوشمند</b><small>هوش مصنوعی · ممکن است اشتباه کند؛ توصیه‌ی مالی نیست</small></div><button type="button" onClick={() => setOpen(false)} aria-label="بستن">✕</button></div>
      <div className="support-body" aria-live="polite">
        {!msgs.length && <><p className="sb-hello">سلام! من دستیار هوشمند بازارنما هستم. درباره‌ی قیمت‌ها، ماشین حساب و امکانات سایت بپرسید.</p><div className="sb-chips">{CHIPS.map((c) => <button key={c} type="button" onClick={() => send(c)}>{c}</button>)}</div></>}
        {msgs.map((m, i) => <div key={i} className={`sb-msg ${m.role}`}>{m.content}</div>)}
        {busy && <div className="sb-msg assistant sb-typing" aria-label="در حال نوشتن"><i/><i/><i/></div>}
        {err && <div className="sb-err" role="alert">{err}</div>}
        <div ref={end}/>
      </div>
      <div className="support-form"><input ref={input} value={text} maxLength={1000} placeholder="پیام خود را بنویسید…" aria-label="پیام" onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.nativeEvent.isComposing) send(text); }}/><button type="button" onClick={() => send(text)} disabled={busy || !text.trim()}>ارسال</button></div>
    </div>}
    <button type="button" className="support-fab" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label={open ? 'بستن پشتیبان' : 'باز کردن پشتیبان هوشمند'}>{open ? '✕' : '💬'}<span>پشتیبانی</span></button>
  </div>;
}
