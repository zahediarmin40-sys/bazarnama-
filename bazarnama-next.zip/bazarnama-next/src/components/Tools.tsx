'use client';
import { useMemo, useState } from 'react';
import { convertViaToman, goldValue } from '@/core/calc';
import { fmt, parseNum } from '@/core/format';
import { computeStatus, worstStatus } from '@/core/status';
import type { PricesPayload } from '@/core/types';
import { convertIran, convertMass, type MassUnit } from '@/core/units';
import { FX_CURRENCIES } from '@/domain/catalog';
import { CURRENCY_LABEL, UNIT_LABEL } from '@/domain/sections';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { timeText } from './view-helpers';

export const TOOL_IDS = ['gold-24', 'gold-22', 'gold-21', 'gold-18', 'gold-17', 'gold-14', ...FX_CURRENCIES.map(([c]) => `fx-${c.toLowerCase()}-free`)];
const MASS: MassUnit[] = ['gram', 'mesghal', 'ounce', 'kilogram'];

export function Tools({ initial }: { initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const d = prefs.digits;
  const { records, mode, intervalSec, now } = useLivePrices(TOOL_IDS, initial);
  const connected = mode !== 'none';

  const [purity, setPurity] = useState('18'); const [w, setW] = useState('1'); const [wu, setWu] = useState<'gram' | 'mesghal'>('gram');
  const [amt, setAmt] = useState('100'); const [from, setFrom] = useState('USD'); const [to, setTo] = useState('IRT');
  const [uv, setUv] = useState('1'); const [uf, setUf] = useState<MassUnit>('gram'); const [ut, setUt] = useState<MassUnit>('mesghal');

  const gold = useMemo(() => {
    const rec = records.get(`gold-${purity}`); const wn = parseNum(w);
    if (!connected) return { msg: 'قیمت زنده متصل نیست.' };
    if (!rec || rec.price === null) return { msg: 'قیمت این عیار در دسترس نیست.' };
    if (!(wn > 0)) return { msg: 'وزن را وارد کنید.' };
    return { total: convertIran(goldValue(wn, wu, rec.price), 'IRT', prefs.currency), base: convertIran(rec.price, 'IRT', prefs.currency), status: computeStatus(rec, now, intervalSec), t: rec.updatedAt };
  }, [records, purity, w, wu, prefs.currency, now, intervalSec, connected]);

  const fx = useMemo(() => {
    if (!connected) return { msg: 'نرخ زنده متصل نیست.' };
    const a = parseNum(amt);
    const rate = (c: string) => { if (c === 'IRT') return { v: 1 }; if (c === 'IRR') return { v: 0.1 }; const r = records.get(`fx-${c.toLowerCase()}-free`); return r && r.price !== null ? { v: r.price, r } : null; };
    const rf = rate(from), rt = rate(to);
    if (!rf || !rt) return { msg: 'نرخ یکی از ارزها در دسترس نیست.' };
    if (!(a >= 0)) return { msg: 'مبلغ را وارد کنید.' };
    const status = worstStatus([rf, rt].flatMap((x) => ('r' in x && x.r ? [computeStatus(x.r, now, intervalSec)] : [])));
    return { out: convertViaToman(a, rf.v, rt.v), a, status };
  }, [records, amt, from, to, now, intervalSec, connected]);

  const unit = parseNum(uv);
  const opts = ['IRT', 'IRR', ...FX_CURRENCIES.map(([c]) => c)];
  return (
    <div className="tools">
      <div className="panel tool"><h2>ماشین‌حساب طلا</h2>
        <div className="f"><div className="two">
          <div><label htmlFor="gp">عیار</label><select id="gp" value={purity} onChange={(e) => setPurity(e.target.value)}>{[24, 22, 21, 18, 17, 14].map((k) => <option key={k} value={k}>{fmt(k, { digits: d })} عیار</option>)}</select></div>
          <div><label htmlFor="gu">واحد وزن</label><select id="gu" value={wu} onChange={(e) => setWu(e.target.value as 'gram' | 'mesghal')}><option value="gram">گرم</option><option value="mesghal">مثقال</option></select></div>
        </div><div><label htmlFor="gw">وزن</label><input id="gw" inputMode="decimal" value={w} onChange={(e) => setW(e.target.value)} /></div></div>
        <div className="res">{'msg' in gold ? gold.msg : (<><div className="big"><Num>{fmt(gold.total, { digits: d })}</Num> {CURRENCY_LABEL[prefs.currency]}</div><div className="mini">قیمت پایه: <Num>{fmt(gold.base, { digits: d })}</Num> {CURRENCY_LABEL[prefs.currency]} / گرم · <StatusPill status={gold.status} /> · {timeText(gold.t, d)}</div><p className="note">محاسبه‌شده از قیمت جدول. اجرت ساخت، سود فروشنده و مالیات لحاظ نشده است.</p></>)}</div>
      </div>
      <div className="panel tool"><h2>مبدل ارز</h2>
        <div className="f"><div><label htmlFor="fa">مبلغ</label><input id="fa" inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} /></div>
          <div className="three"><div><label htmlFor="ff">از</label><select id="ff" value={from} onChange={(e) => setFrom(e.target.value)}>{opts.map((c) => <option key={c} value={c}>{c}</option>)}</select></div>
            <button className="btn" type="button" aria-label="جابه‌جایی مبدأ و مقصد" onClick={() => { setFrom(to); setTo(from); }}>⇄</button>
            <div><label htmlFor="ft">به</label><select id="ft" value={to} onChange={(e) => setTo(e.target.value)}>{opts.map((c) => <option key={c} value={c}>{c}</option>)}</select></div></div></div>
        <div className="res">{'msg' in fx ? fx.msg : (<><div className="big"><Num>{fmt(fx.out, { digits: d, ...(to === 'IRT' || to === 'IRR' ? {} : { min: 2, max: 2 }) })}</Num> {to}</div><div className="mini"><StatusPill status={fx.status} /></div><p className="note">محاسبه‌شده از نرخ بازار آزاد: هر مبلغ ابتدا به تومان و سپس به ارز مقصد تبدیل می‌شود (ریال = ۰٫۱ تومان).</p></>)}</div>
      </div>
      <div className="panel tool"><h2>مبدل واحد وزن</h2>
        <div className="f"><div><label htmlFor="uv">مقدار</label><input id="uv" inputMode="decimal" value={uv} onChange={(e) => setUv(e.target.value)} /></div>
          <div className="two"><div><label htmlFor="uf">از</label><select id="uf" value={uf} onChange={(e) => setUf(e.target.value as MassUnit)}>{MASS.map((u) => <option key={u} value={u}>{UNIT_LABEL[u]}</option>)}</select></div>
            <div><label htmlFor="ut">به</label><select id="ut" value={ut} onChange={(e) => setUt(e.target.value as MassUnit)}>{MASS.map((u) => <option key={u} value={u}>{UNIT_LABEL[u]}</option>)}</select></div></div></div>
        <div className="res">{unit >= 0 ? <div className="big"><Num>{fmt(convertMass(unit, uf, ut), { digits: d, max: 4 })}</Num> {UNIT_LABEL[ut]}</div> : 'مقدار را وارد کنید.'}</div>
        <p className="note">ثابت‌ها: ۱ مثقال = ۴٫۶۰۸۳ گرم؛ ۱ اونس تروی = ۳۱٫۱۰۳۴۷۶۸ گرم.</p>
      </div>
    </div>
  );
}
