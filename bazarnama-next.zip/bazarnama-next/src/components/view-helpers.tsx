import { fmt, fmtSigned, toFa, type Digits } from '@/core/format';
import type { DisplayRow } from '@/core/display';
import { CURRENCY_LABEL, UNIT_LABEL } from '@/domain/sections';
import { Num } from './Num';

/** USD prices keep 2 decimals; tiny toman rates (e.g. 1 lebanese pound, 1 rupiah) keep 2 too so they are not rounded to a whole number. */
export const decimals = (r: DisplayRow) => (r.currency === 'USD' || (r.price !== null && r.price < 100) ? { min: 2, max: 2 } : {});
export const unitText = (r: DisplayRow, digits: Digits): string =>
  r.asset.unit === 'fx' ? `${CURRENCY_LABEL[r.currency]} / ${fmt(1, { digits })} ${r.asset.fxName}` : `${CURRENCY_LABEL[r.currency]} / ${UNIT_LABEL[r.unit]}`;
export const timeText = (ts: number, digits: Digits): string => {
  const s = new Date(ts).toLocaleTimeString('en-GB', { hour12: false, timeZone: 'Asia/Tehran' });
  return digits === 'fa' ? toFa(s) : s;
};
export const agoText = (ts: number, now: number, digits: Digits): string => {
  const s = Math.max(0, Math.round((now - ts) / 1000));
  return s < 60 ? `${fmt(s, { digits })} ثانیه پیش` : `${fmt(Math.round(s / 60), { digits })} دقیقه پیش`;
};
const dir = (n: number): [string, string] => (n > 0 ? ['up', '▲'] : n < 0 ? ['down', '▼'] : ['flat', '■']);

export function Change({ value, row, digits }: { value: number | null; row: DisplayRow; digits: Digits }) {
  if (value === null) return <span className="flat">—</span>;
  const [c, s] = dir(value);
  return <span className={c}>{s} <Num>{fmtSigned(value, { digits, ...decimals(row) })}</Num></span>;
}
export function Percent({ value, digits }: { value: number | null; digits: Digits }) {
  if (value === null) return <span className="flat">—</span>;
  const [c, s] = dir(value);
  return <span className={c}>{s} <Num>{fmtSigned(value, { digits, min: 2, max: 2 })}٪</Num></span>;
}
