import type { HistoryPoint } from '@/core/store';

/** Tiny trend line drawn from recorded points only. Fewer than 2 points -> nothing is drawn. */
export function Sparkline({ points, className }: { points: readonly HistoryPoint[]; className?: string }) {
  if (points.length < 2) return null;
  const w = 100, h = 32, pad = 3;
  const ps = points.map((p) => p.p);
  const min = Math.min(...ps), max = Math.max(...ps), span = max - min || 1;
  const t0 = points[0]!.t, tSpan = (points[points.length - 1]!.t - t0) || 1;
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${(((p.t - t0) / tSpan) * w).toFixed(1)} ${(h - pad - ((p.p - min) / span) * (h - pad * 2)).toFixed(1)}`).join('');
  const down = points[points.length - 1]!.p < points[0]!.p;
  return <svg className={`trendline ${down ? 'is-down' : ''} ${className ?? ''}`} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" aria-hidden="true"><path d={d} vectorEffect="non-scaling-stroke"/></svg>;
}
