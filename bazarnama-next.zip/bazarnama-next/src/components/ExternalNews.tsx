import type { NewsItem } from '@/server/news/feeds';
import { faDate } from './ArticleCard';

/** Headline + short snippet, always linking out to the original outlet (opens in a new tab). */
export function ExternalNewsCard({ n }: { n: NewsItem }) {
  return <article className="panel ext-news">
    <div className="mini" style={{ marginTop: 0 }}><span className="chip">{n.source}</span>{n.publishedAt && <time dateTime={new Date(n.publishedAt).toISOString()}>{faDate(n.publishedAt)}</time>}</div>
    <h3><a href={n.link} target="_blank" rel="noopener noreferrer nofollow">{n.title}</a></h3>
    {n.summary && <p>{n.summary}</p>}
    <a className="ext-more" href={n.link} target="_blank" rel="noopener noreferrer nofollow">ادامه در {n.source} ↗</a>
  </article>;
}
