import Link from 'next/link';
export function GoldTabs({ current }: { current: 'gold' | 'coins' | 'metals' }) {
  const t: ReadonlyArray<['gold' | 'coins' | 'metals', string]> = [['gold', 'طلا'], ['coins', 'سکه'], ['metals', 'فلزات جهانی']];
  return (<div className="tabs" role="navigation" aria-label="بخش‌های طلا">{t.map(([k, l]) => <Link key={k} href={`/${k}`} aria-current={k === current ? 'page' : undefined}>{l}</Link>)}</div>);
}
