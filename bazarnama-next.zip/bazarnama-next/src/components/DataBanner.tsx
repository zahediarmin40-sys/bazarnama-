import type { PricesMode } from '@/core/types';
export function DataBanner({ mode }: { mode: PricesMode }) {
  if (mode === 'live') return null;
  return (
    <div className={mode === 'demo' ? 'banner' : 'banner off'}>
      <div className="wrap">
        {mode === 'demo' ? <><b>حالت نمایشی:</b> اعداد ساختگی‌اند و قیمت واقعی بازار نیستند.</> : 'قیمت‌های زنده هنوز متصل نشده است.'}
      </div>
    </div>
  );
}
