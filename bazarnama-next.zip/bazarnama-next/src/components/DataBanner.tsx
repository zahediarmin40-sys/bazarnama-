import type { PricesMode } from '@/core/types';
export function DataBanner({ mode, hasData }: { mode: PricesMode; hasData: boolean }) {
  if (mode === 'demo') return <div className="banner"><div className="wrap"><b>حالت نمایشی:</b> اعداد ساختگی‌اند و قیمت واقعی بازار نیستند.</div></div>;
  if (mode === 'none' || !hasData) return <div className="banner off"><div className="wrap">قیمت واقعی تا زمان دریافت موفق از منبع، با خط تیره نمایش داده می‌شود؛ هیچ عددی به‌صورت ساختگی جایگزین نشده است.</div></div>;
  return null;
}
