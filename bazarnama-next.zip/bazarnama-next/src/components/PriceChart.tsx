'use client';
import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent, type ReactNode } from 'react';
import { fmt, toFa } from '@/core/format';
import { convertIran, massFactor } from '@/core/units';
import type { HistoryPoint } from '@/core/store';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { CURRENCY_LABEL, UNIT_LABEL } from '@/domain/sections';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';

const HOUR = 3_600_000;
const RANGES = [
  { key: 'h', label: '۱ ساعت', ms: HOUR },
  { key: 'd', label: '۱ روز', ms: 24 * HOUR },
  { key: 'w', label: '۱ هفته', ms: 7 * 24 * HOUR },
  { key: 'm', label: '۱ ماه', ms: 30 * 24 * HOUR },
  { key: 'q', label: '۳ ماه', ms: 90 * 24 * HOUR },
] as const;
type RangeKey = (typeof RANGES)[number]['key'];
const W = 640, H = 270, L = 12, R = 82, T = 18, B = 30;

/** Line chart of RECORDED prices only. A range is enabled only when recorded history covers at least half of it. */
export function PriceChart({ options, initial, initialHistory }: {
  options: ReadonlyArray<{ id: string; label: string }>;
  initial: PricesPayload;
  initialHistory: Record<string, HistoryPoint[]>;
}) {
  const { prefs } = usePrefs();
  const [id, setId] = useState(options[0]?.id ?? '');
  const ids = useMemo(() => options.map((o) => o.id), [options]);
  const { records, now } = useLivePrices(ids, initial);
  const [hist, setHist] = useState<Record<string, HistoryPoint[]>>(initialHistory);
  const [range, setRange] = useState<RangeKey | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const loaded = useRef(new Set<string>());

  // Full recorded history for the selected asset (the server keeps more points than the first paint carries).
  useEffect(() => {
    if (!id || loaded.current.has(id)) return;
    loaded.current.add(id);
    fetch(`/api/history?id=${encodeURIComponent(id)}`, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { points?: HistoryPoint[] } | null) => { if (j?.points) setHist((h) => ({ ...h, [id]: j.points! })); })
      .catch(() => { loaded.current.delete(id); });
  }, [id]);

  // Live ticks are appended once each.
  const live = id ? records.get(id) : undefined;
  const asset = id ? mustAsset(id) : null;
  const base = useMemo(() => {
    const arr = [...(hist[id] ?? [])];
    if (live && live.price !== null && (!arr.length || arr[arr.length - 1]!.t < live.updatedAt)) arr.push({ t: live.updatedAt, p: live.price });
    return arr;
  }, [hist, id, live]);

  const cur = live?.currency ?? asset?.currency ?? 'IRT';
  const conv = (v: number) => {
    const f = asset?.category === 'gold' ? massFactor(prefs.goldUnit) : 1;
    return cur === 'USD' ? v * f : convertIran(v * f, cur, prefs.currency);
  };
  const unitTxt = !asset ? '' : asset.category === 'gold' ? UNIT_LABEL[prefs.goldUnit] : asset.unit === 'fx' ? `۱ ${asset.fxName}` : UNIT_LABEL[asset.unit];
  const curTxt = cur === 'USD' ? CURRENCY_LABEL.USD : CURRENCY_LABEL[prefs.currency];

  const span = base.length > 1 ? base[base.length - 1]!.t - base[0]!.t : 0;
  const enabled = (k: RangeKey, i: number) => i === 0 || span >= (RANGES.find((r) => r.key === k)!.ms) * 0.5;
  const active: RangeKey = range && enabled(range, RANGES.findIndex((r) => r.key === range)) ? range : (enabled('d', 1) ? 'd' : 'h');
  const winMs = RANGES.find((r) => r.key === active)!.ms;
  const pts = useMemo(() => base.filter((p) => p.t >= now - winMs).map((p) => ({ t: p.t, p: conv(p.p) })), // eslint-disable-next-line react-hooks/exhaustive-deps
    [base, winMs, now > 0 ? Math.floor(now / 15000) : 0, prefs.currency, prefs.goldUnit, cur]);

  const d = prefs.digits;
  const timeLbl = (t: number, withDate: boolean) => {
    const o: Intl.DateTimeFormatOptions = withDate ? { month: '2-digit', day: '2-digit', timeZone: 'Asia/Tehran' } : { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Tehran' };
    const s = new Date(t).toLocaleString('en-GB', o).replace(/,.*/, '');
    return d === 'fa' ? toFa(s) : s;
  };

  let body: ReactNode;
  if (pts.length < 2) {
    body = <div className="chart-empty"><b>داده‌ی کافی برای رسم نمودار ثبت نشده است</b><p>نمودار فقط با قیمت‌های واقعی دریافت‌شده ساخته می‌شود و با ادامه‌ی دریافت داده کامل‌تر خواهد شد.</p></div>;
  } else {
    const t0 = pts[0]!.t, t1 = pts[pts.length - 1]!.t, tSpan = t1 - t0 || 1;
    const lo = Math.min(...pts.map((p) => p.p)), hi = Math.max(...pts.map((p) => p.p));
    const pad = (hi - lo || hi * 0.002 || 1) * 0.12;
    const yMin = lo - pad, yMax = hi + pad;
    const x = (t: number) => L + ((t - t0) / tSpan) * (W - L - R);
    const y = (v: number) => T + (1 - (v - yMin) / (yMax - yMin)) * (H - T - B);
    const line = pts.map((p, i) => `${i ? 'L' : 'M'}${x(p.t).toFixed(1)} ${y(p.p).toFixed(1)}`).join('');
    const area = `${line}L${x(t1).toFixed(1)} ${H - B}L${x(t0).toFixed(1)} ${H - B}Z`;
    const yTicks = [0, 1, 2, 3].map((i) => yMin + ((yMax - yMin) * (3 - i)) / 3);
    const xTicks = [0, 1, 2, 3, 4].map((i) => t0 + (tSpan * i) / 4);
    const withDate = tSpan > 36 * HOUR;
    const last = pts[pts.length - 1]!;
    const hp = hover !== null ? pts[hover] : null;
    const shown = hp ?? last;
    const bx = Math.min(Math.max(x(shown.t), 70), W - R - 10), by = Math.max(y(shown.p) - 44, 4);
    const decs = cur === 'USD' ? { min: 2, max: 2 } : {};
    const onMove = (e: RPointerEvent<SVGSVGElement>) => {
      const rect = svgRef.current?.getBoundingClientRect();
      if (!rect) return;
      const px = ((e.clientX - rect.left) / rect.width) * W;
      let best = 0, bd = Infinity;
      pts.forEach((p, i) => { const dd = Math.abs(x(p.t) - px); if (dd < bd) { bd = dd; best = i; } });
      setHover(best);
    };
    body = <div className="chart-box" dir="ltr">
      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`نمودار قیمت ${asset?.name ?? ''}`} onPointerMove={onMove} onPointerLeave={() => setHover(null)}>
        <defs><linearGradient id="pc-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f5c431" stopOpacity=".55"/><stop offset="1" stopColor="#f5c431" stopOpacity=".03"/></linearGradient></defs>
        {yTicks.map((v, i) => <g key={i}><line x1={L} x2={W - R + 6} y1={y(v)} y2={y(v)} className="pc-grid"/><text x={W - R + 12} y={y(v) + 4} className="pc-ax">{fmt(Math.round(v), { digits: d, ...decs })}</text></g>)}
        {xTicks.map((t, i) => <text key={i} x={x(t)} y={H - 8} textAnchor={i === 0 ? 'start' : i === 4 ? 'end' : 'middle'} className="pc-ax">{timeLbl(t, withDate)}</text>)}
        <path d={area} fill="url(#pc-fill)"/>
        <path d={line} className="pc-line"/>
        {hp && <line x1={x(hp.t)} x2={x(hp.t)} y1={T} y2={H - B} className="pc-cross"/>}
        <circle cx={x(shown.t)} cy={y(shown.p)} r="5" className="pc-dot"/>
        <g transform={`translate(${bx - 62} ${by})`} className="pc-tip"><rect width="124" height="32" rx="9"/><text x="62" y="21" textAnchor="middle">{fmt(Math.round(shown.p), { digits: d, ...decs })}</text></g>
      </svg>
    </div>;
  }

  return <>
    <div className="panel-head chart-head"><h2>نمودار تغییرات قیمت</h2>
      <select className="chart-select" aria-label="انتخاب دارایی" value={id} onChange={(e) => { setId(e.target.value); setHover(null); }}>{options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select>
    </div>
    <div className="range-tabs" role="tablist" aria-label="بازه‌ی زمانی">{[...RANGES].reverse().map((r) => { const i = RANGES.findIndex((x) => x.key === r.key); const ok = enabled(r.key, i); return <button key={r.key} type="button" role="tab" aria-selected={r.key === active} disabled={!ok} title={ok ? undefined : 'داده‌ی ثبت‌شده برای این بازه کافی نیست'} onClick={() => setRange(r.key)}>{r.label}</button>; })}</div>
    {body}
    <p className="chart-note">{asset ? <>قیمت به <Num>{curTxt}</Num> / {unitTxt}</> : null}{pts.length > 1 ? <> · {fmt(pts.length, { digits: d })} نقطه‌ی ثبت‌شده</> : null}</p>
  </>;
}
