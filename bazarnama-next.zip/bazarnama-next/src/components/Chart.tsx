'use client';
import { useEffect, useMemo, useState } from 'react';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PriceRecord, PricesMode } from '@/core/types';
import type { HistoryPoint } from '@/core/store';
import { mustAsset } from '@/domain/catalog';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';

type Period = '1h' | '1d' | '1w' | '1m' | '3m';
const PERIODS: ReadonlyArray<[Period, string, number]> = [
  ['1h', '۱ ساعت', 60 * 60 * 1000], ['1d', '۱ روز', 24 * 60 * 60 * 1000], ['1w', '۱ هفته', 7 * 24 * 60 * 60 * 1000], ['1m', '۱ ماه', 30 * 24 * 60 * 60 * 1000], ['3m', '۳ ماه', 90 * 24 * 60 * 60 * 1000],
];

export function Chart({ assetId, record }: { assetId: string; record: PriceRecord | null }) {
  const { prefs } = usePrefs();
  const [pts, setPts] = useState<readonly HistoryPoint[]>([]);
  const [mode, setMode] = useState<PricesMode>('none');
  const [period, setPeriod] = useState<Period>('1d');
  useEffect(() => {
    let off = false;
    const load = async () => { try { const r = await fetch(`/api/history/${assetId}`, { cache: 'no-store' }); if (r.ok && !off) { const j = (await r.json()) as { mode: PricesMode; points: HistoryPoint[] }; setPts(j.points); setMode(j.mode); } } catch { /* chart is optional */ } };
    void load();
    const t = setInterval(load, 30_000);
    return () => { off = true; clearInterval(t); };
  }, [assetId]);

  const asset = mustAsset(assetId);
  const now = Date.now();
  const periodMs = PERIODS.find(([key]) => key === period)?.[2] ?? PERIODS[1]![2];
  const filtered = useMemo(() => pts.filter((p) => p.t >= now - periodMs), [pts, now, periodMs]);
  const conv = (p: number) => toDisplay(asset, { ...(record ?? { assetId, unit: asset.unit, currency: asset.currency, source: '', updatedAt: now, marketType: asset.marketType, dataStatus: 'live' as const }), price: p, change: null, changePercent: null, low: null, high: null }, prefs, now, 1e9).price ?? p;
  const values = filtered.map((x) => conv(x.p));
  const min = values.length ? Math.min(...values) : 0;
  const max = values.length ? Math.max(...values) : 0;
  const range = max - min || 1;
  const W = 600, H = 190, pad = 10;
  const path = values.map((p, i) => `${i ? 'L' : 'M'}${(pad + ((W - 2 * pad) * i) / Math.max(1, values.length - 1)).toFixed(1)} ${(H - pad - ((H - 2 * pad) * (p - min)) / range).toFixed(1)}`).join(' ');
  const decimals = record?.currency === 'USD' ? { min: 2, max: 2 } : {};
  return (
    <div className="panel chart">
      <div className="chart-title"><div><h2>نمودار {asset.name}</h2><span className="chart-subtitle">{mode === 'demo' ? 'داده نمایشی؛ قیمت واقعی نیست' : 'تاریخچه ثبت‌شده در سرویس'}</span></div><div className="chart-range" role="group" aria-label="بازه نمودار">{PERIODS.map(([key, label]) => <button key={key} type="button" aria-pressed={period === key} onClick={() => setPeriod(key)}>{label}</button>)}</div></div>
      {filtered.length < 2 ? <div className="chart-empty">برای این بازه هنوز داده تاریخی کافی ثبت نشده است.</div> : <>
        <svg className="chart-svg" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`نمودار قیمت ${asset.name}`}>
          <defs><linearGradient id={`chart-fill-${assetId}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#F6C642" stopOpacity=".34" /><stop offset="100%" stopColor="#F6C642" stopOpacity="0" /></linearGradient></defs>
          {[.25, .5, .75].map((k) => <line key={k} x1="0" x2={W} y1={H * k} y2={H * k} stroke="var(--line)" strokeDasharray="4 7" />)}
          <path d={`${path} L${W - pad} ${H - pad} L${pad} ${H - pad} Z`} fill={`url(#chart-fill-${assetId})`} />
          <path d={path} fill="none" stroke="#F6C642" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
        </svg>
        <div className="chart-stats"><span>کمترین: <b><Num>{fmt(min, { digits: prefs.digits, ...decimals })}</Num></b></span><span>بیشترین: <b><Num>{fmt(max, { digits: prefs.digits, ...decimals })}</Num></b></span><span>تعداد نقاط: <b>{filtered.length.toLocaleString('fa-IR')}</b></span></div>
      </>}
    </div>
  );
}
