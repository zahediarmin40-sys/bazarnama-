'use client';
import { useEffect, useState } from 'react';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PriceRecord, PricesMode } from '@/core/types';
import type { HistoryPoint } from '@/core/store';
import { mustAsset } from '@/domain/catalog';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';

export function Chart({ assetId, record }: { assetId: string; record: PriceRecord | null }) {
  const { prefs } = usePrefs();
  const [pts, setPts] = useState<readonly HistoryPoint[]>([]);
  const [mode, setMode] = useState<PricesMode>('none');
  useEffect(() => {
    let off = false;
    const load = async () => { try { const r = await fetch(`/api/history/${assetId}`, { cache: 'no-store' }); if (r.ok && !off) { const j = (await r.json()) as { mode: PricesMode; points: HistoryPoint[] }; setPts(j.points); setMode(j.mode); } } catch { /* chart is optional */ } };
    void load();
    const t = setInterval(load, 30_000);
    return () => { off = true; clearInterval(t); };
  }, [assetId]);

  const asset = mustAsset(assetId);
  if (!record || pts.length < 2) return <div className="panel chart"><p className="note">داده تاریخی کافی نیست.</p></div>;
  const conv = (p: number) => toDisplay(asset, { ...record, price: p, change: null, low: null, high: null }, prefs, record.updatedAt, 1e9).price ?? p;
  const v = pts.map((x) => conv(x.p));
  const min = Math.min(...v), max = Math.max(...v), rg = max - min || 1;
  const W = 600, H = 170, pad = 8;
  const d = v.map((p, i) => `${i ? 'L' : 'M'}${(pad + ((W - 2 * pad) * i) / (v.length - 1)).toFixed(1)} ${(H - pad - ((H - 2 * pad) * (p - min)) / rg).toFixed(1)}`).join('');
  const dec = record.currency === 'USD' ? { min: 2, max: 2 } : {};
  return (
    <div className="panel chart">
      <div className="hd"><h2>نمودار</h2><span className="note" style={{ margin: 0 }}>{mode === 'demo' ? 'نمایشی: داده‌های ساختگی؛ فقط از زمان راه‌اندازی سرور' : 'از زمان راه‌اندازی سرور'}</span></div>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`نمودار قیمت ${asset.name}`}><path d={d} fill="none" stroke="var(--gold)" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" /></svg>
      <div className="mini" style={{ justifyContent: 'space-between' }}><span>کمترین: <Num>{fmt(min, { digits: prefs.digits, ...dec })}</Num></span><span>بیشترین: <Num>{fmt(max, { digits: prefs.digits, ...dec })}</Num></span></div>
    </div>
  );
}
