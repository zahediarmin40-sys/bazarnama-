'use client';
import Link from 'next/link';
import { fmt } from '@/core/format';
import { toDisplay, type DisplayRow } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { decimals } from './view-helpers';

const tone = (p: number): string => {
  const a = 0.14 + Math.min(Math.abs(p) / 3, 1) * 0.56;
  return p === 0 ? 'rgba(148,163,184,.16)' : p > 0 ? `rgba(18,200,98,${a.toFixed(2)})` : `rgba(255,69,77,${a.toFixed(2)})`;
};

/** Market pulse from real day-changes only: rising/falling split, top movers and a currency heatmap. */
export function MarketPulse({ ids, heatIds, initial }: { ids: readonly string[]; heatIds: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, intervalSec, now } = useLivePrices(ids, initial);
  const d = prefs.digits;
  const rows = ids.map((id) => toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec)).filter((r) => r.record && r.changePercent !== null);
  if (rows.length < 3) return null;
  const up = rows.filter((r) => r.changePercent! > 0).length, down = rows.filter((r) => r.changePercent! < 0).length, flat = rows.length - up - down;
  const sorted = [...rows].sort((a, b) => b.changePercent! - a.changePercent!);
  const gain = sorted.filter((r) => r.changePercent! > 0).slice(0, 3);
  const lose = [...sorted].reverse().filter((r) => r.changePercent! < 0).slice(0, 3);
  const heat = heatIds.map((id) => rows.find((r) => r.asset.id === id)).filter((r): r is DisplayRow => !!r).slice(0, 30);
  const pct = (n: number) => `${(n / rows.length) * 100}%`;
  const mover = (r: DisplayRow, k: 'up' | 'down') => <Link key={r.asset.id} href={`/asset/${r.asset.id}`} className="mv"><span>{r.asset.name}</span><b className={k}>{k === 'up' ? '▲' : '▼'} <Num>{fmt(Math.abs(r.changePercent!), { digits: d, min: 1, max: 1 })}٪</Num></b></Link>;
  return <section className="pulse panel" aria-labelledby="pulse-t">
    <div className="panel-head"><h2 id="pulse-t">نبض بازار</h2><span className="pulse-sub">بر پایه‌ی تغییر روزانه‌ی نرخ‌های دریافت‌شده</span></div>
    <div className="mood" role="img" aria-label={`${up} نرخ در حال افزایش، ${down} نرخ در حال کاهش، ${flat} بدون تغییر`}>
      <i className="m-up" style={{ width: pct(up) }}/><i className="m-flat" style={{ width: pct(flat) }}/><i className="m-down" style={{ width: pct(down) }}/>
    </div>
    <p className="mood-t"><span className="up">{fmt(up, { digits: d })} افزایشی</span><span className="flat">{fmt(flat, { digits: d })} ثابت</span><span className="down">{fmt(down, { digits: d })} کاهشی</span></p>
    <div className="pulse-grid">
      <div className="movers"><h3>بیشترین رشد</h3>{gain.length ? gain.map((r) => mover(r, 'up')) : <p className="note">موردی نیست</p>}<h3>بیشترین افت</h3>{lose.length ? lose.map((r) => mover(r, 'down')) : <p className="note">موردی نیست</p>}</div>
      <div><h3>نقشه‌ی حرارتی ارزها</h3><div className="heat">{heat.map((r) => <Link key={r.asset.id} href={`/asset/${r.asset.id}`} className="ht" style={{ background: tone(r.changePercent!) }} title={`${r.asset.name}: ${fmt(r.price, { digits: d, ...decimals(r) })}`}><b>{r.asset.code ?? r.asset.name}</b><span>{r.changePercent! > 0 ? '▲' : r.changePercent! < 0 ? '▼' : '■'} <Num>{fmt(Math.abs(r.changePercent!), { digits: d, min: 1, max: 1 })}٪</Num></span></Link>)}</div></div>
    </div>
  </section>;
}
