'use client';
import { useMemo, useState, type ReactNode } from 'react';
import { convertIran, massFactor, MESGHAL_G, type MassUnit } from '@/core/units';
import { equivalentWeight, finenessOf, goldQuote, pureGoldGrams, scaleKaratPrice } from '@/core/calc';
import { computeStatus } from '@/core/status';
import { fmt, parseNum } from '@/core/format';
import type { PriceRecord, PricesPayload } from '@/core/types';
import { useLivePrices } from '@/hooks/useLivePrices';
import { copyToClipboard } from '@/lib/clipboard';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { agoText } from './view-helpers';

const KARATS = [24, 22, 21, 18, 17, 14] as const;
const IDS = ['gold-24', 'gold-22', 'gold-21', 'gold-18', 'gold-17', 'gold-14', 'gold-melt'];
const BASE_ORDER = [18, 24, 22, 21, 17, 14];
const UNITS: ReadonlyArray<[MassUnit, string]> = [['gram', 'گرم'], ['mesghal', 'مثقال'], ['kilogram', 'کیلوگرم']];
type Kind = number | 'melt' | 'custom';
type Tab = 'value' | 'convert';
interface Resolved { perGram: number; live: boolean; from: string; rec?: PriceRecord }

const irt = (r: PriceRecord | undefined): number | null => {
  if (!r || r.price === null || !(r.price > 0) || r.currency === 'USD') return null;
  return convertIran(r.price, r.currency, 'IRT');
};

/** Gold calculator: price/value of any weight at any karat from live prices; scaled prices are always labelled "calculated". */
export function GoldCalculator({ initial, compact = false }: { initial: PricesPayload; compact?: boolean }) {
  const { prefs } = usePrefs();
  const { records, intervalSec, now } = useLivePrices(IDS, initial);
  const d = prefs.digits;
  const IRR = prefs.currency === 'IRR';
  const cur = IRR ? 'ریال' : 'تومان';
  const show = (v: number) => fmt(Math.round(IRR ? v * 10 : v), { digits: d });
  const [tab, setTab] = useState<Tab>('value');
  const [weight, setWeight] = useState('10');
  const [unit, setUnit] = useState<MassUnit>('gram');
  const [kind, setKind] = useState<Kind>(18);
  const [custom, setCustom] = useState('20');
  const [manual, setManual] = useState('');
  const [work, setWork] = useState(true);
  const [wageType, setWageType] = useState<'percent' | 'perGram'>('percent');
  const [wage, setWage] = useState('10');
  const [profit, setProfit] = useState('7');
  const [tax, setTax] = useState('10');
  const [msg, setMsg] = useState('');

  const karat = kind === 'melt' ? 18 : kind === 'custom' ? parseNum(custom) : kind;
  const karatOk = Number.isFinite(karat) && karat > 0 && karat <= 24;

  /** Live price of a karat if the source has it; otherwise scaled from the best available base (flagged as calculated). */
  const priceFor = (k: number, id: string | null): Resolved | null => {
    const own = id ? records.get(id) : undefined;
    const v = irt(own);
    if (v !== null && own) return { perGram: v, live: true, from: '', rec: own };
    for (const b of BASE_ORDER) {
      const br = records.get(`gold-${b}`);
      const bv = irt(br);
      if (bv !== null) return { perGram: scaleKaratPrice(bv, b, k), live: false, from: `عیار ${fmt(b, { digits: d })}`, rec: br };
    }
    return null;
  };

  const manualVal = parseNum(manual);
  const manualOk = manual.trim() !== '' && Number.isFinite(manualVal) && manualVal > 0;
  const auto = karatOk ? priceFor(karat, kind === 'melt' ? 'gold-melt' : typeof kind === 'number' ? `gold-${kind}` : null) : null;
  const perGram = manualOk ? (IRR ? manualVal / 10 : manualVal) : auto?.perGram ?? null;

  const w = parseNum(weight);
  const wOk = Number.isFinite(w) && w > 0;
  const grams = wOk ? w * massFactor(unit) : NaN;
  const num = (s: string) => { const n = parseNum(s); return Number.isFinite(n) && n >= 0 ? n : 0; };

  const quote = useMemo(() => {
    if (!wOk || perGram === null) return null;
    return goldQuote(grams, perGram, work ? { wage: { type: wageType, value: wageType === 'perGram' ? (IRR ? num(wage) / 10 : num(wage)) : num(wage) }, profitPct: num(profit), taxPct: num(tax) } : {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wOk, grams, perGram, work, wageType, wage, profit, tax, IRR]);

  const table = KARATS.map((k) => ({ k, p: priceFor(k, `gold-${k}`) }));
  const anyPrice = table.some((r) => r.p) || auto !== null;
  const refRec = auto?.rec;
  const pure = karatOk && wOk ? pureGoldGrams(grams, karat) : null;
  const gUnit = (g: number) => `${fmt(+g.toFixed(3), { digits: d, max: 3 })} گرم`;
  const mUnit = (g: number) => `${fmt(+(g / MESGHAL_G).toFixed(3), { digits: d, max: 3 })} مثقال`;

  const copy = async () => {
    if (!quote) return;
    const t = `ماشین حساب طلای بازارنما\nوزن: ${weight} ${UNITS.find((u) => u[0] === unit)![1]} | عیار: ${kind === 'melt' ? 'آب‌شده' : karat}\nقیمت هر گرم: ${show(perGram!)} ${cur}\nارزش طلا: ${show(quote.raw)} ${cur}${work ? `\nاجرت: ${show(quote.wage)}\nسود: ${show(quote.profit)}\nمالیات: ${show(quote.tax)}` : ''}\nمبلغ نهایی: ${show(quote.total)} ${cur}`;
    setMsg((await copyToClipboard(t)) ? 'نتیجه کپی شد' : 'کپی انجام نشد');
    setTimeout(() => setMsg(''), 1800);
  };

  const field = (label: string, node: ReactNode) => <label className="gc-f"><span>{label}</span>{node}</label>;
  const inp = (v: string, set: (s: string) => void, ph?: string) => <input inputMode="decimal" autoComplete="off" value={v} placeholder={ph} onChange={(e) => set(e.target.value)} dir="ltr"/>;

  const weightRow = <div className="gc-row">
    {field('وزن', inp(weight, setWeight, '۱۰'))}
    {field('واحد', <select value={unit} onChange={(e) => setUnit(e.target.value as MassUnit)}>{UNITS.map(([u, l]) => <option key={u} value={u}>{l}</option>)}</select>)}
  </div>;
  const kindRow = <div className="gc-row">
    {field('نوع و عیار طلا', <select value={String(kind)} onChange={(e) => { const v = e.target.value; setKind(v === 'melt' || v === 'custom' ? v : Number(v)); }}>
      {KARATS.map((k) => <option key={k} value={k}>{`${fmt(k, { digits: d })} عیار (${fmt(finenessOf(k), { digits: d })})`}</option>)}
      <option value="melt">طلای آب‌شده (۷۵۰)</option><option value="custom">عیار دلخواه…</option>
    </select>)}
    {kind === 'custom' && field('عیار (۱ تا ۲۴)', inp(custom, setCustom, '۲۰'))}
  </div>;

  return <div className={`gcalc ${compact ? 'is-compact' : ''}`}>
    <div className="gc-tabs" role="tablist" aria-label="نوع محاسبه">
      <button type="button" role="tab" aria-selected={tab === 'value'} onClick={() => setTab('value')}>قیمت و ارزش طلا</button>
      <button type="button" role="tab" aria-selected={tab === 'convert'} onClick={() => setTab('convert')}>تبدیل عیار و وزن</button>
    </div>

    {tab === 'value' ? <div className="gc-grid">
      <div className="gc-form">
        {weightRow}{kindRow}
        {field(`قیمت هر گرم (${cur}) — اختیاری`, inp(manual, setManual, auto ? `خودکار: ${show(auto.perGram)}` : 'قیمت را وارد کنید'))}
        <label className="gc-check"><input type="checkbox" checked={work} onChange={(e) => setWork(e.target.checked)}/> شامل اجرت ساخت، سود و مالیات (خرید طلای ساخته‌شده)</label>
        {work && <div className="gc-extra">
          <div className="gc-row">
            {field('اجرت ساخت', inp(wage, setWage))}
            {field('نوع اجرت', <select value={wageType} onChange={(e) => setWageType(e.target.value as 'percent' | 'perGram')}><option value="percent">درصد از ارزش طلا</option><option value="perGram">{cur} به ازای هر گرم</option></select>)}
          </div>
          <div className="gc-row">{field('سود فروشنده (٪)', inp(profit, setProfit))}{field('مالیات بر ارزش افزوده (٪)', inp(tax, setTax))}</div>
          <p className="gc-hint">مقادیر اجرت، سود و مالیات نمونه هستند؛ مطابق فاکتور فروشنده و نرخ قانونی روز تنظیم کنید. مالیات فقط روی اجرت و سود محاسبه می‌شود.</p>
        </div>}
      </div>

      <div className="gc-out" aria-live="polite">
        {!wOk ? <p className="gc-empty">وزن را به‌صورت عدد مثبت وارد کنید.</p>
          : !karatOk ? <p className="gc-empty">عیار باید عددی بین ۱ تا ۲۴ باشد.</p>
          : perGram === null || !quote ? <p className="gc-empty">قیمت زنده‌ی طلا هنوز دریافت نشده است. می‌توانید قیمت هر گرم را دستی وارد کنید.</p>
          : <>
            <div className="gc-total"><small>مبلغ نهایی</small><b><Num>{show(quote.total)}</Num> <span>{cur}</span></b></div>
            <dl className="gc-break">
              <div><dt>قیمت هر گرم {kind === 'melt' ? 'آب‌شده' : `${fmt(karat, { digits: d })} عیار`}</dt><dd><Num>{show(perGram)}</Num></dd></div>
              <div><dt>ارزش طلا ({gUnit(grams)})</dt><dd><Num>{show(quote.raw)}</Num></dd></div>
              {work && <><div><dt>اجرت ساخت</dt><dd><Num>{show(quote.wage)}</Num></dd></div><div><dt>سود فروشنده</dt><dd><Num>{show(quote.profit)}</Num></dd></div><div><dt>مالیات</dt><dd><Num>{show(quote.tax)}</Num></dd></div></>}
              {pure !== null && <div><dt>طلای خالص (۲۴ عیار) موجود</dt><dd>{gUnit(pure)}</dd></div>}
            </dl>
            <div className="gc-src">
              {manualOk ? <span className="st st-indicative"><i/>قیمت دستی</span>
                : auto?.live && refRec ? <><StatusPill status={computeStatus(refRec, now, intervalSec)}/><span>قیمت زنده · {agoText(refRec.updatedAt, now, d)}</span></>
                : <><span className="st st-indicative"><i/>محاسبه‌شده</span><span>از قیمت {auto?.from} متناسب با عیار</span></>}
            </div>
            <button type="button" className="gc-copy" onClick={copy}>{msg || 'کپی نتیجه'}</button>
          </>}
      </div>
    </div> : <div className="gc-grid">
      <div className="gc-form">
        {weightRow}{kindRow}
        <p className="gc-hint">طلای خالص ۲۴ عیار برابر ۱۰۰۰ در هزار است؛ هر عیار برابر یک‌بیست‌وچهارم آن. جدول مقدار هر عیار را که همان طلای خالص را دارد نشان می‌دهد.</p>
      </div>
      <div className="gc-out">
        {!wOk || !karatOk ? <p className="gc-empty">وزن و عیار معتبر وارد کنید.</p> : <>
          <div className="gc-total"><small>طلای خالص موجود</small><b>{gUnit(pure!)}</b><span className="gc-sub">{mUnit(pure!)}</span></div>
          <table className="gc-table"><thead><tr><th>عیار</th><th>وزن معادل</th><th>مثقال</th></tr></thead><tbody>
            {KARATS.map((k) => { const g = equivalentWeight(grams, karat, k); return <tr key={k}><td>{fmt(k, { digits: d })} ({fmt(finenessOf(k), { digits: d })})</td><td><Num>{gUnit(g)}</Num></td><td><Num>{mUnit(g)}</Num></td></tr>; })}
          </tbody></table>
        </>}
      </div>
    </div>}

    {tab === 'value' && wOk && anyPrice && !compact && <div className="gc-all">
      <h3>قیمت هر گرم و ارزش وزن شما در عیارهای مختلف</h3>
      <div className="tw"><table className="pt"><thead><tr><th>عیار</th><th>قیمت هر گرم ({cur})</th><th>ارزش {gUnit(grams)}</th><th>منبع</th></tr></thead><tbody>
        {table.map(({ k, p }) => <tr key={k}><td className="nm">{fmt(k, { digits: d })} عیار</td><td className="pr"><Num>{p ? show(p.perGram) : '—'}</Num></td><td><Num>{p ? show(p.perGram * grams) : '—'}</Num></td><td>{!p ? '—' : p.live ? <span className="up">زنده</span> : <span className="flat">محاسبه‌شده</span>}</td></tr>)}
      </tbody></table></div>
    </div>}
    <p className="note">نتیجه تقریبی و صرفاً جهت اطلاع است؛ قیمت نهایی را فروشنده تعیین می‌کند و توصیه‌ی خرید یا فروش نیست.</p>
  </div>;
}
