/** Small inline icons (no external images, CSP-safe). */
const SYMBOLS: Record<string, string> = { USD: '$', EUR: '€', GBP: '£', TRY: '₺', JPY: '¥', CNY: '¥', CHF: '₣', AED: 'د.إ', CAD: '$', AUD: '$' };
const TINT: Record<string, string> = { USD: '#2f6fdd', EUR: '#2a56b8', GBP: '#6b3fa0', TRY: '#c8352e', JPY: '#c8352e', CNY: '#c8352e', CHF: '#c8352e', AED: '#1e8a4c', CAD: '#c8352e', AUD: '#1e5aa8' };

export function AssetIcon({ category, code, id }: { category: string; code?: string; id: string }) {
  if (category === 'fx' && code) return <span className="aicon aicon-fx" style={{ background: `radial-gradient(circle at 32% 25%, #ffffff55, ${TINT[code] ?? '#2f6fdd'} 62%)` }} aria-hidden="true">{SYMBOLS[code] ?? code}</span>;
  if (category === 'coin') return <span className="aicon aicon-coin" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.8"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="currentColor" strokeWidth="1.2" opacity=".6"/><path d="M12 8v8M9.5 10.5h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg></span>;
  return <span className="aicon aicon-gold" aria-hidden="true" data-id={id}><svg viewBox="0 0 24 24"><path d="M3 17.5 5.5 12h6l2.5 5.5zM10.5 12 13 6.5h6L21.5 12z" fill="currentColor" opacity=".92"/><path d="M5.5 12h6M13 6.5h6" stroke="#fff6" strokeWidth=".8"/></svg></span>;
}
