import Link from 'next/link';
import { NavLinks } from './NavLinks';
import { PrefsMenu } from './PrefsMenu';
import { SearchBox } from './SearchBox';

export function SiteHeader({ date, time, liveStatus, nav }: {
  date: string;
  time: string;
  liveStatus: 'online' | 'waiting' | 'demo';
  nav: ReadonlyArray<{ href: string; label: string }>;
}) {
  return (
    <header className="top">
      <div className="wrap">
        <div className="brand-row">
          <div className="market-clock">
            <span>{date}</span>
            <strong>{time}</strong>
            <span className={`live-state ${liveStatus}`}><i />{liveStatus === 'online' ? 'داده قیمت دریافت شده' : liveStatus === 'demo' ? 'حالت نمایشی' : 'در انتظار دریافت قیمت'}</span>
          </div>
          <Link className="logo" href="/" aria-label="بازارنما، صفحه اصلی">
            <span className="brand-mark" aria-hidden="true">
              <svg viewBox="0 0 56 56" fill="none">
                <path d="M7 43h42" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                <path d="M12 38V29h8v9M25 38V20h8v18M38 38V11h8v27" fill="currentColor" opacity=".95" />
                <path d="m9 22 12-9 9 5L47 5" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M38 5h9v9" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
            <span className="brand-copy"><b>بازارنما</b><small>مرجع قیمت زنده طلا و دلار</small></span>
          </Link>
          <div className="header-tools">
            <PrefsMenu />
            <div className="header-search"><SearchBox /></div>
          </div>
        </div>
      </div>
      <nav className="main" aria-label="ناوبری اصلی"><div className="wrap"><NavLinks items={nav} /></div></nav>
    </header>
  );
}
