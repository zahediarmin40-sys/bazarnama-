import Link from 'next/link';
import { NavLinks } from './NavLinks';
import { PrefsMenu } from './PrefsMenu';
import { SearchBox } from './SearchBox';

export function SiteHeader({ date, nav }: { date: string; nav: ReadonlyArray<{ href: string; label: string }> }) {
  return (
    <header className="top">
      <div className="wrap">
        <div className="row">
          <Link className="logo" href="/" aria-label="بازارنما، صفحه اصلی">
            <svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true"><rect x="2" y="2" width="26" height="26" rx="7" fill="var(--ink)" /><path d="M8 20l5-6 4 3 5-8" fill="none" stroke="var(--gold)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
            بازارنما
          </Link>
          <SearchBox />
          <span className="date">{date}</span>
          <PrefsMenu />
        </div>
      </div>
      <nav className="main" aria-label="دسته‌بندی‌ها"><div className="wrap"><NavLinks items={nav} /></div></nav>
    </header>
  );
}
