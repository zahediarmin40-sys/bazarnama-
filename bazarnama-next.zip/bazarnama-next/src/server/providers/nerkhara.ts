import type { PriceRecord } from '../../core/types.ts';
import { FX_CURRENCIES, getAsset } from '../../domain/catalog.ts';
import { createRestAdapter } from './rest-adapter.ts';
import { ProviderError, type ProviderAdapter } from './types.ts';

/**
 * NerkhAra: free, keyless JSON API (docs: https://nerkhara.com/en/api/, verified 2026-11-16).
 *  - GET https://nerkhara.com/api/v1/latest.json -> { api:"nerkhara/v1", generated_utc, stale, items:[...] }
 *  - Figures are rebuilt every ~10 minutes: this is NOT a tick-by-tick feed, so records are never labelled "live".
 *  - Limits: 10 req/s (burst 60); asking more than once a minute gains nothing.
 *  - Terms: free incl. commercial use; credit NerkhAra with a link to nerkhara.com and keep the time of each figure.
 *  - Tehran free-market readings, not the Central Bank rate and not quotes to trade on.
 */
export const NERKHARA_BASE_URL = 'https://nerkhara.com/api/v1';
export const NERKHARA_REFRESH_SEC = 600;
export const NERKHARA_SOURCE = 'نرخ‌آرا (nerkhara.com) · بازسازی هر ۱۰ دقیقه';

/** NerkhAra id -> site asset id. Anything not listed is ignored. */
export const NERKHARA_MAP: Readonly<Record<string, string>> = {
  // every currency id published by NerkhAra (44 fiat + usdt): id is the lower-case ISO code
  ...Object.fromEntries(FX_CURRENCIES.map(([code]) => [code.toLowerCase(), `fx-${code.toLowerCase()}-free`])),
  'usd-exchange-centre': 'fx-usd-ex', 'usd-bank-cash': 'fx-usd-cash',
  'gold-24k': 'gold-24', 'gold-18k': 'gold-18',
  'coin-emami': 'coin-emami', 'coin-bahar-azadi': 'coin-old', 'coin-half': 'coin-half', 'coin-quarter': 'coin-quarter', 'coin-gram': 'coin-gram',
  xau: 'gold-ounce',
};

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const numOrNull = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** "2026-11-16T21:14:43" is UTC without a suffix. */
export function parseUtc(s: unknown): number {
  if (typeof s !== 'string') return NaN;
  return Date.parse(/(Z|[+-]\d\d:?\d\d)$/.test(s) ? s : `${s}Z`);
}

/** Pure parser (unit-tested). Skips what it cannot trust; throws only when the document itself is wrong. */
export function parseLatest(json: unknown, now: number): PriceRecord[] {
  if (!isObj(json) || typeof json.api !== 'string' || !json.api.startsWith('nerkhara/') || !Array.isArray(json.items)) {
    throw new ProviderError('PARSE', 'nerkhara: unexpected document shape');
  }
  const feedStale = json.stale === true;
  const out: PriceRecord[] = [];
  for (const it of json.items) {
    if (!isObj(it) || typeof it.id !== 'string') continue;
    const assetId = NERKHARA_MAP[it.id];
    const asset = assetId ? getAsset(assetId) : undefined;
    if (!asset) continue;
    const price = numOrNull(it.price);
    if (price === null || price <= 0) continue;                 // docs: no price => left out; never invent one
    if (it.unit !== asset.currency) continue;                   // unit mismatch (e.g. IRT vs USD): refuse rather than convert silently
    const updatedAt = parseUtc(it.updated_utc);
    if (!Number.isFinite(updatedAt) || updatedAt > now + 5 * 60_000) continue;
    const method = typeof it.method === 'string' ? it.method : undefined;
    const published = method === 'published';                    // once-a-day institutional figure
    const derived = method === 'derived';                         // calculated from the dollar and a world rate
    out.push({
      assetId: asset.id, price, unit: asset.unit, currency: asset.currency,
      change: null,                                               // only a percentage is published; an absolute change would be invented precision
      changePercent: numOrNull(it.change_pct),
      low: numOrNull(it.low_24h), high: numOrNull(it.high_24h),
      source: NERKHARA_SOURCE,
      updatedAt,
      marketType: derived ? 'calculated' : asset.marketType,
      dataStatus: feedStale || it.stale === true ? 'stale' : derived ? 'indicative' : 'delayed',
      expectedIntervalSec: published ? 86_400 : NERKHARA_REFRESH_SEC,
      meta: { method, sources: numOrNull(it.sources), spreadPct: numOrNull(it.spread_pct), asOf: typeof it.as_of === 'string' ? it.as_of : null },
    });
  }
  return out;
}

export function createNerkhAra(env: Record<string, string | undefined>): ProviderAdapter {
  const baseUrl = (env.NERKHARA_BASE_URL || NERKHARA_BASE_URL).replace(/\/+$/, '');
  return createRestAdapter({
    id: 'nerkhara', label: 'NerkhAra', kind: 'live',
    note: 'API رایگان و بدون کلید؛ بازسازی هر ۱۰ دقیقه. ذکر منبع الزامی است.',
    attribution: { name: 'NerkhAra', url: 'https://nerkhara.com/en/' },
    capabilities: { transport: 'rest', minIntervalSec: 60, preferredIntervalSec: 120 },
    baseUrl,
    buildRequest: ({ baseUrl: b }) => ({ url: `${b}/latest.json` }),
    parse: parseLatest,
  });
}
