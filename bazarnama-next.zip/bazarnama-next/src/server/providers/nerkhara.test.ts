import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '../../core/store.ts';
import { computeStatus } from '../../core/status.ts';
import { createMemoryBus } from '../ingest/bus.ts';
import { Ingestor } from '../ingest/ingestor.ts';
import { singleProviderPolicy } from '../ingest/policy.ts';
import { NERKHARA_MAP, parseLatest, parseUtc, createNerkhAra } from './nerkhara.ts';
import { ProviderError } from './types.ts';

const T = Date.parse('2026-11-16T21:20:00Z');
const item = (o: Record<string, unknown>) => ({ family: 'currency', unit: 'IRT', price: 100, price_irt: null, change_pct: 0.9, low_24h: null, high_24h: null, spread_pct: null, sources: 2, method: 'average', as_of: null, updated_utc: '2026-11-16T21:14:43', stale: false, ...o });
// Shapes copied from https://nerkhara.com/api/v1/latest.json (2026-11-16)
const doc = (items: unknown[], extra: Record<string, unknown> = {}) => ({ api: 'nerkhara/v1', generated_utc: '2026-11-16T21:17:06', attribution: 'NerkhAra — https://nerkhara.com', documentation: 'https://nerkhara.com/en/api/', stale: false, items, ...extra });

test('parseUtc treats suffix-less timestamps as UTC', () => {
  assert.equal(parseUtc('2026-11-16T21:14:43'), Date.parse('2026-11-16T21:14:43Z'));
  assert.equal(parseUtc('2026-11-16T21:14:43Z'), Date.parse('2026-11-16T21:14:43Z'));
  assert.ok(Number.isNaN(parseUtc(null)));
});
test('mapping only points at assets that exist in the catalog', async () => {
  const { getAsset } = await import('../../domain/catalog.ts');
  for (const [k, v] of Object.entries(NERKHARA_MAP)) assert.ok(getAsset(v), `${k} -> ${v}`);
});
test('dollar, gold, coins and ounce are mapped with honest metadata', () => {
  const recs = parseLatest(doc([
    item({ id: 'usd', price: 268652.5, low_24h: 265860, high_24h: 269900, spread_pct: 0.04 }),
    item({ id: 'gold-18k', family: 'gold', price: 24553426, change_pct: 0.11, spread_pct: 0.11 }),
    item({ id: 'coin-bahar-azadi', family: 'coin', price: 241202500, change_pct: -0.1 }),
    item({ id: 'xau', family: 'metal', unit: 'USD', price: 3883.92, change_pct: 0.0, sources: 1, method: 'lead' }),
    item({ id: 'usd-exchange-centre', price: 192476, change_pct: null, sources: 1, method: 'published', as_of: '2026-11-16' }),
  ]), T);
  const by = Object.fromEntries(recs.map((r) => [r.assetId, r]));
  assert.equal(recs.length, 5);
  assert.equal(by['fx-usd-free']!.price, 268652.5);
  assert.equal(by['fx-usd-free']!.currency, 'IRT');
  assert.equal(by['fx-usd-free']!.dataStatus, 'delayed');              // 10-minute cadence is never "live"
  assert.equal(by['fx-usd-free']!.change, null);                       // no invented absolute change
  assert.equal(by['fx-usd-free']!.changePercent, 0.9);
  assert.equal(by['fx-usd-free']!.low, 265860);
  assert.equal(by['fx-usd-free']!.updatedAt, Date.parse('2026-11-16T21:14:43Z'));
  assert.equal(by['fx-usd-free']!.meta?.sources, 2);
  assert.equal(by['gold-18']!.unit, 'gram');
  assert.equal(by['coin-old']!.price, 241202500);                      // Bahar Azadi = old-design full coin
  assert.equal(by['gold-ounce']!.currency, 'USD');
  assert.equal(by['fx-usd-ex']!.marketType, 'exchange');
  assert.equal(by['fx-usd-ex']!.expectedIntervalSec, 86400);           // once-a-day figure
  assert.equal(by['fx-usd-ex']!.meta?.asOf, '2026-11-16');
  assert.ok(recs.every((r) => r.expectedIntervalSec && r.source.includes('nerkhara.com')));
});
test('derived rates are labelled calculated/indicative, never as a market quote', () => {
  const [eur] = parseLatest(doc([item({ id: 'eur', price: 296264, method: 'derived', sources: null })]), T);
  assert.equal(eur!.dataStatus, 'indicative');
  assert.equal(eur!.marketType, 'calculated');
});
test('untrusted items are skipped: no price, wrong unit, unknown id, future/garbage time, stale flags', () => {
  const recs = parseLatest(doc([
    item({ id: 'eur', price: null }), item({ id: 'gbp', price: 0 }), item({ id: 'aed', unit: 'USD', price: 5 }),
    item({ id: 'btc', unit: 'USDT', price: 65000 }), item({ id: 'cad', updated_utc: 'garbage' }),
    item({ id: 'aud', updated_utc: '2026-11-17T21:14:43' }), 'nope', null,
    item({ id: 'chf', stale: true }), item({ id: 'jpy' }),
  ]), T);
  assert.deepEqual(recs.map((r) => r.assetId).sort(), ['fx-chf-free', 'fx-jpy-free']);
  assert.equal(recs.find((r) => r.assetId === 'fx-chf-free')!.dataStatus, 'stale');
  const all = parseLatest(doc([item({ id: 'usd' })], { stale: true }), T);
  assert.equal(all[0]!.dataStatus, 'stale');
});
test('wrong document shape is a PARSE error', () => {
  for (const bad of [null, [], { api: 'other/v1', items: [] }, { api: 'nerkhara/v1' }]) {
    assert.throws(() => parseLatest(bad, T), (e: unknown) => e instanceof ProviderError && e.code === 'PARSE');
  }
});
test('status ages with the 10-minute cadence: delayed -> stale', () => {
  const [r] = parseLatest(doc([item({ id: 'usd' })]), T);
  const at = (min: number) => computeStatus(r!, r!.updatedAt + min * 60_000, 20);
  assert.equal(at(5), 'delayed');
  assert.equal(at(50), 'delayed');
  assert.equal(at(70), 'stale');
});
test('adapter: keyless default URL, attribution, polite cadence, end-to-end ingest', async () => {
  const a = createNerkhAra({});
  assert.equal(a.isConfigured(), true);
  assert.equal(a.attribution?.url, 'https://nerkhara.com/en/');
  assert.ok(a.capabilities.minIntervalSec >= 60 && (a.capabilities.preferredIntervalSec ?? 0) >= a.capabilities.minIntervalSec);
  const urls: string[] = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = (async (u: string | URL | Request) => { urls.push(String(u)); return new Response(JSON.stringify(doc([item({ id: 'usd' }), item({ id: 'gold-18k', family: 'gold', price: 24553426 })])), { status: 200 }); }) as typeof fetch;
  try {
    const store = createStore();
    const ing = new Ingestor({ adapters: [a], policy: singleProviderPolicy('nerkhara'), store, bus: createMemoryBus(), defaultIntervalSec: 20, now: () => T });
    assert.equal(await ing.pollOnce(a, new AbortController().signal), true);
    assert.deepEqual(urls, ['https://nerkhara.com/api/v1/latest.json']);
    assert.equal(store.get('fx-usd-free')?.price, 100);
    assert.equal(store.get('gold-18')?.price, 24553426);
    assert.deepEqual(ing.attributions(), [{ name: 'NerkhAra', url: 'https://nerkhara.com/en/' }]);
    globalThis.fetch = (async () => new Response('{}', { status: 429 })) as typeof fetch;
    assert.equal(await ing.pollOnce(a, new AbortController().signal), false);
    assert.match(ing.health()[0]!.lastError ?? '', /RATE_LIMITED/);
    assert.equal(store.get('fx-usd-free')?.price, 100);                // last valid value is kept
  } finally { globalThis.fetch = realFetch; }
});

test('every NerkhAra currency, USDT, bank cash and all five coins are mapped', async () => {
  const { getAsset } = await import('../../domain/catalog.ts');
  const fiat = 'usd eur gbp cny aed qar sar kwd omr bhd iqd try lbp syp afn jpy chf dkk sek nok aud cad nzd rub inr pkr myr sgd hkd thb idr krw azn amd gel kgs uzs tjs tmt kzt brl mxn zar uah'.split(' ');
  assert.equal(fiat.length, 44);
  for (const id of [...fiat, 'usdt']) assert.equal(NERKHARA_MAP[id], `fx-${id}-free`, id);
  assert.equal(NERKHARA_MAP['usd-bank-cash'], 'fx-usd-cash');
  assert.equal(getAsset('fx-usd-cash')?.marketType, 'cash');
  for (const id of ['coin-emami', 'coin-bahar-azadi', 'coin-half', 'coin-quarter', 'coin-gram']) assert.ok(NERKHARA_MAP[id], id);
  const recs = parseLatest(doc([item({ id: 'kwd', price: 924398 }), item({ id: 'usdt', price: 293154 }), item({ id: 'lbp', price: 3.2 }), item({ id: 'usd-bank-cash', price: 290000 })]), T);
  assert.deepEqual(recs.map((r) => r.assetId).sort(), ['fx-kwd-free', 'fx-lbp-free', 'fx-usd-cash', 'fx-usdt-free']);
});
