import { env } from '../env.ts';
import { createNewsAggregator, type FeedSpec } from './feeds.ts';

/** Starting points found via public RSS indexes. Verify them with GET /api/news and override with NEWS_FEEDS if needed. */
export const DEFAULT_FEEDS: FeedSpec[] = [
  { name: 'باشگاه خبرنگاران · اقتصادی', url: 'https://yjc.ir/fa/rss/6' },
  { name: 'دنیای اقتصاد', url: 'https://donya-e-eqtesad.com/feeds/' },
];
export function parseFeedsEnv(raw: string): FeedSpec[] {
  if (!raw.trim()) return DEFAULT_FEEDS;
  try {
    const j = JSON.parse(raw) as unknown;
    if (!Array.isArray(j)) return DEFAULT_FEEDS;
    return j.filter((x): x is FeedSpec => typeof x === 'object' && x !== null && typeof (x as FeedSpec).name === 'string' && typeof (x as FeedSpec).url === 'string' && /^https:\/\//i.test((x as FeedSpec).url)).slice(0, 12);
  } catch { return DEFAULT_FEEDS; }
}
const g = globalThis as unknown as { __bzNews?: ReturnType<typeof createNewsAggregator> };
export function getNews() {
  if (g.__bzNews) return g.__bzNews;
  const e = env();
  return (g.__bzNews = createNewsAggregator({ feeds: e.NEWS_ENABLED === '0' ? [] : parseFeedsEnv(e.NEWS_FEEDS), ttlMs: e.NEWS_REFRESH_SEC * 1000 }));
}
