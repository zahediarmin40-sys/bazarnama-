/** RSS/Atom headline aggregator. Keeps only title, a short snippet, the link, the outlet and the time; the full text stays on the outlet's site. */
export interface NewsItem { title: string; summary: string; link: string; source: string; publishedAt: number | null }
export interface FeedSpec { name: string; url: string }
export interface FeedHealth { name: string; url: string; lastOkAt?: number; lastErrorAt?: number; lastError?: string; items: number }

const ENT: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
const decodeEntities = (s: string): string => s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e: string) => {
  if (e[0] === '#') { const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : ''; }
  return ENT[e.toLowerCase()] ?? m;
});
const clean = (s: string): string => decodeEntities(decodeEntities(s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
const cut = (s: string, n: number): string => (s.length <= n ? s : `${s.slice(0, n - 1).trimEnd()}…`);
const tag = (block: string, name: string): string | null => {
  const m = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i').exec(block);
  return m ? m[1]! : null;
};

/** Only absolute http(s) links survive; everything else (javascript:, data:, garbage) is dropped. */
export function safeLink(raw: string | null | undefined, base?: string): string | null {
  if (!raw) return null;
  try {
    const u = new URL(clean(raw), base);
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.toString() : null;
  } catch { return null; }
}

/** Pure parser (unit-tested). Accepts RSS 2.0 and Atom; skips entries it cannot trust. */
export function parseFeed(xml: string, spec: FeedSpec, now: number): NewsItem[] {
  const out: NewsItem[] = [];
  const blocks = [...xml.matchAll(/<(item|entry)(?:\s[^>]*)?>([\s\S]*?)<\/\1>/gi)].map((m) => m[2]!);
  for (const b of blocks.slice(0, 60)) {
    const title = clean(tag(b, 'title') ?? '');
    const atomHref = /<link\b[^>]*\bhref\s*=\s*["']([^"']+)["']/i.exec(b)?.[1];
    const link = safeLink(tag(b, 'link') ?? atomHref ?? tag(b, 'guid'), spec.url) ?? safeLink(atomHref, spec.url);
    if (!title || !link) continue;
    const dateRaw = tag(b, 'pubDate') ?? tag(b, 'dc:date') ?? tag(b, 'published') ?? tag(b, 'updated');
    let ts: number | null = dateRaw ? Date.parse(clean(dateRaw)) : NaN;
    if (!Number.isFinite(ts) || (ts as number) > now + 3_600_000) ts = null;
    const summary = cut(clean(tag(b, 'description') ?? tag(b, 'summary') ?? tag(b, 'content:encoded') ?? ''), 200);
    out.push({ title: cut(title, 180), summary: summary === title ? '' : summary, link, source: spec.name, publishedAt: ts });
  }
  return out;
}

export async function fetchFeed(spec: FeedSpec, now: () => number = Date.now): Promise<NewsItem[]> {
  if (!/^https:\/\//i.test(spec.url)) throw new Error('feed url must be https');
  const res = await fetch(spec.url, { headers: { 'user-agent': 'BazarnamaBot/1.0 (headline reader)', accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5' }, redirect: 'follow', cache: 'no-store', signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  if (text.length > 3_000_000) throw new Error('feed too large');
  const items = parseFeed(text, spec, now());
  if (!items.length) throw new Error('no items parsed');
  return items;
}

const keyOf = (i: NewsItem): string => i.link.replace(/[#?].*$/, '').replace(/\/+$/, '').toLowerCase();
export function mergeNews(lists: readonly NewsItem[][], max = 80): NewsItem[] {
  const seen = new Set<string>(); const all: NewsItem[] = [];
  for (const l of lists) for (const i of l) { const k = keyOf(i); if (!seen.has(k)) { seen.add(k); all.push(i); } }
  return all.sort((a, b) => (b.publishedAt ?? 0) - (a.publishedAt ?? 0)).slice(0, max);
}

export function createNewsAggregator(o: { feeds: readonly FeedSpec[]; ttlMs?: number; fetcher?: (f: FeedSpec) => Promise<NewsItem[]>; now?: () => number }) {
  const ttl = o.ttlMs ?? 600_000;
  const now = o.now ?? Date.now;
  const fetcher = o.fetcher ?? ((f: FeedSpec) => fetchFeed(f, now));
  const per = new Map<string, NewsItem[]>();
  const health = new Map<string, FeedHealth>(o.feeds.map((f) => [f.url, { name: f.name, url: f.url, items: 0 }]));
  let merged: NewsItem[] = []; let at = 0; let inflight: Promise<void> | null = null;
  const refresh = (): Promise<void> => inflight ??= (async () => {
    const res = await Promise.allSettled(o.feeds.map((f) => fetcher(f)));
    res.forEach((r, i) => {
      const f = o.feeds[i]!; const h = health.get(f.url)!;
      if (r.status === 'fulfilled') { per.set(f.url, r.value); h.lastOkAt = now(); h.lastError = undefined; h.items = r.value.length; }
      else { h.lastErrorAt = now(); h.lastError = r.reason instanceof Error ? r.reason.message.slice(0, 120) : 'error'; } // keep the last good items of a failing feed
    });
    merged = mergeNews(o.feeds.map((f) => per.get(f.url) ?? []));
    at = now();
  })().finally(() => { inflight = null; });
  return {
    /** Fresh cache -> instant. Stale cache -> instant, refresh in background. Empty cache -> wait up to maxWaitMs. */
    async get(maxWaitMs = 3000): Promise<NewsItem[]> {
      if (!o.feeds.length) return [];
      if (at && now() - at < ttl) return merged;
      const p = refresh();
      if (!merged.length) await Promise.race([p, new Promise((r) => setTimeout(r, maxWaitMs))]);
      return merged;
    },
    health: (): FeedHealth[] => [...health.values()].map((h) => ({ ...h })),
  };
}
