import test from 'node:test';
import assert from 'node:assert/strict';
import { createNewsAggregator, mergeNews, parseFeed, safeLink } from './feeds.ts';

const spec = { name: 'نمونه', url: 'https://example.ir/rss' };
const NOW = Date.parse('2026-11-26T08:00:00Z');
const rss = `<?xml version="1.0"?><rss><channel><title>x</title>
<item><title><![CDATA[دلار در آستانه کانال جدید]]></title><link>https://example.ir/n/1?utm=1</link><pubDate>Thu, 26 Nov 2026 06:30:00 GMT</pubDate><description>&lt;p&gt;متن &amp;amp; خلاصه&lt;/p&gt; <b>خبر</b></description></item>
<item><title>خطرناک</title><link>javascript:alert(1)</link></item>
<item><title>بدون لینک</title></item>
<item><title>تاریخ آینده</title><link>/n/3</link><pubDate>Fri, 01 Jan 2100 00:00:00 GMT</pubDate></item>
</channel></rss>`;
const atom = `<feed><entry><title>اتم</title><link href="https://example.ir/a/9" rel="alternate"/><updated>2026-11-26T07:00:00Z</updated><summary>چکیده</summary></entry></feed>`;

test('RSS: CDATA, entities, html stripping, date handling, unsafe links dropped', () => {
  const items = parseFeed(rss, spec, NOW);
  assert.equal(items.length, 2);
  assert.equal(items[0]!.title, 'دلار در آستانه کانال جدید');
  assert.equal(items[0]!.summary, 'متن & خلاصه خبر');
  assert.equal(items[0]!.publishedAt, Date.parse('2026-11-26T06:30:00Z'));
  assert.equal(items[0]!.source, 'نمونه');
  assert.equal(items[1]!.link, 'https://example.ir/n/3');     // relative link resolved against the feed
  assert.equal(items[1]!.publishedAt, null);                  // future date is not trusted
});
test('Atom entries parse', () => {
  const [i] = parseFeed(atom, spec, NOW);
  assert.equal(i!.link, 'https://example.ir/a/9');
  assert.equal(i!.summary, 'چکیده');
  assert.equal(i!.publishedAt, Date.parse('2026-11-26T07:00:00Z'));
});
test('safeLink only allows http(s)', () => {
  assert.equal(safeLink('data:text/html,x'), null);
  assert.equal(safeLink('ftp://a/b'), null);
  assert.equal(safeLink('https://a.ir/x'), 'https://a.ir/x');
});
test('merge dedupes by link and sorts newest first, undated last', () => {
  const a = { title: 'a', summary: '', link: 'https://x.ir/1?ref=1', source: 's', publishedAt: 100 };
  const b = { ...a, title: 'dup', link: 'https://x.ir/1/' };
  const c = { ...a, title: 'c', link: 'https://x.ir/2', publishedAt: 200 };
  const d = { ...a, title: 'd', link: 'https://x.ir/3', publishedAt: null };
  assert.deepEqual(mergeNews([[a, d], [b, c]]).map((i) => i.title), ['c', 'a', 'd']);
});
test('aggregator: one failing feed keeps its last good items and reports the error', async () => {
  let fail = false; let t = 1;
  const it = (n: string) => ({ title: n, summary: '', link: `https://x.ir/${n}`, source: 's', publishedAt: 1 });
  const agg = createNewsAggregator({ feeds: [{ name: 'A', url: 'https://a.ir/r' }, { name: 'B', url: 'https://b.ir/r' }], ttlMs: 10, now: () => t,
    fetcher: async (f) => { if (f.name === 'B' && fail) throw new Error('HTTP 500'); return [it(f.name)]; } });
  assert.equal((await agg.get()).length, 2);
  fail = true; t = 1000;
  assert.equal((await agg.get()).length, 2);   // stale cache answers instantly, refresh runs in the background
  await new Promise((r) => setTimeout(r, 20));
  const h = agg.health().find((x) => x.name === 'B')!;
  assert.equal(h.lastError, 'HTTP 500');
  assert.equal((await createNewsAggregator({ feeds: [] }).get()).length, 0);
});
