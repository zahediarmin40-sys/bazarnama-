export type HomeModuleId = 'snapshot' | 'tiles' | 'gold' | 'coins' | 'currency' | 'news' | 'tools';
export const HOME_MODULE_IDS: readonly HomeModuleId[] = ['snapshot', 'tiles', 'gold', 'coins', 'currency', 'news', 'tools'];
export const NEWS_CATEGORIES = ['بازار طلا', 'ارز و دلار', 'اقتصاد', 'بانک', 'سکه'] as const;
export type NewsCategory = (typeof NEWS_CATEGORIES)[number];
export type AnnouncementTone = 'info' | 'warning' | 'success';

export interface SiteConfig {
  announcement: { enabled: boolean; tone: AnnouncementTone; text: string; href: string };
  homeModules: { id: HomeModuleId; enabled: boolean }[]; // array order = page order
  nav: { href: string; label: string; visible: boolean }[];
  snapshotIds: string[];
  footerNote: string;
}
export interface Article {
  id: string; slug: string; title: string; summary: string; body: string;
  category: NewsCategory; source: string; published: boolean; publishedAt: number; updatedAt: number;
}
export interface PersistedData { config: SiteConfig; articles: Article[] }
