import { getAsset } from '../../domain/catalog.ts';
import { NAV } from '../../domain/sections.ts';
import { defaultConfig } from './defaults.ts';
import { HOME_MODULE_IDS, NEWS_CATEGORIES, type Article, type NewsCategory, type SiteConfig } from './types.ts';

export class ValidationError extends Error {
  readonly field: string;
  constructor(field: string, message: string) { super(message); this.name = 'ValidationError'; this.field = field; }
}
const str = (v: unknown, field: string, max: number, allowEmpty = true): string => {
  if (typeof v !== 'string') throw new ValidationError(field, `${field} باید متن باشد`);
  const t = v.trim();
  if (t.length > max) throw new ValidationError(field, `${field} حداکثر ${max} نویسه`);
  if (!allowEmpty && !t) throw new ValidationError(field, `${field} الزامی است`);
  return t;
};
const safeHref = (v: string, field: string): string => {
  if (!v) return '';
  if (v.startsWith('/') && !v.startsWith('//')) return v;
  if (/^https:\/\/[^\s]+$/.test(v)) return v;
  throw new ValidationError(field, 'پیوند باید با / یا https:// شروع شود');
};

/** Strict whitelist sanitizer: unknown keys are dropped, bad values throw. Missing parts fall back to defaults. */
export function sanitizeConfig(input: unknown, base: SiteConfig = defaultConfig()): SiteConfig {
  if (typeof input !== 'object' || input === null) throw new ValidationError('config', 'ساختار نامعتبر');
  const x = input as Record<string, unknown>;
  const out: SiteConfig = structuredClone(base);

  if (x.announcement !== undefined) {
    const a = x.announcement as Record<string, unknown>;
    if (typeof a !== 'object' || a === null) throw new ValidationError('announcement', 'ساختار نامعتبر');
    const tone = a.tone === 'warning' || a.tone === 'success' ? a.tone : 'info';
    const text = str(a.text ?? '', 'متن اطلاعیه', 200);
    const enabled = a.enabled === true;
    if (enabled && !text) throw new ValidationError('announcement', 'اطلاعیه‌ی فعال باید متن داشته باشد');
    out.announcement = { enabled, tone, text, href: safeHref(str(a.href ?? '', 'پیوند اطلاعیه', 300), 'پیوند اطلاعیه') };
  }
  if (x.homeModules !== undefined) {
    if (!Array.isArray(x.homeModules)) throw new ValidationError('homeModules', 'ساختار نامعتبر');
    const seen = new Set<string>(); const list: SiteConfig['homeModules'] = [];
    for (const m of x.homeModules as Array<Record<string, unknown>>) {
      const id = m?.id as (typeof HOME_MODULE_IDS)[number];
      if (!HOME_MODULE_IDS.includes(id) || seen.has(id)) throw new ValidationError('homeModules', 'ماژول نامعتبر یا تکراری');
      seen.add(id); list.push({ id, enabled: m.enabled !== false });
    }
    for (const id of HOME_MODULE_IDS) if (!seen.has(id)) list.push({ id, enabled: true });
    out.homeModules = list;
  }
  if (x.nav !== undefined) {
    if (!Array.isArray(x.nav)) throw new ValidationError('nav', 'ساختار نامعتبر');
    const known = new Set(NAV.map((n) => n.href)); const seen = new Set<string>(); const list: SiteConfig['nav'] = [];
    for (const n of x.nav as Array<Record<string, unknown>>) {
      const href = n?.href as string;
      if (!known.has(href) || seen.has(href)) throw new ValidationError('nav', 'مسیر منو نامعتبر یا تکراری');
      seen.add(href); list.push({ href, label: str(n.label, 'برچسب منو', 30, false), visible: href === '/' ? true : n.visible !== false });
    }
    for (const d of NAV) if (!seen.has(d.href)) list.push({ href: d.href, label: d.label, visible: true });
    out.nav = list;
  }
  if (x.snapshotIds !== undefined) {
    if (!Array.isArray(x.snapshotIds)) throw new ValidationError('snapshotIds', 'ساختار نامعتبر');
    const ids = [...new Set(x.snapshotIds as unknown[])];
    if (ids.length < 3 || ids.length > 6) throw new ValidationError('snapshotIds', 'نوار قیمت باید ۳ تا ۶ مورد داشته باشد');
    if (!ids.every((i) => typeof i === 'string' && getAsset(i))) throw new ValidationError('snapshotIds', 'شناسه‌ی دارایی نامعتبر');
    out.snapshotIds = ids as string[];
  }
  if (x.footerNote !== undefined) out.footerNote = str(x.footerNote, 'یادداشت پاورقی', 300);
  return out;
}

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
export function sanitizeArticle(input: unknown, existing?: Article, now = Date.now()): Omit<Article, 'id'> {
  if (typeof input !== 'object' || input === null) throw new ValidationError('article', 'ساختار نامعتبر');
  const x = input as Record<string, unknown>;
  const category = x.category as NewsCategory;
  if (!NEWS_CATEGORIES.includes(category)) throw new ValidationError('category', 'دسته‌بندی نامعتبر');
  const slugRaw = typeof x.slug === 'string' ? x.slug.trim().toLowerCase() : '';
  const slug = slugRaw || existing?.slug || `n-${now.toString(36)}`;
  if (slug.length < 3 || slug.length > 60 || !SLUG.test(slug)) throw new ValidationError('slug', 'نشانی باید لاتین/عدد با خط‌تیره، ۳ تا ۶۰ نویسه باشد');
  const publishedAt = typeof x.publishedAt === 'number' && Number.isFinite(x.publishedAt) ? x.publishedAt : existing?.publishedAt ?? now;
  return {
    slug, category, publishedAt, updatedAt: now,
    title: str(x.title, 'تیتر', 150, false), summary: str(x.summary, 'خلاصه', 300, false), body: str(x.body, 'متن خبر', 20000, false),
    source: str(x.source, 'منبع', 80, false), published: x.published === true,
  };
}
