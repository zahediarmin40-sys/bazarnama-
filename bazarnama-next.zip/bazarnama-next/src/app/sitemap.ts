import type { MetadataRoute } from 'next';
import { ASSETS } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://bazarnama.onrender.com';
  const paths = ['', '/all', '/gold', '/coins', '/currency', '/charts', '/tools', '/about', '/news', ...getRuntime().config.listArticles({ publishedOnly: true }).map((a) => `/news/${a.slug}`), ...ASSETS.filter((a) => a.category !== 'world' || a.id === 'gold-ounce').map((a) => `/asset/${a.id}`)];
  return paths.map((p) => ({ url: `${base}${p}`, changeFrequency: p.startsWith('/asset') || p === '' ? 'hourly' : 'daily' }));
}
