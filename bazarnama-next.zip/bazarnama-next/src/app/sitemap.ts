import type { MetadataRoute } from 'next';
import { ASSETS } from '@/domain/catalog';
import { PHASE2 } from '@/domain/sections';
import { getRuntime } from '@/server/ingest/runtime';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';
  const paths = ['', '/gold', '/coins', '/metals', '/currency', '/global', '/tools', '/data', '/news', ...getRuntime().config.listArticles({ publishedOnly: true }).map((a) => `/news/${a.slug}`), ...Object.keys(PHASE2).map((k) => `/${k}`), ...ASSETS.filter((a) => a.marketType !== 'exchange' || a.category === 'fx').map((a) => `/asset/${a.id}`)];
  return paths.map((p) => ({ url: `${base}${p}`, changeFrequency: p.startsWith('/asset') || p === '' ? 'hourly' : 'daily' }));
}
