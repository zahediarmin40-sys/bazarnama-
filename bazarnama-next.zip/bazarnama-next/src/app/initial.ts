import type { PricesPayload } from '@/core/types';
import type { HistoryPoint } from '@/core/store';
import { buildPayload } from '@/server/snapshot';
import { getRuntime } from '@/server/ingest/runtime';
/** Server-render the first paint from the in-memory book; the client then takes over via SSE. */
export const initialFor = (ids: readonly string[]): PricesPayload => buildPayload(new Set(ids));
/** Recorded history (real ticks only) for sparklines and charts. */
export const historyFor = (ids: readonly string[], max = 60): Record<string, HistoryPoint[]> =>
  Object.fromEntries(ids.map((id) => [id, getRuntime().store.history(id).slice(-max).map((p) => ({ ...p }))]));
