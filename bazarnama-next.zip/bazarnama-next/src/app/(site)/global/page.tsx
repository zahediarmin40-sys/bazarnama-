import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { Section } from '@/components/Section';
import { StatusPill } from '@/components/StatusPill';
import { METAL_IDS } from '@/domain/catalog';
import { GLOBAL_SECTIONS } from '@/domain/sections';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'بازارهای جهانی', alternates: { canonical: '/global' } };

export default function GlobalPage() {
  return (
    <>
      <Crumbs trail={[[null, 'بازارهای جهانی']]} />
      <h1>بازارهای جهانی</h1>
      <p className="lead">هر گروه جدا است. تا اتصال منبع، گروه‌هایی که داده ندارند «ناموجود» می‌مانند.</p>
      {GLOBAL_SECTIONS.map((s) => (
        <Section key={s.title} title={s.title}>
          {s.items ? (
            <div className="tw"><table className="pt"><thead><tr><th>نام</th><th>قیمت</th><th>وضعیت</th></tr></thead><tbody>{s.items.map((n) => <tr key={n}><td className="nm">{n}</td><td>—</td><td><StatusPill status="unavailable" /></td></tr>)}</tbody></table></div>
          ) : <LiveTable ids={METAL_IDS} initial={initialFor(METAL_IDS)} />}
        </Section>
      ))}
      <p className="note">نوع هر عدد (قیمت بین‌المللی، مقدار تبدیل‌شده یا مرجع تقریبی) در ستون «نوع بازار» مشخص می‌شود.</p>
    </>
  );
}
