import { redirect } from 'next/navigation';
export default function GlobalPage() { redirect('/currency'); }
