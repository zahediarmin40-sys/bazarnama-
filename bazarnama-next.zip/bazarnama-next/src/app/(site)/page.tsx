import Link from 'next/link';
import { LiveTable } from '@/components/LiveTable';
import { Snapshot } from '@/components/Snapshot';
import { Advertisement } from '@/components/Advertisement';
import { SearchBox } from '@/components/SearchBox';
import { Watchlist } from '@/components/Watchlist';
import { PriceChart } from '@/components/PriceChart';
import { GoldCalculator } from '@/components/GoldCalculator';
import { GOLD_IDS, COIN_IDS, fxIds, mustAsset } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor, historyFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
const CHART_IDS = ['gold-18', 'gold-24', 'coin-emami', 'fx-usd-free', 'fx-eur-free'];
const CALC_IDS = ['gold-24', 'gold-22', 'gold-21', 'gold-18', 'gold-17', 'gold-14', 'gold-melt'];
const ago = (ts: number): string => { const m = Math.max(1, Math.round((Date.now() - ts) / 60000)); return m < 60 ? `${m.toLocaleString('fa-IR')} دقیقه پیش` : m < 1440 ? `${Math.round(m / 60).toLocaleString('fa-IR')} ساعت پیش` : `${Math.round(m / 1440).toLocaleString('fa-IR')} روز پیش`; };
const TABLE_ORDER = [...GOLD_IDS, ...COIN_IDS, ...fxIds('free'), ...fxIds('exchange'), 'gold-ounce'];

function Hero() {
  return <section className="hero" aria-labelledby="hero-title">
    <div className="hero-art" aria-hidden="true"/>
    <div className="hero-copy"><h1 id="hero-title">قیمت لحظه‌ای <em>طلا و دلار</em></h1><p>همیشه به‌روز، شفاف و دقیق</p>
      <ul className="hero-checks"><li>عیارهای دارای قیمت معتبر</li><li>سکه‌ها و ارزهای پشتیبانی‌شده</li><li>منبع و زمان آخرین دریافت</li></ul>
      <Link href="/all" className="hero-cta">سریع، دقیق، مطمئن <b>⚡</b></Link></div>
  </section>;
}

export default function Home() {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const validRecords = rt.store.all().filter((r) => typeof r.price === 'number' && r.price > 0);
  const valid = new Set(validRecords.map((r) => r.assetId));
  const cards = cfg.snapshotIds.filter((id) => valid.has(id)).slice(0, 5);
  const availableIds = [...valid];
  const tableIds = TABLE_ORDER.filter((id) => valid.has(id)).slice(0, 7);
  const chartOptions = CHART_IDS.filter((id) => valid.has(id)).map((id) => ({ id, label: mustAsset(id).name }));
  const news = rt.config.listArticles({ publishedOnly: true }).slice(0, 3);
  const enabledModules = new Set(cfg.homeModules.filter((m) => m.enabled).map((m) => m.id));
  const sections = [
    { href: '/gold', title: 'قیمت طلا', detail: 'عیارهای دارای قیمت معتبر', icon: '◈' },
    { href: '/coins', title: 'قیمت سکه', detail: 'امامی، طرح قدیم، نیم، ربع و گرمی', icon: '◉' },
    { href: '/currency', title: 'قیمت دلار و ارز', detail: 'نرخ‌های دریافت‌شده از منابع', icon: '⇄' },
    { href: '/calculator', title: 'ماشین حساب طلا', detail: 'قیمت هر وزن و عیار، اجرت و مالیات', icon: '▦' },
  ];
  return <>
    <Hero/>
    <Advertisement ads={cfg.ads} placement="home"/>
    <div className="dashboard-intro"><b>قیمت‌های منتخب بازار</b><span className="market-hint">فقط قیمت‌های دریافت‌شده از منبع معتبر نمایش داده می‌شوند.</span><SearchBox availableIds={availableIds}/></div>
    {enabledModules.has('snapshot') && (cards.length ? <Snapshot ids={cards} initial={initialFor(cards)} history={historyFor(cards)}/> : <div className="panel empty price-empty"><b>در حال دریافت قیمت‌های بازار</b><p>به‌محض دریافت داده معتبر، قیمت‌ها در همین قسمت نمایش داده می‌شوند.</p></div>)}
    <Watchlist availableIds={availableIds}/>
    <section className={`dashboard-grid ${enabledModules.has('news') ? 'has-news' : 'without-news'}`} aria-label="نمای کلی بازار">
      <div className="dashboard-table panel"><div className="panel-head"><h2>جدول کامل قیمت‌ها</h2><Link href="/all">مشاهده همه ←</Link></div>
        {tableIds.length ? <div className="home-table"><LiveTable ids={tableIds} initial={initialFor(tableIds)}/></div> : <div className="news-empty">هنوز قیمت معتبری دریافت نشده است.</div>}
      </div>
      <div className="dashboard-chart panel">
        {chartOptions.length ? <PriceChart options={chartOptions} initial={initialFor(chartOptions.map((o) => o.id))} initialHistory={historyFor(chartOptions.map((o) => o.id), 400)}/> : <><div className="panel-head"><h2>نمودار تغییرات قیمت</h2></div><div className="news-empty">پس از دریافت قیمت معتبر، نمودار در این بخش نمایش داده می‌شود.</div></>}
      </div>
      {enabledModules.has('news') && <aside className="dashboard-news panel"><div className="panel-head"><h2>آخرین اخبار اقتصادی</h2><Link href="/news">مشاهده همه</Link></div>
        {news.length ? news.map((article) => <Link className="home-news-item" key={article.id} href={`/news/${article.slug}`}><span className="news-thumb" aria-hidden="true">▤</span><span className="news-text"><b>{article.title}</b><small>{article.category} · {ago(article.publishedAt)}</small></span></Link>) : <div className="news-empty">خبر مرتبطی برای نمایش ثبت نشده است.</div>}
      </aside>}
    </section>
    <section className="shortcut-row" aria-label="دسترسی سریع">{sections.map((s2) => {
      const count = s2.href === '/gold' ? [...GOLD_IDS, 'gold-ounce'].filter((id) => valid.has(id)).length : s2.href === '/coins' ? COIN_IDS.filter((id) => valid.has(id)).length : s2.href === '/currency' ? [...fxIds('free'), ...fxIds('exchange')].filter((id) => valid.has(id)).length : null;
      return <Link className="market-shortcut" key={s2.href} href={s2.href}><span className="shortcut-icon">{s2.icon}</span><span><b>{s2.title}</b><small>{s2.detail}</small>{count !== null && <small className="shortcut-count">{count.toLocaleString('fa-IR')} نرخ در دسترس</small>}</span><i>←</i></Link>;
    })}</section>
    <section className="blk home-calc" aria-labelledby="calc-title"><div className="hd"><h2 id="calc-title">ماشین حساب طلا</h2><Link className="all" href="/calculator">نسخه‌ی کامل ←</Link></div><GoldCalculator compact initial={initialFor(CALC_IDS)}/></section>
    <Advertisement ads={cfg.ads} placement="footer"/>
    <section className="trust-row" aria-label="ویژگی‌های بازارنما">
      <div><b>◉</b><span>نمایش منبع قیمت</span></div><div><b>✓</b><span>اطلاعات معتبر و شفاف</span></div><div><b>⚡</b><span>بروزرسانی خودکار قیمت‌ها</span></div><div><b>▣</b><span>رابط کاربری ساده و سریع</span></div><div><b>♡</b><span>همراه شما در بازار</span></div>
    </section>
  </>;
}
