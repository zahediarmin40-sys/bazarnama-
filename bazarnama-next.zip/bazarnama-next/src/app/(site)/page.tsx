import Link from 'next/link';
import type { ReactNode } from 'react';
import { ArticleCard } from '@/components/ArticleCard';
import { Chart } from '@/components/Chart';
import { LiveTable } from '@/components/LiveTable';
import { Section } from '@/components/Section';
import { Snapshot } from '@/components/Snapshot';
import { GOLD_IDS, COIN_IDS } from '@/domain/catalog';

import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
const SNAP_IDS = ['gold-18', 'coin-emami', 'fx-usd-free', 'fx-eur-free', 'gold-24'];
const HOME_TABLE_IDS = ['gold-18', 'gold-melt', 'gold-24', 'gold-22', 'gold-21', 'coin-emami', 'coin-half', 'coin-quarter', 'fx-usd-free'];
const SHORTCUTS: ReadonlyArray<[string, string, string]> = [
  ['/gold', 'قیمت انواع طلا', 'عیار ۱۸، ۲۱، ۲۲، ۲۴ و اونس جهانی'],
  ['/coins', 'قیمت انواع سکه', 'امامی، بهار آزادی، نیم، ربع و گرمی'],
  ['/currency', 'قیمت دلار و ارز', 'بازار آزاد و مرکز مبادله'],
  ['/all', 'جدول کامل قیمت‌ها', 'تمام دارایی‌های پشتیبانی‌شده'],
  ['/charts', 'نمودار و تحلیل', 'روند تغییرات قیمت در بازه‌های زمانی'],
  ['/tools', 'محاسبه‌گر هوشمند', 'محاسبه قیمت طلا و تبدیل ارز'],
];

function Hero() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="hero-copy">
        <div className="hero-kicker"><span /> مرجع تخصصی بازار طلا و ارز</div>
        <h1 id="hero-title">قیمت لحظه‌ای <em>طلا و دلار</em></h1>
        <p>همیشه به‌روز، شفاف و قابل مقایسه</p>
        <div className="hero-checks"><span>✓ تمامی عیارها و انواع سکه</span><span>✓ نرخ‌های مختلف ارز</span><span>✓ نمودار و محاسبه‌گر قیمت</span></div>
        <Link href="/all" className="hero-cta">مشاهده جدول کامل قیمت‌ها <b>←</b></Link>
      </div>
      <div className="hero-art" aria-hidden="true" />
    </section>
  );
}

export default function Home() {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const news = rt.config.listArticles({ publishedOnly: true }).slice(0, 3);
  const cards = initialFor(SNAP_IDS);
  const homeTable = initialFor(HOME_TABLE_IDS);
  const goldRecord = cards.records.find((r) => r.assetId === 'gold-18') ?? null;
  const modules: Record<string, ReactNode> = {
    snapshot: <Section key="snapshot" title="قیمت‌های منتخب بازار" href="/all"><Snapshot ids={SNAP_IDS} initial={cards} /></Section>,
    tiles: <Section key="tiles" title="دسترسی سریع"><div className="shortcut-grid">{SHORTCUTS.map(([href, title, desc]) => <Link className="shortcut" key={href} href={href}><b>{title}</b><span>{desc}</span><i>←</i></Link>)}</div></Section>,
    gold: <Section key="gold" title="قیمت طلا" href="/gold"><LiveTable ids={GOLD_IDS} initial={initialFor(GOLD_IDS)} /><p className="note">قیمت هر گرم به تفکیک عیار. اونس جهانی در صفحه طلا نمایش داده می‌شود.</p></Section>,
    coins: <Section key="coins" title="قیمت سکه" href="/coins"><LiveTable ids={COIN_IDS} initial={initialFor(COIN_IDS)} /></Section>,
    currency: <Section key="currency" title="قیمت ارز" href="/currency"><LiveTable ids={['fx-usd-free', 'fx-usd-ex', 'fx-eur-free', 'fx-aed-free']} initial={initialFor(['fx-usd-free', 'fx-usd-ex', 'fx-eur-free', 'fx-aed-free'])} /></Section>,
    news: <Section key="news" title="آخرین اخبار اقتصادی" href="/news">{news.length ? <div className="news-list">{news.map((article) => <ArticleCard key={article.id} a={article} />)}</div> : <div className="panel empty"><b>هنوز خبری منتشر نشده است.</b><p>به‌زودی خبرها و تحلیل‌های مرتبط با طلا و ارز در این قسمت قرار می‌گیرند.</p></div>}</Section>,
    tools: <Section key="tools" title="ابزارهای بازار" href="/tools"><div className="shortcut-grid"><Link className="shortcut" href="/tools"><b>محاسبه قیمت طلا</b><span>بر اساس وزن و عیار</span><i>←</i></Link><Link className="shortcut" href="/tools"><b>مبدل دلار و ارز</b><span>تبدیل با نرخ‌های بازار</span><i>←</i></Link><Link className="shortcut" href="/charts"><b>بررسی نمودارها</b><span>مشاهده سابقه تغییرات</span><i>←</i></Link></div></Section>,
  };
  return (
    <>
      <Hero />
      <div className="dashboard-intro"><span>نمای کلی بازار</span><span className="market-hint">قیمت‌ها تنها پس از دریافت از منبع معتبر نمایش داده می‌شوند.</span></div>
      {cfg.homeModules.filter((m) => m.enabled && m.id === 'snapshot').map((module) => modules[module.id])}
      <section className="dashboard-grid" aria-label="نمایش سریع بازار">
        <aside className="dashboard-news">
          <div className="panel-head"><h2>آخرین اخبار اقتصادی</h2><Link href="/news">مشاهده همه</Link></div>
          {news.length ? news.map((article) => <ArticleCard key={article.id} a={article} />) : <div className="news-empty">خبر مرتبطی برای نمایش ثبت نشده است.</div>}
        </aside>
        <div className="dashboard-chart">
          <div className="panel-head"><h2>نمودار تغییرات طلای ۱۸ عیار</h2><Link href="/charts">همه نمودارها</Link></div>
          <Chart assetId="gold-18" record={goldRecord} />
        </div>
        <div className="dashboard-table">
          <div className="panel-head"><h2>جدول قیمت‌های منتخب</h2><Link href="/all">جدول کامل</Link></div>
          <div className="home-table"><LiveTable ids={HOME_TABLE_IDS} initial={homeTable} /></div>
        </div>
      </section>
      <section className="trust-row" aria-label="ویژگی‌های بازارنما">
        <div><b>◎</b><span>نمایش منبع و زمان بروزرسانی</span></div>
        <div><b>↻</b><span>بروزرسانی خودکار اطلاعات</span></div>
        <div><b>⚡</b><span>محاسبه سریع و دقیق</span></div>
        <div><b>◈</b><span>رابط کاربری ساده و سریع</span></div>
      </section>
    </>
  );
}
