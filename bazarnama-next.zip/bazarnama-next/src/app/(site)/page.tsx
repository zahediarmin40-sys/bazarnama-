import Link from 'next/link';
import type { ReactNode } from 'react';
import { ArticleCard } from '@/components/ArticleCard';
import { LiveTable } from '@/components/LiveTable';
import { Section } from '@/components/Section';
import { Snapshot } from '@/components/Snapshot';
import { COIN_IDS, GOLD_IDS } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
const FX_PREVIEW = ['fx-usd-free', 'fx-eur-free', 'fx-gbp-free', 'fx-aed-free', 'fx-try-free', 'fx-cny-free'];
const TILES: ReadonlyArray<[string, string, string]> = [['/gold', 'طلا و سکه', 'عیارها، سکه‌ها، اونس'], ['/currency', 'ارز', 'بازار آزاد و مرکز مبادله'], ['/vehicles', 'خودرو', 'داخلی و وارداتی'], ['/mobile', 'موبایل', 'برند، مدل، حافظه'], ['/housing', 'مسکن', 'منطقه و نوع ملک'], ['/iron', 'آهن و مصالح', 'محصول و گرید'], ['/global', 'بازارهای جهانی', 'فلزات، انرژی، شاخص‌ها']];

export default function Home() {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const news = rt.config.listArticles({ publishedOnly: true }).slice(0, 3);
  const modules: Record<string, ReactNode> = {
    snapshot: <Snapshot key="snapshot" ids={cfg.snapshotIds} initial={initialFor(cfg.snapshotIds)} />,
    tiles: <section key="tiles" className="blk" aria-label="دسته‌بندی‌ها"><div className="tiles">{TILES.map(([h, t, s]) => <Link key={h} href={h}><b>{t}</b><span>{s}</span></Link>)}</div></section>,
    gold: <Section key="gold" title="طلا" href="/gold"><LiveTable ids={GOLD_IDS} initial={initialFor(GOLD_IDS)} /><p className="note">قیمت هر گرم، بازار آزاد ایران. اونس جهانی در صفحه طلا جدا نمایش داده می‌شود.</p></Section>,
    coins: <Section key="coins" title="سکه" href="/coins"><LiveTable ids={COIN_IDS} initial={initialFor(COIN_IDS)} /></Section>,
    currency: <Section key="currency" title="ارز (بازار آزاد)" href="/currency"><LiveTable ids={FX_PREVIEW} initial={initialFor(FX_PREVIEW)} /></Section>,
    news: <Section key="news" title="آخرین اخبار اقتصادی" href="/news">{news.length ? <div style={{ display: 'grid', gap: 10 }}>{news.map((a) => <ArticleCard key={a.id} a={a} />)}</div> : <div className="panel empty"><b>هنوز خبری منتشر نشده است.</b></div>}</Section>,
    tools: <Section key="tools" title="ابزارها" href="/tools"><div className="tiles"><Link href="/tools"><b>ماشین‌حساب طلا</b><span>وزن و عیار به مبلغ</span></Link><Link href="/tools"><b>مبدل ارز</b><span>با دکمه جابه‌جایی</span></Link><Link href="/tools"><b>مبدل واحد</b><span>گرم، مثقال، اونس</span></Link></div></Section>,
  };
  return (
    <>
      <h1>قیمت طلا، سکه و ارز</h1>
      <p className="lead">هر قیمت با واحد، منبع و زمان بروزرسانی. برای دیدن همه ردیف‌ها، دسته‌بندی را باز کنید.</p>
      {cfg.homeModules.filter((m) => m.enabled).map((m) => modules[m.id])}
    </>
  );
}
