import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Crumbs } from '@/components/Crumbs';
import { PHASE2 } from '@/domain/sections';

type Props = { params: Promise<{ section: string }> };
export const dynamicParams = false;
export const generateStaticParams = () => Object.keys(PHASE2).map((section) => ({ section }));
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const s = PHASE2[(await params).section];
  return { title: s?.title ?? 'پیدا نشد' };
}
export default async function Phase2Page({ params }: Props) {
  const s = PHASE2[(await params).section];
  if (!s) return notFound();
  return (
    <>
      <Crumbs trail={[[null, s.title]]} />
      <h1>{s.title}</h1>
      <div className="panel empty"><b>این بخش در فاز ۲ ساخته می‌شود.</b><p>هنوز منبع داده متصل نیست و هیچ عدد نمایشی برای آن نشان داده نمی‌شود.</p></div>
      <section className="blk"><h2>ستون‌های جدول</h2><div className="cols">{s.columns.map((c) => <span className="chip" key={c}>{c}</span>)}</div><h2>فیلترها</h2><div className="cols">{s.filters.map((c) => <span className="chip" key={c}>{c}</span>)}</div>{s.note && <p className="note">{s.note}</p>}</section>
    </>
  );
}
