import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldTabs } from '@/components/GoldTabs';
import { LiveTable } from '@/components/LiveTable';
import { COIN_IDS } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت سکه', alternates: { canonical: '/coins' } };

export default function CoinsPage() {
  return (
    <>
      <Crumbs trail={[['/gold', 'طلا'], [null, 'سکه']]} />
      <h1>قیمت سکه</h1>
      <p className="lead">انواع سکه را مقایسه کنید. روی نام سکه بزنید تا وزن، عیار، طلای خالص و نمودار را ببینید.</p>
      <GoldTabs current="coins" />
      <LiveTable ids={COIN_IDS} initial={initialFor(COIN_IDS)} />
      <p className="note">وزن و عیار سکه‌ها مشخصات مرجع‌اند و پیش از انتشار باید با منبع معتبر تأیید شوند. ارزش ذاتی با برچسب «محاسبه‌شده» آمده است: وزن طلای خالص × قیمت هر گرم ۲۴ عیار.</p>
    </>
  );
}
