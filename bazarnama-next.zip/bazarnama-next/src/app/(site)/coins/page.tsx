import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldTabs } from '@/components/GoldTabs';
import { LiveTable } from '@/components/LiveTable';
import { Chart } from '@/components/Chart';
import { Section } from '@/components/Section';
import { COIN_IDS } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت سکه', alternates: { canonical: '/coins' } };
export default function CoinsPage() {
  const payload = initialFor(['coin-emami']);
  return <>
    <Crumbs trail={[['/gold', 'طلا'], [null, 'سکه']]} />
    <h1>قیمت انواع سکه</h1>
    <p className="lead">قیمت سکه امامی، طرح قدیم، نیم، ربع و گرمی را در یک جدول مقایسه کنید.</p>
    <GoldTabs current="coins" />
    <LiveTable ids={COIN_IDS} initial={initialFor(COIN_IDS)} />
    <p className="note">وزن و عیار سکه‌ها مشخصات مرجع‌اند. ارزش ذاتی و حباب سکه فقط زمانی محاسبه می‌شود که داده‌های لازم با منبع معتبر در دسترس باشند.</p>
    <Section title="نمودار سکه امامی" href="/charts"><Chart assetId="coin-emami" record={payload.records[0] ?? null} /></Section>
  </>;
}
