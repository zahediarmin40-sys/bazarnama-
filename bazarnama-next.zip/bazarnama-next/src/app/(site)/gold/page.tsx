import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldTabs } from '@/components/GoldTabs';
import { GoldUnitSeg } from '@/components/GoldUnitSeg';
import { LiveTable } from '@/components/LiveTable';
import { Section } from '@/components/Section';
import { Chart } from '@/components/Chart';
import { GOLD_IDS } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت طلا', alternates: { canonical: '/gold' } };
const WORLD = ['gold-ounce'];
export default function GoldPage() {
  const payload = initialFor(['gold-18']);
  return <>
    <Crumbs trail={[[null, 'طلا']]} />
    <h1>قیمت انواع طلا</h1>
    <p className="lead">قیمت بازار ایران را به تفکیک عیار، همراه با واحد و زمان دریافت مشاهده کنید.</p>
    <GoldTabs current="gold" />
    <GoldUnitSeg />
    <LiveTable ids={GOLD_IDS} initial={initialFor(GOLD_IDS)} />
    <p className="note">تبدیل واحد: ۱ مثقال = ۴٫۶۰۸۳ گرم؛ ۱ کیلوگرم = ۱۰۰۰ گرم. اجرت، سود فروشنده و مالیات در این نرخ‌ها لحاظ نشده است.</p>
    <Section title="نمودار طلای ۱۸ عیار" href="/charts"><Chart assetId="gold-18" record={payload.records[0] ?? null} /></Section>
    <Section title="اونس جهانی طلا"><LiveTable ids={WORLD} initial={initialFor(WORLD)} /><p className="note">اونس جهانی با واحد دلار نمایش داده می‌شود و از قیمت بازار داخلی جداست.</p></Section>
  </>;
}
