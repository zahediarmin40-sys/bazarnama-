import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldTabs } from '@/components/GoldTabs';
import { GoldUnitSeg } from '@/components/GoldUnitSeg';
import { LiveTable } from '@/components/LiveTable';
import { Section } from '@/components/Section';
import { GOLD_IDS } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت طلا', alternates: { canonical: '/gold' } };
const WORLD = ['gold-ounce'];

export default function GoldPage() {
  return (
    <>
      <Crumbs trail={[[null, 'طلا']]} />
      <h1>قیمت طلا</h1>
      <p className="lead">قیمت بازار آزاد ایران برای هر عیار. قیمت جهانی جدا و با واحد دلار نمایش داده می‌شود.</p>
      <GoldTabs current="gold" />
      <GoldUnitSeg />
      <LiveTable ids={GOLD_IDS} initial={initialFor(GOLD_IDS)} />
      <p className="note">تبدیل واحد: ۱ مثقال = ۴٫۶۰۸۳ گرم؛ ۱ کیلوگرم = ۱۰۰۰ گرم. ردیف را برای کمترین و بیشترین امروز باز کنید.</p>
      <Section title="قیمت جهانی (اونس، دلار آمریکا)"><LiveTable ids={WORLD} initial={initialFor(WORLD)} /><p className="note">این ردیف قیمت بین‌المللی است و ربطی به قیمت بازار تهران ندارد. قیمت بازار ایران از روی اونس و دلار محاسبه نمی‌شود.</p></Section>
    </>
  );
}
