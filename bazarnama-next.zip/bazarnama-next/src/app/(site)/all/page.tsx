import Link from 'next/link';
import { NAV } from '@/domain/sections';
export const metadata = { title: 'همه بخش‌ها' };
export default function AllPage() {
  return (<><h1>همه بخش‌ها</h1><div className="tiles">{[...NAV.filter((n) => n.href !== '/'), { href: '/coins', label: 'سکه' }, { href: '/metals', label: 'فلزات جهانی' }].map((n) => <Link key={n.href} href={n.href}><b>{n.label}</b></Link>)}</div></>);
}
