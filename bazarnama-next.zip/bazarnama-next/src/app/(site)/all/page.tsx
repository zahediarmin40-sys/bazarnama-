import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { GOLD_IDS, COIN_IDS, fxIds } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'جدول کامل قیمت‌ها', alternates: { canonical: '/all' } };
const IDS = [...GOLD_IDS, ...COIN_IDS, ...fxIds('free'), ...fxIds('exchange'), 'gold-ounce'];
export default function AllPage() {
  return <>
    <Crumbs trail={[[null, 'جدول کامل قیمت‌ها']]} />
    <div className="page-heading"><div><h1>جدول کامل قیمت‌ها</h1><p className="lead">تمام ردیف‌های پشتیبانی‌شده طلا، سکه و ارز را در یک جدول مقایسه کنید.</p></div><span className="heading-badge">{IDS.length} ردیف اطلاعات</span></div>
    <div className="filter-strip"><span>طلا و عیارها</span><span>انواع سکه</span><span>دلار و ارز</span><span>اونس جهانی</span></div>
    <LiveTable ids={IDS} initial={initialFor(IDS)} />
    <p className="note">نرخ بازار آزاد و مرکز مبادله به‌صورت جداگانه نمایش داده می‌شوند. ردیف بدون قیمت یعنی منبع آن داده معتبری ارسال نکرده است.</p>
  </>;
}
