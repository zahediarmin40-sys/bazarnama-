import Link from 'next/link';
import type { ReactNode } from 'react';
import { Announcement } from '@/components/Announcement';
import { BottomNav } from '@/components/BottomNav';
import { DataBanner } from '@/components/DataBanner';
import { SiteHeader } from '@/components/SiteHeader';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export default function SiteLayout({ children }: { children: ReactNode }) {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const date = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full', timeZone: 'Asia/Tehran' }).format(new Date());
  return (
    <>
      <a className="skip" href="#main">پرش به محتوا</a>
      <SiteHeader date={date} nav={cfg.nav.filter((n) => n.visible)} />
      <Announcement a={cfg.announcement} />
      <DataBanner mode={rt.mode} />
      <main id="main" tabIndex={-1}><div className="wrap">{children}</div></main>
      <footer className="site"><div className="wrap">
        <p><Link href="/data">درباره داده‌ها</Link><Link href="/data">روش‌شناسی</Link><Link href="/data">حریم خصوصی</Link><Link href="/data">تماس</Link><Link href="/data">سلب مسئولیت</Link></p>
        {rt.ingestor.attributions().length > 0 && (
          <p>منبع قیمت‌ها: {rt.ingestor.attributions().map((a, i) => (<span key={a.name}>{i > 0 && '، '}<a href={a.url} rel="noopener noreferrer" target="_blank">{a.name}</a></span>))}. نرخ‌ها قیمت بازار آزاد تهران‌اند، نه نرخ رسمی بانک مرکزی، و زمان دریافت هر قیمت کنار آن آمده است.</p>
        )}
        <p>{cfg.footerNote}</p>
      </div></footer>
      <BottomNav />
    </>
  );
}
