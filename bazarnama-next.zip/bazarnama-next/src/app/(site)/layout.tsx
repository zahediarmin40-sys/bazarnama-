import Link from 'next/link';
import type { ReactNode } from 'react';
import { Announcement } from '@/components/Announcement';
import { Advertisement } from '@/components/Advertisement';
import { ServiceWorkerRegister } from '@/components/ServiceWorkerRegister';
import { BottomNav } from '@/components/BottomNav';
import { DataBanner } from '@/components/DataBanner';
import { SiteHeader } from '@/components/SiteHeader';
import { NAV } from '@/domain/sections';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export default function SiteLayout({ children }: { children: ReactNode }) {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const date = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full', timeZone: 'Asia/Tehran' }).format(new Date());
  const time = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tehran' }).format(new Date());
  const records = rt.store.all();
  const newest = records.reduce<number>((latest, row) => Math.max(latest, row.updatedAt), 0);
  const isFresh = newest > 0 && Date.now() - newest <= 15 * 60 * 1000;
  const liveStatus = rt.mode === 'demo' ? 'demo' : isFresh ? 'online' : 'waiting';
  const baseNav = cfg.nav.filter((item) => item.visible).map(({ href, label }) => ({ href, label }));
  // Saved configs that predate the calculator page get it added once (admins can still hide it afterwards).
  const calc = NAV.find((n) => n.href === '/calculator');
  const configuredNav = calc && baseNav.length && !cfg.nav.some((n) => n.href === '/calculator')
    ? (() => { const i = baseNav.findIndex((n) => n.href === '/all'); const out = [...baseNav]; out.splice(i < 0 ? out.length : i, 0, calc); return out; })()
    : baseNav;
  return (
    <>
      <a className="skip" href="#main">پرش به محتوا</a>
      <ServiceWorkerRegister />
      <SiteHeader date={date} time={time} liveStatus={liveStatus} nav={configuredNav.length ? configuredNav : NAV} />
      <Announcement a={cfg.announcement} />
      <Advertisement ads={cfg.ads} placement="top" />
      <DataBanner mode={rt.mode} hasData={records.length > 0} />
      <main id="main" tabIndex={-1}><div className="wrap">{children}</div></main>
      <footer className="site"><div className="wrap">
        <div className="footer-brand"><b>بازارنما</b><span>مرجع قیمت طلا، سکه و دلار</span></div>
        <p><Link href="/about">درباره بازارنما</Link><Link href="/about">روش‌شناسی قیمت‌ها</Link><Link href="/about">حریم خصوصی</Link><Link href="/about">تماس با ما</Link><Link href="/about">سلب مسئولیت</Link></p>
        {rt.ingestor.attributions().length > 0 && (
          <p>منبع قیمت‌ها: {rt.ingestor.attributions().map((a, i) => (<span key={a.name}>{i > 0 && '، '}<a href={a.url} rel="noopener noreferrer" target="_blank">{a.name}</a></span>))}. نرخ‌های بازار آزاد از نرخ‌های رسمی جدا نمایش داده می‌شوند.</p>
        )}
        <p>{cfg.footerNote}</p>
      </div></footer>
      <BottomNav />
    </>
  );
}
