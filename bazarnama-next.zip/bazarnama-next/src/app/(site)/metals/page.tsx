import { redirect } from 'next/navigation';
export default function MetalsPage() { redirect('/gold'); }
