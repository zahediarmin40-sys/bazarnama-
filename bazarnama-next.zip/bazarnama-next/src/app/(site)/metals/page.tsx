import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldTabs } from '@/components/GoldTabs';
import { LiveTable } from '@/components/LiveTable';
import { METAL_IDS } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'فلزات جهانی', alternates: { canonical: '/metals' } };

export default function MetalsPage() {
  return (<><Crumbs trail={[['/gold', 'طلا'], [null, 'فلزات جهانی']]} /><h1>فلزات جهانی</h1><p className="lead">قیمت بین‌المللی هر اونس به دلار آمریکا.</p><GoldTabs current="metals" /><LiveTable ids={METAL_IDS} initial={initialFor(METAL_IDS)} /></>);
}
