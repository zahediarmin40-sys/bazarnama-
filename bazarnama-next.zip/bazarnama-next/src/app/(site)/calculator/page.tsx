import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { GoldCalculator } from '@/components/GoldCalculator';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'ماشین حساب طلا', description: 'محاسبه قیمت و ارزش طلا با عیارهای مختلف، اجرت، سود و مالیات و تبدیل عیار.', alternates: { canonical: '/calculator' } };
const IDS = ['gold-24', 'gold-22', 'gold-21', 'gold-18', 'gold-17', 'gold-14', 'gold-melt'];
export default function CalculatorPage() {
  return <><Crumbs trail={[[null, 'ماشین حساب طلا']]}/><div className="page-heading"><div><h1>ماشین حساب طلا</h1><p className="lead">قیمت و ارزش هر وزن طلا را با هر عیار حساب کنید؛ با قیمت زنده، اجرت ساخت، سود و مالیات یا تبدیل عیارها به هم.</p></div></div><GoldCalculator initial={initialFor(IDS)}/></>;
}
