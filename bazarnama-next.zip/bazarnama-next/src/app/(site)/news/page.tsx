import type { Metadata } from 'next';
import Link from 'next/link';
import { ArticleCard } from '@/components/ArticleCard';
import { Crumbs } from '@/components/Crumbs';
import { ExternalNewsCard } from '@/components/ExternalNews';
import { getNews } from '@/server/news';
import { NEWS_CATEGORIES } from '@/server/config/types';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'اخبار اقتصادی', alternates: { canonical: '/news' } };

export default async function NewsPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const c = (await searchParams).c;
  const cat = NEWS_CATEGORIES.find((x) => x === c);
  const all = getRuntime().config.listArticles({ publishedOnly: true });
  const list = cat ? all.filter((a) => a.category === cat) : all;
  const external = cat ? [] : (await getNews().get(4000)).slice(0, 40);
  return (
    <>
      <Crumbs trail={[[null, 'اخبار']]} />
      <h1>اخبار اقتصادی</h1>
      <p className="lead">تیتر، زمان انتشار، دسته‌بندی و منبع هر خبر. اخبار از جدول قیمت‌ها جدا است.</p>
      <div className="tabs" role="navigation" aria-label="دسته‌بندی اخبار">
        <Link href="/news" aria-current={!cat ? 'page' : undefined}>همه</Link>
        {NEWS_CATEGORIES.map((x) => <Link key={x} href={`/news?c=${encodeURIComponent(x)}`} aria-current={cat === x ? 'page' : undefined}>{x}</Link>)}
      </div>
      {external.length > 0 && <section className="blk" aria-labelledby="ext-h"><div className="hd"><h2 id="ext-h">تازه‌ترین خبرها از خبرگزاری‌ها</h2></div><div style={{ display: 'grid', gap: 10 }}>{external.map((n) => <ExternalNewsCard key={n.link} n={n} />)}</div><p className="note">فقط تیتر و چکیده‌ی کوتاه نمایش داده می‌شود؛ متن کامل هر خبر در سایت منبع است و مسئولیت محتوا با همان منبع است.</p></section>}
      {list.length === 0 && external.length === 0 ? <div className="panel empty"><b>خبری برای نمایش نیست.</b><p>هنوز خبری منتشر نشده است.</p></div> : list.length > 0 && <section className="blk">{external.length > 0 && <div className="hd"><h2>یادداشت‌ها و اخبار بازارنما</h2></div>}<div style={{ display: 'grid', gap: 10 }}>{list.map((a) => <ArticleCard key={a.id} a={a} />)}</div></section>}
    </>
  );
}
