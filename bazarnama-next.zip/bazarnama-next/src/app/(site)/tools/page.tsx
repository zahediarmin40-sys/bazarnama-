import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { Tools, TOOL_IDS } from '@/components/Tools';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'محاسبه‌گر بازار', alternates: { canonical: '/tools' } };

export default function ToolsPage() {
  return (<><Crumbs trail={[[null, 'ابزارها']]} /><h1>محاسبه‌گر بازار</h1><p className="lead">محاسبه قیمت طلا بر اساس وزن و عیار، تبدیل ارز و تبدیل واحدهای وزن.</p><Tools initial={initialFor(TOOL_IDS)} /></>);
}
