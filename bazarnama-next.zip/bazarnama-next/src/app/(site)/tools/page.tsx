import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { Tools, TOOL_IDS } from '@/components/Tools';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'ابزارها', alternates: { canonical: '/tools' } };

export default function ToolsPage() {
  return (<><Crumbs trail={[[null, 'ابزارها']]} /><h1>ابزارها</h1><Tools initial={initialFor(TOOL_IDS)} /></>);
}
