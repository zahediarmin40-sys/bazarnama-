import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { Section } from '@/components/Section';

export const metadata: Metadata = { title: 'درباره بازارنما', alternates: { canonical: '/about' } };
export default function AboutPage() {
  return <>
    <Crumbs trail={[[null, 'درباره بازارنما']]} />
    <h1>درباره بازارنما</h1>
    <p className="lead">بازارنما برای مشاهده و مقایسه قیمت طلا، انواع سکه و نرخ‌های ارز طراحی شده است.</p>
    <Section title="شفافیت قیمت‌ها"><div className="panel info-panel"><p>هر قیمت باید همراه با واحد، نوع بازار، منبع و زمان بروزرسانی نمایش داده شود. قیمت بازار آزاد و نرخ مرکز مبادله با یکدیگر ادغام نمی‌شوند.</p><p>در صورت قطع منبع یا قدیمی‌شدن داده، وضعیت آن به‌صورت واضح مشخص می‌شود؛ بازارنما قیمت ساختگی را به‌جای قیمت واقعی نشان نمی‌دهد.</p></div></Section>
    <Section title="محاسبات"><div className="panel info-panel"><p>ابزارهای محاسبه‌گر از نرخ‌های نمایش‌داده‌شده در جدول‌ها استفاده می‌کنند. محاسبه قیمت طلا، اجرت ساخت، سود فروشنده یا مالیات را خودکار شامل نمی‌شود مگر آنکه جداگانه اعلام شده باشد.</p></div></Section>
    <Section title="سلب مسئولیت"><div className="panel info-panel"><p>اطلاعات بازارنما صرفاً جنبه اطلاع‌رسانی دارد و توصیه خرید یا فروش دارایی نیست. پیش از هر تصمیم مالی، قیمت و شرایط معامله را از منبع مربوط بررسی کنید.</p></div></Section>
  </>;
}
