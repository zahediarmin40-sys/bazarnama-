import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { Chart } from '@/components/Chart';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'نمودارهای طلا، سکه و دلار', alternates: { canonical: '/charts' } };
const IDS = ['gold-18', 'fx-usd-free', 'coin-emami', 'gold-24', 'fx-usd-ex'];
export default function ChartsPage() {
  const payload = initialFor(IDS);
  return <>
    <Crumbs trail={[[null, 'نمودارها']]} />
    <h1>نمودارهای قیمت و تحلیل بازار</h1>
    <p className="lead">روند تغییرات قیمت طلا، سکه و دلار را بر پایه داده‌هایی که واقعاً از زمان فعال‌بودن سرویس ذخیره شده‌اند ببینید.</p>
    <div className="chart-grid">{IDS.map((id) => <Chart key={id} assetId={id} record={payload.records.find((r) => r.assetId === id) ?? null} />)}</div>
    <p className="note">تاریخچه فعلی در حافظه سرویس نگهداری می‌شود؛ بعد از راه‌اندازی مجدد سرور ممکن است داده‌های نمودار از نو جمع‌آوری شوند. نمایش سابقه چندماهه نیازمند ذخیره‌سازی پایدار است.</p>
  </>;
}
