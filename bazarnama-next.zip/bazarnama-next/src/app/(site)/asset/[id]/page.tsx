import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { AssetView } from '@/components/AssetView';
import { Crumbs } from '@/components/Crumbs';
import { getAsset } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const a = getAsset((await params).id);
  return a ? { title: `قیمت ${a.name}`, alternates: { canonical: `/asset/${a.id}` } } : { title: 'پیدا نشد' };
}
export default async function AssetPage({ params }: Props) {
  const { id } = await params;
  const a = getAsset(id);
  if (!a) return notFound();
  const parent: [string, string] = a.category === 'gold' ? ['/gold', 'طلا'] : a.category === 'coin' ? ['/coins', 'سکه'] : a.category === 'fx' ? ['/currency', 'ارز'] : ['/metals', 'فلزات جهانی'];
  return (<><Crumbs trail={[parent, [null, a.name]]} /><h1>{a.name}</h1><AssetView id={id} initial={initialFor([id, 'gold-24'])} /></>);
}
