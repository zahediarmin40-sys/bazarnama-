import type { Metadata } from 'next';
import Link from 'next/link';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { fxIds } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'نرخ ارز', alternates: { canonical: '/currency' } };

export default async function CurrencyPage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const type = (await searchParams).t === 'exchange' ? 'exchange' : 'free';
  const ids = fxIds(type);
  return (
    <>
      <Crumbs trail={[[null, 'ارز']]} />
      <h1>نرخ ارز</h1>
      <p className="lead">هر نوع نرخ جدا نمایش داده می‌شود. نرخ‌های بازارهای مختلف هرگز در یک عدد ادغام نمی‌شوند.</p>
      <div className="tabs" role="navigation" aria-label="نوع نرخ">
        <Link href="/currency" aria-current={type === 'free' ? 'page' : undefined}>بازار آزاد</Link>
        <Link href="/currency?t=exchange" aria-current={type === 'exchange' ? 'page' : undefined}>مرکز مبادله</Link>
      </div>
      <LiveTable ids={ids} initial={initialFor(ids)} />
      <p className="note">نرخ حواله، نقدی و سایر انواع پس از تأیید منبع داده اضافه می‌شود. ردیف «ناموجود» یعنی منبع آن نرخ را نداده است. مبدل ارز در صفحه <Link href="/tools">ابزارها</Link> است.</p>
    </>
  );
}
