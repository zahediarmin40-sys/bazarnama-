import type { Metadata } from 'next';
import Link from 'next/link';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { Chart } from '@/components/Chart';
import { Section } from '@/components/Section';
import { fxIds } from '@/domain/catalog';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت دلار و ارز', alternates: { canonical: '/currency' } };
export default async function CurrencyPage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const type = (await searchParams).t === 'exchange' ? 'exchange' : 'free';
  const ids = fxIds(type);
  const dollar = initialFor([type === 'free' ? 'fx-usd-free' : 'fx-usd-ex']);
  return <>
    <Crumbs trail={[[null, 'ارز']]} />
    <h1>قیمت دلار و نرخ ارز</h1>
    <p className="lead">نرخ بازار آزاد و مرکز مبادله را جداگانه ببینید؛ هیچ نرخ متفاوتی در یک عدد ادغام نمی‌شود.</p>
    <div className="tabs" role="navigation" aria-label="نوع نرخ"><Link href="/currency" aria-current={type === 'free' ? 'page' : undefined}>بازار آزاد</Link><Link href="/currency?t=exchange" aria-current={type === 'exchange' ? 'page' : undefined}>مرکز مبادله</Link></div>
    <LiveTable ids={ids} initial={initialFor(ids)} />
    <p className="note">نرخ حواله، نقدی و سایر انواع پس از تأیید منبع داده اضافه می‌شود. ردیف فاقد قیمت به معنی دریافت‌نشدن داده معتبر از منبع است.</p>
    <Section title="نمودار دلار" href="/charts"><Chart assetId={type === 'free' ? 'fx-usd-free' : 'fx-usd-ex'} record={dollar.records[0] ?? null} /></Section>
    <p className="note">برای تبدیل مبالغ ارزی به تومان یا محاسبه ارزش طلا، از <Link href="/tools">محاسبه‌گر بازارنما</Link> استفاده کنید.</p>
  </>;
}
