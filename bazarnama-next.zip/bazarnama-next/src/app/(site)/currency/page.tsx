import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { fxIds } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت دلار و ارز', alternates: { canonical: '/currency' } };
export default function CurrencyPage() {
  const rt = getRuntime();
  const ok = (id: string) => { const r = rt.store.get(id); return !!r && typeof r.price === 'number' && r.price > 0; };
  const free = fxIds('free').filter(ok);
  const exchange = fxIds('exchange').filter(ok);
  const total = free.length + exchange.length;
  return <><Crumbs trail={[[null, 'ارز']]}/><div className="page-heading"><div><h1>قیمت دلار و ارز</h1><p className="lead">نرخ بازار آزاد همه‌ی ارزهای پشتیبانی‌شده‌ی منبع، به‌همراه تتر، نرخ مرکز مبادله و دلار نقدی صرافی‌ها.</p></div><span className="heading-badge">{total.toLocaleString('fa-IR')} نرخ در دسترس</span></div>
    {free.length ? <section className="blk"><div className="hd"><h2>بازار آزاد</h2></div><LiveTable ids={free} initial={initialFor(free)} filterable/></section> : <div className="panel empty"><b>هنوز نرخ ارز از منبع دریافت نشده است.</b><p>نرخ‌های تأییدنشده یا فاقد قیمت از فهرست حذف شده‌اند.</p></div>}
    {exchange.length > 0 && <section className="blk"><div className="hd"><h2>مرکز مبادله و صرافی</h2></div><LiveTable ids={exchange} initial={initialFor(exchange)}/></section>}
    <p className="note">قیمت هر ردیف برای یک واحد از همان ارز است. نرخ ارزهای غیر از دلار از روی دلار آزاد و نرخ‌های جهانی محاسبه می‌شود و در ستون «نوع بازار» با برچسب «محاسبه‌شده» مشخص است.</p></>;
}
