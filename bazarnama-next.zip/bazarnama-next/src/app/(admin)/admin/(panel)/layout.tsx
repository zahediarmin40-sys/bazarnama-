import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';
import { AdminNav } from '@/components/admin/AdminNav';
import { LogoutButton } from '@/components/admin/LogoutButton';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';

export const dynamic = 'force-dynamic';
const ROLE: Record<string, string> = { admin: 'مدیر کل', editor: 'ویراستار', operator: 'اپراتور داده' };

export default async function PanelLayout({ children }: { children: ReactNode }) {
  const s = await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET);
  if (!s) return redirect('/admin/login');
  return (
    <div className="adm">
      <aside className="adm-side">
        <a className="adm-brand" href="/admin">
          <svg width="34" height="34" viewBox="0 0 30 30" aria-hidden="true"><rect x="2" y="2" width="26" height="26" rx="8" fill="#161C25" stroke="#D9AA45" /><path d="M8 20l5-6 4 3 5-8" fill="none" stroke="#D9AA45" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
          <span>بازارنما<small>پنل مدیریت</small></span>
        </a>
        <AdminNav />
        <div className="sp" />
        <div className="adm-me"><b>{s.sub}</b><span className="adm-role">{ROLE[s.role] ?? s.role}</span></div>
        <LogoutButton />
      </aside>
      <div className="adm-main">{children}</div>
    </div>
  );
}
