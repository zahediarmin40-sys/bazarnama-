import type { Metadata } from 'next';
import Link from 'next/link';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { StatsPanel, type Stats } from '@/components/admin/StatsPanel';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'داشبورد مدیریت', robots: { index: false, follow: false } };

export default async function Dashboard() {
  const s = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  const rt = getRuntime();
  const feeds = rt.ingestor.health();
  const stats: Stats = { mode: rt.mode, records: rt.store.size(), sse: rt.sse.open, bucketSec: rt.meter.bucketMs() / 1000, activity: rt.meter.series(), feedsOk: feeds.filter((f) => f.enabled && f.configured && f.consecutiveFailures === 0 && f.lastOkAt).length, feedsTotal: feeds.length, articles: rt.config.listArticles().length, time: Date.now() };
  const hour = Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: 'Asia/Tehran' }).format(new Date()));
  const greet = hour < 5 ? 'شب بخیر' : hour < 12 ? 'صبح بخیر' : hour < 17 ? 'ظهر بخیر' : hour < 21 ? 'عصر بخیر' : 'شب بخیر';
  return (
    <>
      <Hero title={`${greet}، مدیر عزیز`} text={`وارد شده با ${s.sub}. از اینجا ظاهر سایت، اخبار و منابع قیمت را کنترل می‌کنید.`} />
      <div className="adm-body">
        <StatsPanel initial={stats} />
        <div className="adm-grid adm-two" style={{ marginTop: 16 }}>
          <div className="adm-card">
            <h2>میانبرها</h2>
            <div className="adm-row">
              {can(s.role, 'content:edit') && <><Link className="adm-btn pri" href="/admin/site">ویرایش ظاهر سایت</Link><Link className="adm-btn" href="/admin/news">مدیریت اخبار</Link></>}
              <Link className="adm-btn" href="/admin/providers">منابع قیمت</Link>
              <Link className="adm-btn" href="/" target="_blank">مشاهده سایت</Link>
            </div>
          </div>
          <div className="adm-card">
            <h2>آخرین رویدادها</h2>
            {rt.audit.list(5).length === 0 ? <p className="note">رویدادی ثبت نشده است.</p> : <ul className="adm-list">{rt.audit.list(5).map((e) => <li key={`${e.t}-${e.action}-${e.target}`} className="adm-item"><span className="grow"><b>{e.action}</b><div className="note num" style={{ margin: 0 }}>{e.actor} · {e.target}</div></span></li>)}</ul>}
          </div>
        </div>
      </div>
    </>
  );
}
