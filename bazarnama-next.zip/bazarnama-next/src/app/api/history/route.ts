import { NextResponse, type NextRequest } from 'next/server';
import { getAsset } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

/** Real recorded points only (in-memory price book). Never interpolated or invented. */
export function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get('id') ?? '';
  if (!/^[a-z0-9-]{1,40}$/.test(id) || !getAsset(id)) return NextResponse.json({ error: 'unknown asset' }, { status: 400 });
  const points = getRuntime().store.history(id);
  return NextResponse.json({ id, points }, { headers: { 'Cache-Control': 'public, s-maxage=5, stale-while-revalidate=10' } });
}
