import { NextResponse } from 'next/server';
import { getAsset } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

/** In-memory session history. Persisted history requires provider licence/retention terms (see README). */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!getAsset(id)) return NextResponse.json({ error: 'not-found' }, { status: 404 });
  const rt = getRuntime();
  return NextResponse.json({ mode: rt.mode, points: rt.store.history(id) });
}
