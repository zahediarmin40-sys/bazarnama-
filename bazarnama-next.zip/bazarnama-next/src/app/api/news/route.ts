import { NextResponse } from 'next/server';
import { getNews } from '@/server/news';

export const dynamic = 'force-dynamic';
/** Headlines from the configured RSS feeds + per-feed health (use it to verify NEWS_FEEDS). */
export async function GET() {
  const agg = getNews();
  const items = await agg.get(4000);
  return NextResponse.json({ items, feeds: agg.health() }, { headers: { 'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=300' } });
}
