// Usage: npm run hash-password -- you@example.com [--totp]
// Prompts for the password (hidden), then prints the ADMIN_USERS entry. With --totp it also creates a 2FA secret.
import { randomBytes, scrypt } from 'node:crypto';
import readline from 'node:readline';

const email = process.argv[2]?.trim().toLowerCase();
const wantTotp = process.argv.includes('--totp');
if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { console.error('usage: npm run hash-password -- you@example.com [--totp]'); process.exit(1); }

function ask(q) {
  return new Promise((res) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(q)) process.stdout.write(s); else if (s === '\r\n' || s === '\n') process.stdout.write(s); };
    rl.question(q, (a) => { rl.close(); res(a); });
  });
}
const b32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const base32 = (buf) => { let bits = 0, v = 0, o = ''; for (const b of buf) { v = (v << 8) | b; bits += 8; while (bits >= 5) { o += b32[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits) o += b32[(v << (5 - bits)) & 31]; return o; };

const pw = await ask('Password (min 12 chars): ');
if (pw.length < 12) { console.error('Password must be at least 12 characters.'); process.exit(1); }
const pw2 = await ask('Repeat password: ');
if (pw !== pw2) { console.error('Passwords differ.'); process.exit(1); }
const N = 16384, salt = randomBytes(16);
const key = await new Promise((res, rej) => scrypt(pw, salt, 64, { N }, (e, k) => (e ? rej(e) : res(k))));
const entry = { email, hash: `scrypt$${N}$${salt.toString('base64')}$${key.toString('base64')}`, role: 'admin' };
if (wantTotp) {
  entry.totpSecret = base32(randomBytes(20));
  console.log(`\n2FA secret (add to your authenticator app): ${entry.totpSecret}`);
  console.log(`otpauth://totp/Bazarnama:${encodeURIComponent(email)}?secret=${entry.totpSecret}&issuer=Bazarnama&digits=6&period=30`);
}
console.log('\nPut this in .env (single line):');
console.log(`ADMIN_USERS=${JSON.stringify([entry])}`);
console.log(`ADMIN_OWNER_EMAIL=${email}`);
console.log('ADMIN_JWT_SECRET=<run: openssl rand -base64 48>');
