# بازارنما | Bazarnama

A Persian, mobile-first price portal for supported Iranian gold, coins and currency markets, built with Next.js 15 and React 19.

## Deploy on Render

The GitHub repository's root should contain both `render.yaml` and the source archive named `bazarnama-next.zip`. The Blueprint build command extracts that archive and builds the Next.js app.

1. Upload `bazarnama-next.zip` to the root of your GitHub repository (do not extract it in GitHub).
2. In Render, choose **New + → Blueprint**, connect the GitHub repository, and apply the `render.yaml` blueprint.
3. Wait for the first build. The service health check is `/api/health`.

### First-time admin setup

1. On your computer, extract the archive, open the `bazarnama-next` folder and run `npm install`.
2. Run `npm run hash-password -- your-admin-email@example.com --totp` and follow the prompts. Use a unique password of at least 12 characters.
3. In Render → your service → Environment, set `ADMIN_OWNER_EMAIL` to that email and `ADMIN_USERS` to the complete JSON line printed by the script. Keep `ADMIN_JWT_SECRET` secret (Render generates it). Never commit these values to GitHub.
4. Save changes and redeploy. Sign in at `/admin` with email, password and your authenticator code.

## Local development

Requirements: Node.js 22.6 or newer.

```bash
cd bazarnama-next
cp .env.example .env
npm install
npm run dev
```

- Website: `http://localhost:3000`
- Admin: `http://localhost:3000/admin`
- Health: `http://localhost:3000/api/health`

## Website sections and admin features

The public website has separate pages for Home, Gold, Coins, Currency, the complete price table, Economic News, Guide and About. The homepage follows the supplied dark navy/gold dashboard reference. Public charts, market analysis and gold calculators are intentionally omitted. Items without a valid provider quote are hidden from price tables, homepage cards, search and the sitemap. A personal watchlist is stored in the visitor's browser.

The admin panel includes site layout and announcement settings, news management, provider health, audit events and an advertising manager. Ads support an image URL, click-through destination, placement (top/home/footer), enable/disable controls and scheduled start/end times. On Render Free, those admin settings are stored under `/tmp` and may be lost after restarts; durable campaigns require persistent storage.

## Prices and data accuracy

The Render blueprint enables NerkhAra. Its feed is periodically refreshed (not tick-by-tick); the UI should preserve the provider timestamp and delayed/stale status. Do not describe these quotes as exchange-executable prices. Some values are derived/indicative and are labelled accordingly. Assets without a provider mapping remain unavailable rather than being filled with fabricated prices.

## Important limitations of the Render Free deployment

- Render Free web services can spin down after inactivity. While asleep, the app cannot poll its price provider; after wake-up, the feed needs time to refresh. This is not a continuously running real-time ticker.
- The Free service has no persistent disk. `DATA_DIR=/tmp/bazarnama-data` is temporary: admin-edited site settings and news can be lost after restart/redeploy. Do not use the Free plan for durable editorial data. A persistent disk or a properly wired external database is required before treating the admin CMS as production storage.
- The price store, event bus and audit log are in memory and are designed for one running instance. Do not scale horizontally without moving these to shared infrastructure.
- `prisma/schema.prisma` is a starting schema; Prisma persistence is not yet wired into the application.

## Checks

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

The source test suite can run on Node 22 without installing the Next.js dependencies:

```bash
node --test --experimental-strip-types 'src/**/*.test.ts'
```

## Security

- Never commit `.env`, `ADMIN_USERS`, API keys, passwords, TOTP secrets or `ADMIN_JWT_SECRET`.
- Use HTTPS and a strong unique admin password; enable TOTP.
- Review provider terms, rate limits and attribution requirements before production use.

## Architecture

`NerkhAra → provider adapter → validation/policy → in-memory price store → SSE/API → UI`

The codebase separates `src/core` (pure calculations and validation), `src/domain` (asset catalog), `src/server` (providers, ingestion, auth and configuration), and `src/app` (Next.js routes and pages).
