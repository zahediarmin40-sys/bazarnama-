import type { MetadataRoute } from 'next';
import { ASSETS } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://bazarnama.onrender.com';
  const rt = getRuntime();
  const availableIds = new Set(rt.store.all().filter((r) => typeof r.price === 'number' && r.price > 0).map((r) => r.assetId));
  const paths = ['', '/all', '/gold', '/coins', '/currency', '/about', '/guide', '/news', ...rt.config.listArticles({ publishedOnly: true }).map((a) => `/news/${a.slug}`), ...ASSETS.filter((a) => availableIds.has(a.id)).map((a) => `/asset/${a.id}`)];
  return paths.map((p) => ({ url: `${base}${p}`, changeFrequency: p.startsWith('/asset') || p === '' ? 'hourly' : 'daily' }));
}
