import type { Metadata } from 'next';
import Link from 'next/link';
import { ArticleCard } from '@/components/ArticleCard';
import { Crumbs } from '@/components/Crumbs';
import { NEWS_CATEGORIES } from '@/server/config/types';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'اخبار اقتصادی', alternates: { canonical: '/news' } };

export default async function NewsPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const c = (await searchParams).c;
  const cat = NEWS_CATEGORIES.find((x) => x === c);
  const all = getRuntime().config.listArticles({ publishedOnly: true });
  const list = cat ? all.filter((a) => a.category === cat) : all;
  return (
    <>
      <Crumbs trail={[[null, 'اخبار']]} />
      <h1>اخبار اقتصادی</h1>
      <p className="lead">تیتر، زمان انتشار، دسته‌بندی و منبع هر خبر. اخبار از جدول قیمت‌ها جدا است.</p>
      <div className="tabs" role="navigation" aria-label="دسته‌بندی اخبار">
        <Link href="/news" aria-current={!cat ? 'page' : undefined}>همه</Link>
        {NEWS_CATEGORIES.map((x) => <Link key={x} href={`/news?c=${encodeURIComponent(x)}`} aria-current={cat === x ? 'page' : undefined}>{x}</Link>)}
      </div>
      {list.length === 0 ? <div className="panel empty"><b>خبری برای نمایش نیست.</b><p>هنوز خبری منتشر نشده است.</p></div> : <div style={{ display: 'grid', gap: 10 }}>{list.map((a) => <ArticleCard key={a.id} a={a} />)}</div>}
    </>
  );
}
