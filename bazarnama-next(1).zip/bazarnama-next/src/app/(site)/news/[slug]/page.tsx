import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { faDate } from '@/components/ArticleCard';
import { Crumbs } from '@/components/Crumbs';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const a = getRuntime().config.getArticleBySlug((await params).slug);
  return a ? { title: a.title, description: a.summary, alternates: { canonical: `/news/${a.slug}` } } : { title: 'پیدا نشد' };
}
export default async function ArticlePage({ params }: Props) {
  const a = getRuntime().config.getArticleBySlug((await params).slug);
  if (!a) return notFound();
  const paragraphs = a.body.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
  return (
    <>
      <Crumbs trail={[['/news', 'اخبار'], [null, a.title]]} />
      <article style={{ maxWidth: '70ch' }}>
        <h1>{a.title}</h1>
        <div className="mini" style={{ marginTop: 0 }}><span className="chip">{a.category}</span><time dateTime={new Date(a.publishedAt).toISOString()}>انتشار: {faDate(a.publishedAt)}</time>{a.updatedAt - a.publishedAt > 60_000 && <span>· بروزرسانی: {faDate(a.updatedAt)}</span>}<span>· منبع: {a.source}</span></div>
        <p className="lead" style={{ marginTop: 14 }}>{a.summary}</p>
        {paragraphs.map((p, i) => <p key={i} style={{ lineHeight: 2 }}>{p}</p>)}
      </article>
    </>
  );
}
