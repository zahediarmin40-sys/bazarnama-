import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { fxIds } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت دلار و ارز', alternates: { canonical: '/currency' } };
export default function CurrencyPage() {
  const rt = getRuntime();
  const all = [...fxIds('free'), ...fxIds('exchange')];
  const ids = all.filter((id) => { const r = rt.store.get(id); return !!r && typeof r.price === 'number' && r.price > 0; });
  return <><Crumbs trail={[[null, 'ارز']]}/><div className="page-heading"><div><h1>قیمت دلار و ارز</h1><p className="lead">نرخ‌های بازار آزاد و مرکز مبادله، فقط برای ارزهایی که منبع آن‌ها قیمت معتبر ارائه می‌کند.</p></div><span className="heading-badge">{ids.length} نرخ در دسترس</span></div>{ids.length ? <LiveTable ids={ids} initial={initialFor(ids)}/> : <div className="panel empty"><b>هنوز نرخ ارز از منبع دریافت نشده است.</b><p>نرخ‌های تأییدنشده یا فاقد قیمت از فهرست حذف شده‌اند.</p></div>}<p className="note">نرخ بازار آزاد و مرکز مبادله به‌صورت ردیف‌های جداگانه نمایش داده می‌شوند.</p></>;
}
