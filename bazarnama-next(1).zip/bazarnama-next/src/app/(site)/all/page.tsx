import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { GOLD_IDS, COIN_IDS, fxIds } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'جدول قیمت‌ها', alternates: { canonical: '/all' } };
export default function AllPage() {
  const rt = getRuntime();
  const all = [...GOLD_IDS, ...COIN_IDS, ...fxIds('free'), ...fxIds('exchange'), 'gold-ounce'];
  const ids = all.filter((id) => { const r = rt.store.get(id); return !!r && typeof r.price === 'number' && r.price > 0; });
  return <><Crumbs trail={[[null, 'جدول قیمت‌ها']]}/><div className="page-heading"><div><h1>جدول کامل قیمت‌ها</h1><p className="lead">همه نرخ‌های معتبر طلا، سکه و ارز در یک جدول؛ بدون ردیف‌های فاقد قیمت.</p></div><span className="heading-badge">{ids.length} قیمت دریافت‌شده</span></div><div className="filter-strip"><span>طلا</span><span>سکه</span><span>دلار و ارز</span></div>{ids.length ? <LiveTable ids={ids} initial={initialFor(ids)}/> : <div className="panel empty"><b>هنوز قیمتی از منابع دریافت نشده است.</b><p>به محض دریافت قیمت معتبر، ردیف‌ها در این جدول قرار می‌گیرند.</p></div>}</>;
}
