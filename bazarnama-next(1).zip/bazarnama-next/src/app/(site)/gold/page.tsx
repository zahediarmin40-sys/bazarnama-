import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { GOLD_IDS } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت طلا', alternates: { canonical: '/gold' } };
export default function GoldPage() {
  const rt = getRuntime();
  const ids = [...GOLD_IDS, 'gold-ounce'].filter((id) => { const r = rt.store.get(id); return !!r && typeof r.price === 'number' && r.price > 0; });
  return <><Crumbs trail={[[null, 'طلا']]}/><div className="page-heading"><div><h1>قیمت انواع طلا</h1><p className="lead">قیمت عیارها و انواع طلای دارای داده معتبر، همراه با واحد و زمان بروزرسانی.</p></div><span className="heading-badge">{ids.length} نرخ در دسترس</span></div>{ids.length ? <LiveTable ids={ids} initial={initialFor(ids)}/> : <div className="panel empty"><b>قیمت طلا هنوز از منبع دریافت نشده است.</b><p>ردیف‌هایی که قیمت معتبر ندارند در این صفحه نمایش داده نمی‌شوند.</p></div>}<p className="note">قیمت‌های این صفحه بر اساس داده‌های منبع هستند؛ اجرت، مالیات و سود فروشنده در آن‌ها لحاظ نشده است.</p></>;
}
