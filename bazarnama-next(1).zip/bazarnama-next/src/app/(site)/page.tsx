import Link from 'next/link';
import { LiveTable } from '@/components/LiveTable';
import { Snapshot } from '@/components/Snapshot';
import { Advertisement } from '@/components/Advertisement';
import { SearchBox } from '@/components/SearchBox';
import { Watchlist } from '@/components/Watchlist';
import { GOLD_IDS, COIN_IDS, fxIds } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';

export const dynamic = 'force-dynamic';
const TABLE_ORDER = [...GOLD_IDS, ...COIN_IDS, ...fxIds('free'), ...fxIds('exchange'), 'gold-ounce'];

function Hero() {
  return <section className="hero" aria-labelledby="hero-title">
    <div className="hero-art" aria-hidden="true"/>
    <div className="hero-copy"><h1 id="hero-title">قیمت لحظه‌ای <em>طلا و دلار</em></h1><p>همیشه به‌روز، شفاف و دقیق</p>
      <ul className="hero-checks"><li>عیارهای دارای قیمت معتبر</li><li>سکه‌ها و ارزهای پشتیبانی‌شده</li><li>منبع و زمان آخرین دریافت</li></ul>
      <Link href="/all" className="hero-cta">سریع، دقیق، مطمئن <b>⚡</b></Link></div>
  </section>;
}

export default function Home() {
  const rt = getRuntime();
  const cfg = rt.config.getConfig();
  const validRecords = rt.store.all().filter((r) => typeof r.price === 'number' && r.price > 0);
  const valid = new Set(validRecords.map((r) => r.assetId));
  const latestUpdate = validRecords.reduce<number | null>((latest, row) => latest === null || row.updatedAt > latest ? row.updatedAt : latest, null);
  const cards = cfg.snapshotIds.filter((id) => valid.has(id)).slice(0, 5);
  const availableIds = [...valid];
  const tableIds = TABLE_ORDER.filter((id) => valid.has(id)).slice(0, 7);
  const news = rt.config.listArticles({ publishedOnly: true }).slice(0, 3);
  const enabledModules = new Set(cfg.homeModules.filter((m) => m.enabled).map((m) => m.id));
  const sections = [
    { href: '/gold', title: 'قیمت طلا', detail: 'عیارهای دارای قیمت معتبر', icon: '◈' },
    { href: '/coins', title: 'قیمت سکه', detail: 'امامی، طرح قدیم، نیم، ربع و گرمی', icon: '◉' },
    { href: '/currency', title: 'قیمت دلار و ارز', detail: 'نرخ‌های دریافت‌شده از منابع', icon: '⇄' },
  ];
  return <>
    <Hero/>
    <Advertisement ads={cfg.ads} placement="home"/>
    <div className="dashboard-intro"><b>قیمت‌های منتخب بازار</b><span className="market-hint">فقط قیمت‌های دریافت‌شده از منبع معتبر نمایش داده می‌شوند.</span><SearchBox availableIds={availableIds}/></div>
    {enabledModules.has('snapshot') && (cards.length ? <Snapshot ids={cards} initial={initialFor(cards)}/> : <div className="panel empty price-empty"><b>در حال دریافت قیمت‌های بازار</b><p>به‌محض دریافت داده معتبر، قیمت‌ها در همین قسمت نمایش داده می‌شوند.</p></div>)}
    <Watchlist availableIds={availableIds}/>
    <section className={`dashboard-grid ${enabledModules.has('news') ? 'has-news' : 'without-news'}`} aria-label="نمای کلی بازار">
      <div className="dashboard-table panel"><div className="panel-head"><h2>جدول کامل قیمت‌ها</h2><Link href="/all">مشاهده همه ←</Link></div>
        {tableIds.length ? <div className="home-table"><LiveTable ids={tableIds} initial={initialFor(tableIds)}/></div> : <div className="news-empty">هنوز قیمت معتبری دریافت نشده است.</div>}
      </div>
      <div className="dashboard-links panel"><div className="panel-head"><h2>دسته‌بندی‌های بازار</h2><span className="gold-icon">▦</span></div>
        <div className="market-shortcuts-grid">{sections.map((s) => {
          const count = s.href === '/gold' ? [...GOLD_IDS, 'gold-ounce'].filter((id) => valid.has(id)).length : s.href === '/coins' ? COIN_IDS.filter((id) => valid.has(id)).length : [...fxIds('free'), ...fxIds('exchange')].filter((id) => valid.has(id)).length;
          return <Link className="market-shortcut" key={s.href} href={s.href}><span className="shortcut-icon">{s.icon}</span><span><b>{s.title}</b><small>{s.detail}</small><small className="shortcut-count">{count.toLocaleString('fa-IR')} نرخ در دسترس</small></span><i>←</i></Link>;
        })}</div>
        <div className="market-update-strip"><span className="update-dot"/><span><b>وضعیت داده‌های بازار</b><small>{latestUpdate ? `آخرین دریافت: ${new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tehran' }).format(latestUpdate)}` : 'هنوز داده معتبری دریافت نشده است'}</small></span><strong>{valid.size.toLocaleString('fa-IR')} نرخ</strong></div>
        <div className="market-tools-links"><Link href="/all">جدول جامع قیمت‌ها</Link><Link href="/guide">راهنمای استفاده</Link><Link href="/news">اخبار اقتصادی</Link></div>
      </div>
      {enabledModules.has('news') && <aside className="dashboard-news panel"><div className="panel-head"><h2>آخرین اخبار اقتصادی</h2><Link href="/news">مشاهده همه</Link></div>
        {news.length ? news.map((article) => <div className="home-news-item" key={article.id}><b>{article.title}</b><small>{article.summary}</small></div>) : <div className="news-empty">خبر مرتبطی برای نمایش ثبت نشده است.</div>}
      </aside>}
    </section>
    <Advertisement ads={cfg.ads} placement="footer"/>
    <section className="trust-row" aria-label="ویژگی‌های بازارنما">
      <div><b>◉</b><span>نمایش منبع قیمت</span></div><div><b>✓</b><span>اطلاعات معتبر و شفاف</span></div><div><b>⚡</b><span>بروزرسانی خودکار قیمت‌ها</span></div><div><b>▣</b><span>رابط کاربری ساده و سریع</span></div><div><b>♡</b><span>همراه شما در بازار</span></div>
    </section>
  </>;
}
