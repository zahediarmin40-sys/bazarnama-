import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { LiveTable } from '@/components/LiveTable';
import { COIN_IDS } from '@/domain/catalog';
import { getRuntime } from '@/server/ingest/runtime';
import { initialFor } from '@/app/initial';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'قیمت سکه', alternates: { canonical: '/coins' } };
export default function CoinsPage() {
  const rt = getRuntime();
  const ids = COIN_IDS.filter((id) => { const r = rt.store.get(id); return !!r && typeof r.price === 'number' && r.price > 0; });
  return <><Crumbs trail={[[null, 'سکه']]}/><div className="page-heading"><div><h1>قیمت انواع سکه</h1><p className="lead">قیمت سکه‌های دارای داده معتبر را در یک جدول مقایسه کنید.</p></div><span className="heading-badge">{ids.length} نرخ در دسترس</span></div>{ids.length ? <LiveTable ids={ids} initial={initialFor(ids)}/> : <div className="panel empty"><b>قیمت سکه هنوز از منبع دریافت نشده است.</b><p>سکه‌هایی که قیمت معتبر ندارند نمایش داده نمی‌شوند.</p></div>}</>;
}
