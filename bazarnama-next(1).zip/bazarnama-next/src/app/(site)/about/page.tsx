import type { Metadata } from 'next';
import { Crumbs } from '@/components/Crumbs';
import { Section } from '@/components/Section';

export const metadata: Metadata = { title: 'درباره بازارنما', alternates: { canonical: '/about' } };
export default function AboutPage() {
  return <>
    <Crumbs trail={[[null, 'درباره بازارنما']]} />
    <h1>درباره بازارنما</h1>
    <p className="lead">بازارنما برای مشاهده و مقایسه قیمت طلا، انواع سکه و نرخ‌های ارز طراحی شده است.</p>
    <Section title="شفافیت قیمت‌ها"><div className="panel info-panel"><p>هر قیمت باید همراه با واحد، نوع بازار، منبع و زمان بروزرسانی نمایش داده شود. قیمت بازار آزاد و نرخ مرکز مبادله با یکدیگر ادغام نمی‌شوند.</p><p>در صورت قطع منبع یا قدیمی‌شدن داده، وضعیت آن به‌صورت واضح مشخص می‌شود؛ بازارنما قیمت ساختگی را به‌جای قیمت واقعی نشان نمی‌دهد.</p></div></Section>
    <Section title="دامنه پوشش"><div className="panel info-panel"><p>تمرکز بازارنما بر قیمت طلا، سکه و ارزهای پشتیبانی‌شده است. هر مورد فقط زمانی در جدول‌ها قرار می‌گیرد که منبع داده، نرخ معتبر و زمان دریافت آن را ارائه کرده باشد.</p></div></Section>
    <Section title="سلب مسئولیت"><div className="panel info-panel"><p>اطلاعات بازارنما صرفاً جنبه اطلاع‌رسانی دارد و توصیه خرید یا فروش دارایی نیست. پیش از هر تصمیم مالی، قیمت و شرایط معامله را از منبع مربوط بررسی کنید.</p></div></Section>
  </>;
}
