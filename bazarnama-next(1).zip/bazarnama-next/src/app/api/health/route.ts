import { NextResponse } from 'next/server';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

/** Liveness + minimal feed summary. Provider errors/details are admin-only. */
export function GET() {
  const rt = getRuntime();
  return NextResponse.json({ ok: true, mode: rt.mode, records: rt.store.size(), sseConnections: rt.sse.open, time: Date.now() });
}
