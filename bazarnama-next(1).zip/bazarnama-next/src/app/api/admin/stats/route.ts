import { NextResponse, type NextRequest } from 'next/server';
import { requireAdmin } from '@/server/auth/guard';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const g = await requireAdmin(req, 'providers:view');
  if (!g.ok) return g.res;
  const rt = getRuntime();
  const feeds = rt.ingestor.health();
  return NextResponse.json({
    mode: rt.mode, records: rt.store.size(), sse: rt.sse.open, bucketSec: rt.meter.bucketMs() / 1000, activity: rt.meter.series(),
    feedsOk: feeds.filter((f) => f.enabled && f.configured && f.consecutiveFailures === 0 && f.lastOkAt).length, feedsTotal: feeds.length,
    articles: rt.config.listArticles().length, time: Date.now(),
  });
}
