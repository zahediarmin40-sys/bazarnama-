import { NextResponse } from 'next/server';
import { SESSION_COOKIE } from '@/server/auth/session';

export function POST() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
  return res;
}
