import { NextResponse, type NextRequest } from 'next/server';
import { errorResponse, requireAdmin } from '@/server/auth/guard';
import { can } from '@/server/auth/rbac';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const g = await requireAdmin(req, 'providers:view');
  if (!g.ok) return g.res;
  const rt = getRuntime();
  return NextResponse.json({ mode: rt.mode, hasDemo: Boolean(rt.demo), outage: rt.demo?.outage ?? false, providers: rt.ingestor.health(), audit: can(g.session.role, 'audit:view') ? rt.audit.list(30) : [] });
}

/** Body: { id, enabled? } or { id: 'demo', outage? } */
export async function POST(req: NextRequest) {
  const g = await requireAdmin(req, 'providers:manage');
  if (!g.ok) return g.res;
  try {
    const b = (await req.json().catch(() => null)) as { id?: unknown; enabled?: unknown; outage?: unknown } | null;
    if (typeof b?.id !== 'string') return NextResponse.json({ error: 'bad-request' }, { status: 400 });
    const rt = getRuntime();
    if (typeof b.enabled === 'boolean') {
      if (!rt.ingestor.setEnabled(b.id, b.enabled)) return NextResponse.json({ error: 'unknown-provider' }, { status: 404 });
      rt.audit.record({ actor: g.session.sub, action: b.enabled ? 'provider.enable' : 'provider.disable', target: b.id });
    }
    if (typeof b.outage === 'boolean' && b.id === 'demo' && rt.demo) {
      rt.demo.outage = b.outage;
      rt.audit.record({ actor: g.session.sub, action: 'demo.outage', target: String(b.outage) });
    }
    return NextResponse.json({ ok: true, outage: rt.demo?.outage ?? false, providers: rt.ingestor.health() });
  } catch (e) { return errorResponse(e); }
}
