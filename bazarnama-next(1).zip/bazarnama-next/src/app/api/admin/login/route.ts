import { NextResponse } from 'next/server';
import { authenticate, normalizeEmail, parseUsers } from '@/server/auth/users';
import { sameOrigin } from '@/server/auth/origin';
import { SESSION_COOKIE, SESSION_TTL_SEC, signSession } from '@/server/auth/session';
import { env } from '@/server/env';
import { getRuntime } from '@/server/ingest/runtime';

export async function POST(req: Request) {
  const e = env();
  if (!e.ADMIN_JWT_SECRET) return NextResponse.json({ error: 'admin-disabled' }, { status: 503 });
  if (!sameOrigin(req.headers.get('origin'), req.headers.get('host'))) return NextResponse.json({ error: 'bad-origin' }, { status: 403 });
  const rt = getRuntime();
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
  const lim = rt.loginLimiter.check(ip);
  if (!lim.ok) return NextResponse.json({ error: 'too-many-attempts' }, { status: 429, headers: { 'Retry-After': String(lim.retryAfterSec) } });
  const b = (await req.json().catch(() => null)) as { email?: unknown; password?: unknown; code?: unknown } | null;
  if (typeof b?.email !== 'string' || typeof b?.password !== 'string' || b.password.length > 200 || b.email.length > 200) return NextResponse.json({ error: 'bad-request' }, { status: 400 });
  const email = normalizeEmail(b.email);
  const r = await authenticate(parseUsers(e.ADMIN_USERS, e.ADMIN_OWNER_EMAIL), email, b.password, typeof b.code === 'string' ? b.code : undefined);
  if (r.status === 'totp-required') return NextResponse.json({ error: 'totp-required' }, { status: 401 });
  rt.audit.record({ actor: email.slice(0, 80), action: r.status === 'ok' ? 'login.ok' : 'login.fail', target: ip });
  if (r.status !== 'ok') return NextResponse.json({ error: 'invalid-credentials' }, { status: 401 });
  const token = await signSession({ sub: r.user.email, role: r.user.role }, e.ADMIN_JWT_SECRET);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, secure: e.NODE_ENV === 'production', sameSite: 'strict', path: '/', maxAge: SESSION_TTL_SEC });
  return res;
}
