import { NextResponse, type NextRequest } from 'next/server';
import { errorResponse, requireAdmin } from '@/server/auth/guard';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  return NextResponse.json({ config: getRuntime().config.getConfig() });
}
export async function PUT(req: NextRequest) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  try {
    const rt = getRuntime();
    const config = rt.config.updateConfig(await req.json());
    rt.audit.record({ actor: g.session.sub, action: 'config.update', target: 'site' });
    return NextResponse.json({ config });
  } catch (e) { return errorResponse(e); }
}
/** POST = reset to defaults */
export async function POST(req: NextRequest) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  const rt = getRuntime();
  const config = rt.config.resetConfig();
  rt.audit.record({ actor: g.session.sub, action: 'config.reset', target: 'site' });
  return NextResponse.json({ config });
}
