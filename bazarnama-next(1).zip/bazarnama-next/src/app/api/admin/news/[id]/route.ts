import { NextResponse, type NextRequest } from 'next/server';
import { errorResponse, requireAdmin } from '@/server/auth/guard';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  try {
    const { id } = await ctx.params;
    const rt = getRuntime();
    const body = (await req.json()) as { published?: unknown };
    const cur = rt.config.getArticle(id);
    if (cur && cur.published !== (body?.published === true) && !(await requireAdmin(req, 'news:publish')).ok) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
    const article = rt.config.updateArticle(id, body);
    if (!article) return NextResponse.json({ error: 'not-found' }, { status: 404 });
    rt.audit.record({ actor: g.session.sub, action: 'news.update', target: article.slug });
    return NextResponse.json({ article });
  } catch (e) { return errorResponse(e); }
}
export async function DELETE(req: NextRequest, ctx: Ctx) {
  const g = await requireAdmin(req, 'news:publish');
  if (!g.ok) return g.res;
  const { id } = await ctx.params;
  const rt = getRuntime();
  const a = rt.config.getArticle(id);
  if (!rt.config.deleteArticle(id)) return NextResponse.json({ error: 'not-found' }, { status: 404 });
  rt.audit.record({ actor: g.session.sub, action: 'news.delete', target: a?.slug ?? id });
  return NextResponse.json({ ok: true });
}
