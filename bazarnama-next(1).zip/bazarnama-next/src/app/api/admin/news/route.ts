import { NextResponse, type NextRequest } from 'next/server';
import { errorResponse, requireAdmin } from '@/server/auth/guard';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  return NextResponse.json({ articles: getRuntime().config.listArticles() });
}
export async function POST(req: NextRequest) {
  const g = await requireAdmin(req, 'content:edit');
  if (!g.ok) return g.res;
  try {
    const rt = getRuntime();
    const body = (await req.json()) as { published?: unknown };
    if (body?.published === true && !(await requireAdmin(req, 'news:publish')).ok) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
    const article = rt.config.createArticle(body);
    rt.audit.record({ actor: g.session.sub, action: 'news.create', target: article.slug });
    return NextResponse.json({ article }, { status: 201 });
  } catch (e) { return errorResponse(e); }
}
