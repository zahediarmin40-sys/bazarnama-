import { NextResponse, type NextRequest } from 'next/server';
import { buildPayload, parseIds } from '@/server/snapshot';

export const dynamic = 'force-dynamic';

/** Snapshot endpoint (also the polling fallback). One upstream poll serves every visitor. */
export function GET(req: NextRequest) {
  const payload = buildPayload(parseIds(req.nextUrl.searchParams.get('ids')));
  return NextResponse.json(payload, { headers: { 'Cache-Control': 'public, s-maxage=2, stale-while-revalidate=5' } });
}
