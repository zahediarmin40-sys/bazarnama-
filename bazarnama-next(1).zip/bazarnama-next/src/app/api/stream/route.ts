import type { NextRequest } from 'next/server';
import { env } from '@/server/env';
import { getRuntime } from '@/server/ingest/runtime';
import { buildPayload, parseIds } from '@/server/snapshot';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export function GET(req: NextRequest) {
  const rt = getRuntime();
  if (rt.sse.open >= env().MAX_SSE_CONNECTIONS) return new Response('too many connections', { status: 503, headers: { 'Retry-After': '10' } });
  const ids = parseIds(req.nextUrl.searchParams.get('ids'));
  const enc = new TextEncoder();
  let unsub: (() => void) | undefined;
  let hb: ReturnType<typeof setInterval> | undefined;
  let closed = false;
  const cleanup = () => { if (closed) return; closed = true; unsub?.(); if (hb) clearInterval(hb); rt.sse.open--; };

  const stream = new ReadableStream<Uint8Array>({
    start(c) {
      rt.sse.open++;
      const send = (event: string, data: unknown) => { if (!closed) c.enqueue(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)); };
      send('snapshot', buildPayload(ids));
      unsub = rt.bus.subscribe((recs) => { const f = ids ? recs.filter((r) => ids.has(r.assetId)) : recs; if (f.length) send('prices', f); });
      hb = setInterval(() => send('ping', { t: Date.now() }), 15_000);
      req.signal.addEventListener('abort', () => { cleanup(); try { c.close(); } catch { /* already closed */ } });
    },
    cancel: cleanup,
  });
  return new Response(stream, { headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' } });
}
