import type { Metadata, Viewport } from 'next';
import { Vazirmatn } from 'next/font/google';
import { cookies } from 'next/headers';
import type { ReactNode } from 'react';
import { PrefsProvider } from '@/components/PrefsProvider';
import { PREFS_COOKIE, parsePrefs } from '@/lib/prefs';
import './globals.css';
import './admin.css';

const vazir = Vazirmatn({ subsets: ['arabic', 'latin'], variable: '--font-vazir', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'),
  title: { default: 'بازارنما | قیمت طلا، سکه و ارز', template: '%s | بازارنما' },
  description: 'قیمت طلا، سکه و ارز با واحد، منبع و زمان بروزرسانی مشخص.',
  robots: { index: true, follow: true },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1 };

export default async function RootLayout({ children }: { children: ReactNode }) {
  const prefs = parsePrefs((await cookies()).get(PREFS_COOKIE)?.value);
  return (
    <html lang="fa" dir="rtl" className={vazir.variable} data-theme={prefs.theme === 'auto' ? undefined : prefs.theme} suppressHydrationWarning>
      <body><PrefsProvider initial={prefs}>{children}</PrefsProvider></body>
    </html>
  );
}
