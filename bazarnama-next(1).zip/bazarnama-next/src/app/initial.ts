import type { PricesPayload } from '@/core/types';
import { buildPayload } from '@/server/snapshot';
/** Server-render the first paint from the in-memory book; the client then takes over via SSE. */
export const initialFor = (ids: readonly string[]): PricesPayload => buildPayload(new Set(ids));
