import Link from 'next/link';
export default function NotFound() {
  return <div className="panel empty"><b>صفحه پیدا نشد.</b><p><Link href="/">بازگشت به صفحه اصلی</Link></p></div>;
}
