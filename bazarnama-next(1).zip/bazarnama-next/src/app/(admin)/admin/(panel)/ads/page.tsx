import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { AdsManager } from '@/components/admin/AdsManager';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'مدیریت تبلیغات', robots: { index: false } };
export default async function AdsAdmin() {
  const session = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  return <><Hero title="مدیریت تبلیغات" text="تبلیغات بنری را بسازید، جایگاه نمایش و بازه زمانی تعیین کنید و پس از ذخیره، روی سایت منتشر کنید."/><div className="adm-body"><AdsManager initial={getRuntime().config.getConfig()} canEdit={can(session.role, 'content:edit')}/></div></>;
}
