import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { ProviderPanel } from '@/components/admin/ProviderPanel';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'منابع قیمت', robots: { index: false } };

export default async function ProvidersPage() {
  const s = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  if (!can(s.role, 'providers:view')) return <div className="adm-body" style={{ paddingTop: 40 }}><div className="adm-card"><b>دسترسی ندارید.</b></div></div>;
  const rt = getRuntime();
  return (<><Hero title="منابع قیمت" text={`حالت فعلی: ${rt.mode}. هر منبع را روشن یا خاموش کنید و سلامتش را ببینید.`} /><div className="adm-body"><ProviderPanel rows={rt.ingestor.health()} canManage={can(s.role, 'providers:manage')} hasDemo={Boolean(rt.demo)} outage={rt.demo?.outage ?? false} /></div></>);
}
