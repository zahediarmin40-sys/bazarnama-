import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { NewsManager } from '@/components/admin/NewsManager';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'مدیریت اخبار', robots: { index: false } };

export default async function NewsAdmin() {
  const s = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  if (!can(s.role, 'content:edit')) return <div className="adm-body" style={{ paddingTop: 40 }}><div className="adm-card"><b>دسترسی ندارید.</b></div></div>;
  return (<><Hero title="مدیریت اخبار" text="خبر بنویسید، پیش‌نویس کنید و منتشر کنید. خبرها بدون HTML و به‌صورت متن امن نمایش داده می‌شوند." /><div className="adm-body"><NewsManager initial={getRuntime().config.listArticles()} canPublish={can(s.role, 'news:publish')} /></div></>);
}
