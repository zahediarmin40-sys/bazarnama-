import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'گزارش رویدادها', robots: { index: false } };

export default async function AuditPage() {
  const s = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  if (!can(s.role, 'audit:view')) return <div className="adm-body" style={{ paddingTop: 40 }}><div className="adm-card"><b>دسترسی ندارید.</b></div></div>;
  const rows = getRuntime().audit.list(200);
  return (
    <><Hero title="گزارش رویدادها" text="ورودها، تغییر تنظیمات، انتشار اخبار و خطاهای منابع. (فعلاً در حافظه؛ برای ماندگاری به دیتابیس وصل می‌شود.)" />
      <div className="adm-body"><div className="adm-card" style={{ overflowX: 'auto' }}>
        <table className="adm-table"><thead><tr><th>زمان</th><th>کاربر</th><th>رویداد</th><th>هدف</th><th>جزئیات</th></tr></thead><tbody>
          {rows.length === 0 ? <tr><td colSpan={5}>رویدادی ثبت نشده است.</td></tr> : rows.map((e) => <tr key={`${e.t}-${e.action}-${e.target}`}><td>{new Date(e.t).toLocaleString('fa-IR', { timeZone: 'Asia/Tehran' })}</td><td className="num">{e.actor}</td><td>{e.action}</td><td className="num">{e.target}</td><td>{e.detail ?? '—'}</td></tr>)}
        </tbody></table></div></div></>
  );
}
