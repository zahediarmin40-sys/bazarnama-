import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { Hero } from '@/components/admin/Hero';
import { SiteEditor } from '@/components/admin/SiteEditor';
import { can } from '@/server/auth/rbac';
import { SESSION_COOKIE, verifySession } from '@/server/auth/session';
import { getRuntime } from '@/server/ingest/runtime';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'ظاهر و محتوای سایت', robots: { index: false } };

export default async function SitePage() {
  const s = (await verifySession((await cookies()).get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET))!;
  return (<><Hero title="ظاهر و محتوای سایت" text="اطلاعیه، چیدمان صفحه‌ی اصلی، منو و نوار قیمت را تغییر دهید. با «ذخیره و انتشار» فوراً روی سایت اعمال می‌شود." /><div className="adm-body"><SiteEditor initial={getRuntime().config.getConfig()} canEdit={can(s.role, 'content:edit')} /></div></>);
}
