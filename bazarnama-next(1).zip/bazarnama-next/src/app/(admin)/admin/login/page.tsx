import type { Metadata } from 'next';
import { LoginForm } from '@/components/LoginForm';

export const metadata: Metadata = { title: 'ورود مدیران', robots: { index: false, follow: false } };

const CANDLES = [[40, 120, 60, 'u'], [90, 90, 40, 'd'], [140, 105, 55, 'u'], [190, 70, 35, 'u'], [240, 85, 50, 'd'], [290, 55, 30, 'u'], [340, 65, 40, 'u'], [390, 40, 25, 'd'], [440, 48, 30, 'u'], [490, 25, 22, 'u']] as const;

export default function LoginPage() {
  return (
    <div className="lg">
      <section className="lg-art" aria-hidden="false">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: '1.2rem' }}>
          <svg width="34" height="34" viewBox="0 0 30 30" style={{ position: 'static', height: 34, width: 34, opacity: 1 }} aria-hidden="true"><rect x="2" y="2" width="26" height="26" rx="8" fill="#161C25" stroke="#D9AA45" /><path d="M8 20l5-6 4 3 5-8" fill="none" stroke="#D9AA45" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
          بازارنما
        </div>
        <div><h2>کنترل کامل سایت، در یک جا.</h2><p>ظاهر صفحه، اخبار، منابع قیمت و گزارش رویدادها. دسترسی فقط برای مدیران تأییدشده.</p></div>
        <svg viewBox="0 0 540 180" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
          {CANDLES.map(([x, y, h, t], i) => (
            <g className="candle" key={i}><line x1={x + 12} x2={x + 12} y1={y - 14} y2={y + h + 12} stroke={t === 'u' ? '#D9AA45' : '#6B7C95'} strokeWidth="2" /><rect x={x} y={y} width="24" height={h} rx="4" fill={t === 'u' ? '#D9AA45' : '#2B3646'} stroke={t === 'u' ? '#D9AA45' : '#6B7C95'} /></g>
          ))}
        </svg>
      </section>
      <section className="lg-form"><div className="lg-card"><h1>ورود مدیران</h1><p className="sub">با ایمیل مدیر و گذرواژه‌ی خودتان وارد شوید.</p><LoginForm /></div></section>
    </div>
  );
}
