'use client';
import { useEffect, useState } from 'react';

/** Re-renders every `ms` so status (live/delayed/stale) is derived from the clock, never frozen. */
export function useNow(ms = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => { if (!document.hidden) setNow(Date.now()); }, ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}
