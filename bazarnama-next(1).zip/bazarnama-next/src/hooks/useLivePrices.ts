'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { mergeRecords } from '@/core/store';
import type { PriceRecord, PricesMode, PricesPayload } from '@/core/types';
import { useNow } from './useNow';

export type Connection = 'connecting' | 'stream' | 'polling';

/** SSE first (server pushes), automatic fallback to polling, periodic retry of SSE. Never invents data. */
export function useLivePrices(ids: readonly string[], initial: PricesPayload) {
  const [records, setRecords] = useState<Map<string, PriceRecord>>(() => mergeRecords(new Map(), initial.records));
  const [mode, setMode] = useState<PricesMode>(initial.mode);
  const [intervalSec, setIntervalSec] = useState(initial.intervalSec);
  const [conn, setConn] = useState<Connection>('connecting');
  const now = useNow(1000);
  const key = useMemo(() => ids.join(','), [ids]);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    let es: EventSource | null = null;
    let poll: ReturnType<typeof setInterval> | null = null;
    let retry: ReturnType<typeof setTimeout> | null = null;
    const apply = (p: Partial<PricesPayload> & { records: PriceRecord[] }) => {
      if (!alive.current) return;
      setRecords((m) => mergeRecords(m, p.records));
      if (p.mode) setMode(p.mode);
      if (p.intervalSec) setIntervalSec(p.intervalSec);
    };
    const url = `/api/stream?ids=${encodeURIComponent(key)}`;
    const startPolling = () => {
      setConn('polling');
      const tick = async () => {
        try { const r = await fetch(`/api/prices?ids=${encodeURIComponent(key)}`, { cache: 'no-store' }); if (r.ok) apply((await r.json()) as PricesPayload); } catch { /* keep last values; status ages naturally */ }
      };
      void tick();
      poll = setInterval(tick, Math.max(5, intervalSec) * 1000);
      retry = setTimeout(() => { if (poll) clearInterval(poll); poll = null; connect(); }, 60_000);
    };
    const connect = () => {
      if (typeof EventSource === 'undefined') return startPolling();
      es = new EventSource(url);
      es.addEventListener('open', () => alive.current && setConn('stream'));
      es.addEventListener('snapshot', (e) => apply(JSON.parse((e as MessageEvent<string>).data) as PricesPayload));
      es.addEventListener('prices', (e) => apply({ records: JSON.parse((e as MessageEvent<string>).data) as PriceRecord[] }));
      es.addEventListener('error', () => { es?.close(); es = null; startPolling(); });
    };
    connect();
    return () => { alive.current = false; es?.close(); if (poll) clearInterval(poll); if (retry) clearTimeout(retry); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return { records, mode, intervalSec, conn, now };
}
