import type { PricesPayload } from '../core/types.ts';
import { getRuntime } from './ingest/runtime.ts';

export function buildPayload(ids?: ReadonlySet<string>): PricesPayload {
  const rt = getRuntime();
  const all = rt.store.all();
  return { mode: rt.mode, intervalSec: rt.ingestor.intervalSec(), serverTime: Date.now(), records: ids ? all.filter((r) => ids.has(r.assetId)) : all };
}
export function parseIds(param: string | null): Set<string> | undefined {
  if (!param) return undefined;
  const ids = param.split(',').map((s) => s.trim()).filter((s) => /^[a-z0-9-]{1,40}$/.test(s)).slice(0, 80);
  return ids.length ? new Set(ids) : undefined;
}
