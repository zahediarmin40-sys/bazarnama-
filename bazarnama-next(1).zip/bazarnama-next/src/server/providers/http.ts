import { ProviderError } from './types.ts';

export interface FetchJsonOptions { headers?: Record<string, string>; timeoutMs?: number; maxBytes?: number; signal?: AbortSignal }

/** fetch + timeout + size cap + typed errors. Never logs headers (they may contain secrets). */
export async function fetchJson(url: string, o: FetchJsonOptions = {}): Promise<unknown> {
  const { headers = {}, timeoutMs = 10_000, maxBytes = 2_000_000, signal } = o;
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(new Error('timeout')), timeoutMs);
  const onAbort = () => ctl.abort(signal?.reason);
  signal?.addEventListener('abort', onAbort, { once: true });
  try {
    const res = await fetch(url, { headers: { accept: 'application/json', ...headers }, signal: ctl.signal, cache: 'no-store' });
    if (res.status === 429) throw new ProviderError('RATE_LIMITED', 'HTTP 429');
    if (!res.ok) throw new ProviderError('HTTP', `HTTP ${res.status}`);
    const text = await res.text();
    if (text.length > maxBytes) throw new ProviderError('PARSE', 'response too large');
    try { return JSON.parse(text) as unknown; } catch { throw new ProviderError('PARSE', 'invalid JSON'); }
  } catch (e) {
    if (e instanceof ProviderError) throw e;
    if (ctl.signal.aborted) throw new ProviderError('TIMEOUT', 'request aborted or timed out');
    throw new ProviderError('NETWORK', e instanceof Error ? e.message : 'network error');
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }
}
