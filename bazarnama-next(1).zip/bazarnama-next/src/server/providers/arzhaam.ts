import { createRestAdapter, notImplemented } from './rest-adapter.ts';
import type { ProviderAdapter } from './types.ts';

/**
 * CANDIDATE provider: not endorsed, not verified.
 * Before production verify with Arzhaam: endpoints, asset coverage, real update frequency, rate limits,
 * uptime, attribution, commercial redistribution rights and price.
 * Advertised transport: "rest". The request below is a placeholder until verified against the official docs.
 */
export function createArzhaam(env: Record<string, string | undefined>): ProviderAdapter {
  return createRestAdapter({
    id: 'arzhaam',
    label: 'Arzhaam',
    note: 'REST JSON برای ارز، طلا و سکه ایران با کلید API (برای تأیید)',
    capabilities: { transport: 'rest', minIntervalSec: 20 },
    baseUrl: env.ARZHAAM_BASE_URL || undefined,
    apiKey: env.ARZHAAM_API_KEY || undefined,
    // TODO(verify): auth scheme and path from the official docs. The key must never reach a client bundle.
    buildRequest: ({ baseUrl, apiKey }) => ({ url: baseUrl, headers: apiKey ? { 'x-api-key': apiKey } : undefined }),
    // TODO(verify): validate with zod, map ids via DEFAULT_MAPPINGS.arzhaam, set marketType per asset, use the provider's own timestamp.
    parse: () => notImplemented('arzhaam'),
  });
}
