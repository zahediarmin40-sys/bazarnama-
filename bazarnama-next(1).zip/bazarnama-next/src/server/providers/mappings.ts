/**
 * providerAssetId -> site assetId, per provider.
 * Intentionally EMPTY: IDs must come from each provider's official documentation.
 * In production this table moves to the database and is edited from the admin screen.
 *
 * Example (illustrative only, do NOT trust):
 *   talasanj: { 'some-provider-id-for-18k': 'gold-18' }
 */
export const DEFAULT_MAPPINGS: Record<string, Record<string, string>> = { talasanj: {}, arzhaam: {}, nerkhara: {} };
