import { createRestAdapter, notImplemented } from './rest-adapter.ts';
import type { ProviderAdapter } from './types.ts';

/**
 * CANDIDATE provider: not endorsed, not verified.
 * Before production verify with Talasanj: endpoints, asset coverage, real update frequency, rate limits,
 * uptime, attribution, commercial redistribution rights and price.
 * Advertised transport: "sse". The request below is a placeholder until verified against the official docs.
 */
export function createTalasanj(env: Record<string, string | undefined>): ProviderAdapter {
  return createRestAdapter({
    id: 'talasanj',
    label: 'Talasanj',
    note: 'طلا، سکه و دلار آزاد؛ جریان زنده با بازه حدود ۲۰ ثانیه (برای تأیید)',
    capabilities: { transport: 'rest', minIntervalSec: 20 },
    baseUrl: env.TALASANJ_BASE_URL || undefined,
    apiKey: env.TALASANJ_API_KEY || undefined,
    // TODO(verify): auth scheme and path from the official docs. The key must never reach a client bundle.
    buildRequest: ({ baseUrl, apiKey }) => ({ url: baseUrl, headers: apiKey ? { 'x-api-key': apiKey } : undefined }),
    // TODO(verify): validate with zod, map ids via DEFAULT_MAPPINGS.talasanj, set marketType per asset, use the provider's own timestamp.
    parse: () => notImplemented('talasanj'),
  });
}
