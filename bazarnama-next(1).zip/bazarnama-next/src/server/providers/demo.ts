import type { PriceRecord } from '../../core/types.ts';
import { ASSETS } from '../../domain/catalog.ts';
import type { ProviderAdapter } from './types.ts';

/**
 * DEMO ONLY. Fabricated numbers for UI development. Enabled only with PRICE_MODE=demo,
 * refused in production unless ALLOW_DEMO_IN_PRODUCTION=1, and always labelled "نمایشی (دمو)".
 */
const G24 = 15_400_000;
const FX_FREE: Record<string, number> = { USD: 112400, EUR: 131200, GBP: 150300, AED: 30600, TRY: 2640, CAD: 80300, AUD: 73100, CHF: 139600, JPY: 745, CNY: 15500 };
const FX_EX: Record<string, number> = { USD: 78000, EUR: 91000, GBP: 104500, AED: 21200, TRY: 1840 };
const COIN: Record<string, number> = { emami: 121_800_000, old: 119_500_000, half: 62_000_000, quarter: 34_200_000, gram: 15_700_000 };
const WORLD: Record<string, number> = { gold: 4150, silver: 52.3, platinum: 1620, palladium: 1480 };

export function demoBase(assetId: string): number | null {
  const a = ASSETS.find((x) => x.id === assetId);
  if (!a) return null;
  if (a.category === 'gold') return Math.round(((G24 * (a.purity ?? 24)) / 24) / 1000) * 1000;
  if (a.category === 'coin') return COIN[assetId.slice(5)] ?? null;
  if (a.category === 'world') return WORLD[assetId.replace('-ounce', '')] ?? null;
  if (a.category === 'fx') return (a.marketType === 'exchange' ? FX_EX : FX_FREE)[a.code ?? ''] ?? null;
  return null;
}

export const DEMO_SOURCE = 'نمایشی (دمو)';

export function createDemoAdapter(rnd: () => number = Math.random, now: () => number = Date.now): ProviderAdapter & { outage: boolean } {
  const level: Record<string, number> = { gold: 1, coin: 1, fx: 1, world: 1 };
  const day = new Map<string, { open: number; lo: number; hi: number }>();
  const adapter = {
    id: 'demo', label: 'نمایشی (دمو)', kind: 'demo' as const, note: 'ارائه‌دهنده ساختگی برای توسعه',
    capabilities: { transport: 'rest' as const, minIntervalSec: 3 },
    outage: false,
    isConfigured: () => true,
    async poll(): Promise<PriceRecord[]> {
      if (adapter.outage) return []; // simulates a silent feed: nothing new arrives, so records age into delayed/stale
      for (const k of Object.keys(level)) level[k] = Math.min(1.03, Math.max(0.97, (level[k] ?? 1) * (1 + (rnd() - 0.5) * 0.0016)));
      const ts = now();
      const out: PriceRecord[] = [];
      for (const a of ASSETS) {
        const base = demoBase(a.id);
        if (base === null) continue;
        const lv = level[a.category === 'gold' ? 'gold' : a.category === 'coin' ? 'coin' : a.category === 'world' ? 'world' : 'fx'] ?? 1;
        const noise = a.category === 'gold' ? 1 : 1 + (rnd() - 0.5) * 0.0004;
        const raw = base * lv * noise;
        const price = a.currency === 'USD' ? Math.round(raw * 100) / 100 : Math.round(raw / (a.category === 'fx' ? (base < 1000 ? 1 : 10) : 1000)) * (a.category === 'fx' ? (base < 1000 ? 1 : 10) : 1000);
        const d = day.get(a.id) ?? { open: base, lo: price, hi: price };
        d.lo = Math.min(d.lo, price); d.hi = Math.max(d.hi, price); day.set(a.id, d);
        out.push({ assetId: a.id, price, unit: a.unit, currency: a.currency, change: price - d.open, changePercent: ((price - d.open) / d.open) * 100, low: d.lo, high: d.hi, source: DEMO_SOURCE, updatedAt: ts, marketType: a.marketType, dataStatus: 'live' });
      }
      return out;
    },
  };
  return adapter;
}
