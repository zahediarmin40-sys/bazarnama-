import type { PriceRecord } from '../../core/types.ts';
import { fetchJson } from './http.ts';
import { ProviderError, type ProviderAdapter, type ProviderCapabilities } from './types.ts';

export interface RestAdapterConfig {
  id: string;
  label: string;
  note: string;
  kind?: 'candidate' | 'live';
  attribution?: { name: string; url: string };
  capabilities: ProviderCapabilities;
  baseUrl?: string;
  apiKey?: string;
  /** Build the request from the provider's OFFICIAL docs (auth scheme, path, query). */
  buildRequest(cfg: { baseUrl: string; apiKey?: string }): { url: string; headers?: Record<string, string> };
  /** Set false for keyless public APIs. */
  /** Map the provider's JSON into normalized records, using mappings.ts. Must validate with zod/guards. */
  parse(json: unknown, now: number): PriceRecord[];
}

export function createRestAdapter(c: RestAdapterConfig): ProviderAdapter {
  return {
    id: c.id, label: c.label, kind: c.kind ?? 'candidate', note: c.note, attribution: c.attribution, capabilities: c.capabilities,
    isConfigured: () => Boolean(c.baseUrl),
    async poll(signal) {
      if (!c.baseUrl) throw new ProviderError('NOT_CONFIGURED', `${c.id}: BASE_URL / API_KEY env vars are not set`);
      const req = c.buildRequest({ baseUrl: c.baseUrl, apiKey: c.apiKey });
      const json = await fetchJson(req.url, { headers: req.headers, signal });
      return c.parse(json, Date.now());
    },
  };
}

export const notImplemented = (id: string): never => {
  throw new ProviderError('NOT_IMPLEMENTED', `${id}: response mapping is not implemented. Verify the official API docs, then implement parse() and fill mappings.ts.`);
};
