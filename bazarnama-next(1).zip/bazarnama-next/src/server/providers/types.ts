import type { PriceRecord } from '../../core/types.ts';

export type ProviderErrorCode = 'NOT_CONFIGURED' | 'NOT_IMPLEMENTED' | 'HTTP' | 'PARSE' | 'RATE_LIMITED' | 'TIMEOUT' | 'NETWORK';
export class ProviderError extends Error {
  readonly code: ProviderErrorCode;
  constructor(code: ProviderErrorCode, message: string) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
  }
}

export interface ProviderCapabilities {
  transport: 'rest' | 'sse' | 'ws';
  /** Smallest interval the provider's terms allow. The ingestor never polls faster than this. */
  minIntervalSec: number;
  /** Polling cadence that matches how often the provider really refreshes (defaults to the site interval). */
  preferredIntervalSec?: number;
}

/**
 * Provider adapter contract. Adapters run ONLY on the server, own their credentials,
 * and must return fully-normalized records (see core/types PriceRecord).
 * Adapters must not average, convert or "improve" prices.
 */
export interface ProviderAdapter {
  readonly id: string;
  readonly label: string;
  readonly kind: 'demo' | 'candidate' | 'live';
  /** Required credit line when this provider's figures are displayed (provider terms). */
  readonly attribution?: { name: string; url: string };
  readonly note?: string;
  readonly capabilities: ProviderCapabilities;
  isConfigured(): boolean;
  poll(signal: AbortSignal): Promise<PriceRecord[]>;
  /** Optional push transport. Resolves when the stream ends; the ingestor reconnects with backoff. */
  stream?(onRecords: (records: PriceRecord[]) => void, signal: AbortSignal): Promise<void>;
}
