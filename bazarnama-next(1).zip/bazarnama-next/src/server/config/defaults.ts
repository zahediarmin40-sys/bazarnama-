import { NAV } from '../../domain/sections.ts';
import { SNAPSHOT_IDS } from '../../domain/catalog.ts';
import { HOME_MODULE_IDS, type SiteConfig } from './types.ts';

export const DEFAULT_FOOTER = 'اطلاعات این سایت صرفاً مرجع است و توصیه مالی نیست. هر قیمت با واحد، منبع و زمان بروزرسانی نمایش داده می‌شود.';
export const defaultConfig = (): SiteConfig => ({
  announcement: { enabled: false, tone: 'info', text: '', href: '' },
  homeModules: HOME_MODULE_IDS.map((id) => ({ id, enabled: true })),
  nav: NAV.map((n) => ({ href: n.href, label: n.label, visible: true })),
  snapshotIds: [...SNAPSHOT_IDS],
  ads: [],
  footerNote: DEFAULT_FOOTER,
});
