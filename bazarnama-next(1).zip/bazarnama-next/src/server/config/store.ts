import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { defaultConfig } from './defaults.ts';
import { HOME_MODULE_IDS } from './types.ts';
import { NAV } from '../../domain/sections.ts';
import { sanitizeArticle, sanitizeConfig, ValidationError } from './sanitize.ts';
import type { Article, PersistedData, SiteConfig } from './types.ts';

/** File-backed, atomic (tmp + rename). Single-process; swap for the Prisma models when scaling out. */
export function createConfigStore(file: string | null, now: () => number = Date.now) {
  let data: PersistedData = { config: defaultConfig(), articles: [] };
  if (file && existsSync(file)) {
    try {
      const raw = JSON.parse(readFileSync(file, 'utf8')) as Partial<PersistedData>;
      const legacy = { ...((raw.config ?? {}) as Record<string, unknown>) };
      // Migrate removed legacy navigation/module entries without discarding stored articles.
      if (Array.isArray(legacy.nav)) legacy.nav = legacy.nav.filter((n) => n && typeof n === 'object' && NAV.some((item) => item.href === (n as { href?: string }).href));
      if (Array.isArray(legacy.homeModules)) legacy.homeModules = legacy.homeModules.filter((m) => m && typeof m === 'object' && HOME_MODULE_IDS.includes((m as { id?: string }).id as (typeof HOME_MODULE_IDS)[number]));
      data = { config: sanitizeConfig(legacy), articles: Array.isArray(raw.articles) ? raw.articles.filter((a) => a && typeof a.id === 'string') : [] };
    } catch {
      try { renameSync(file, `${file}.corrupt-${now()}`); } catch { /* keep going with defaults */ }
    }
  }
  const flush = () => {
    if (!file) return;
    mkdirSync(dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    renameSync(tmp, file);
  };
  return {
    getConfig: (): SiteConfig => structuredClone(data.config),
    updateConfig(patch: unknown): SiteConfig { data.config = sanitizeConfig(patch, data.config); flush(); return structuredClone(data.config); },
    resetConfig(): SiteConfig { data.config = defaultConfig(); flush(); return structuredClone(data.config); },
    listArticles(opts: { publishedOnly?: boolean } = {}): Article[] {
      return data.articles.filter((a) => !opts.publishedOnly || (a.published && a.publishedAt <= now())).sort((a, b) => b.publishedAt - a.publishedAt).map((a) => ({ ...a }));
    },
    getArticleBySlug: (slug: string, publishedOnly = true): Article | null => {
      const a = data.articles.find((x) => x.slug === slug);
      return a && (!publishedOnly || (a.published && a.publishedAt <= now())) ? { ...a } : null;
    },
    getArticle: (id: string): Article | null => { const a = data.articles.find((x) => x.id === id); return a ? { ...a } : null; },
    createArticle(input: unknown): Article {
      const a = sanitizeArticle(input, undefined, now());
      if (data.articles.some((x) => x.slug === a.slug)) throw new ValidationError('slug', 'این نشانی قبلاً استفاده شده است');
      const art: Article = { id: randomUUID(), ...a };
      data.articles.push(art); flush(); return { ...art };
    },
    updateArticle(id: string, input: unknown): Article | null {
      const i = data.articles.findIndex((x) => x.id === id);
      if (i < 0) return null;
      const cur = data.articles[i] as Article;
      const a = sanitizeArticle(input, cur, now());
      if (data.articles.some((x) => x.slug === a.slug && x.id !== id)) throw new ValidationError('slug', 'این نشانی قبلاً استفاده شده است');
      data.articles[i] = { id, ...a }; flush(); return { ...(data.articles[i] as Article) };
    },
    deleteArticle(id: string): boolean { const n = data.articles.length; data.articles = data.articles.filter((x) => x.id !== id); if (data.articles.length !== n) { flush(); return true; } return false; },
  };
}
export type ConfigStore = ReturnType<typeof createConfigStore>;
