/** Fixed-window limiter (per key). In-memory: use Redis when running multiple instances. */
export function createRateLimiter(limit: number, windowMs: number, now: () => number = Date.now) {
  const hits = new Map<string, { n: number; reset: number }>();
  return {
    check(key: string): { ok: boolean; retryAfterSec: number } {
      const t = now();
      const h = hits.get(key);
      if (!h || t >= h.reset) { hits.set(key, { n: 1, reset: t + windowMs }); return { ok: true, retryAfterSec: 0 }; }
      h.n++;
      return h.n <= limit ? { ok: true, retryAfterSec: 0 } : { ok: false, retryAfterSec: Math.ceil((h.reset - t) / 1000) };
    },
  };
}
