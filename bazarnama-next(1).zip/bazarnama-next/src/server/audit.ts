export interface AuditEntry { t: number; actor: string; action: string; target: string; detail?: string }
/** Swap for the Prisma AuditLog table in Phase 3. */
export interface AuditSink { record(e: Omit<AuditEntry, 't'>): void; list(limit?: number): AuditEntry[] }
export function createMemoryAudit(max = 500, now: () => number = Date.now): AuditSink {
  const log: AuditEntry[] = [];
  return {
    record(e) { log.unshift({ t: now(), ...e }); if (log.length > max) log.pop(); },
    list: (limit = 50) => log.slice(0, limit),
  };
}
