import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '../core/store.ts';
import type { PriceRecord } from '../core/types.ts';
import { acceptFrom, parsePolicy, singleProviderPolicy } from './ingest/policy.ts';
import { Ingestor, nextDelayMs } from './ingest/ingestor.ts';
import { createMemoryBus } from './ingest/bus.ts';
import { createDemoAdapter, DEMO_SOURCE } from './providers/demo.ts';
import { ProviderError, type ProviderAdapter } from './providers/types.ts';
import { can, isRole } from './auth/rbac.ts';
import { hashPassword, verifyPassword } from './auth/password.ts';
import { authenticate, parseUsers } from './auth/users.ts';
import { createRateLimiter } from './rate-limit.ts';
import { createMemoryAudit } from './audit.ts';

const rec = (o: Partial<PriceRecord> = {}): PriceRecord => ({ assetId: 'gold-18', price: 1000, unit: 'gram', currency: 'IRT', change: 0, changePercent: 0, low: null, high: null, source: 't', updatedAt: 1000, marketType: 'free-local', dataStatus: 'live', ...o });
const fake = (id: string, fn: () => Promise<PriceRecord[]>): ProviderAdapter => ({ id, label: id, kind: 'candidate', capabilities: { transport: 'rest', minIntervalSec: 1 }, isConfigured: () => true, poll: fn });

test('policy: primary accepted, fallback only when primary is silent', () => {
  const pol = parsePolicy('{"gold":{"primary":"a","fallback":["b","c"]}}');
  const seen = new Map<string, number>();
  const ls = (p: string) => seen.get(p);
  assert.equal(acceptFrom('a', 'gold', pol, ls, 100, 50), true);
  assert.equal(acceptFrom('b', 'gold', pol, ls, 100, 50), true); // a never seen
  seen.set('a', 90);
  assert.equal(acceptFrom('b', 'gold', pol, ls, 100, 50), false); // a is fresh
  seen.set('a', 10);
  assert.equal(acceptFrom('b', 'gold', pol, ls, 100, 50), true); // a stale
  assert.equal(acceptFrom('c', 'gold', pol, ls, 100, 50), true);
  seen.set('b', 95);
  assert.equal(acceptFrom('c', 'gold', pol, ls, 100, 50), false);
  assert.equal(acceptFrom('x', 'gold', pol, ls, 100, 50), false); // not in chain
  assert.equal(acceptFrom('a', 'coin', pol, ls, 100, 50), false); // no policy => nothing accepted
});
test('policy parsing rejects garbage', () => {
  assert.throws(() => parsePolicy('{'));
  assert.throws(() => parsePolicy('{"nope":{"primary":"a"}}'));
  assert.throws(() => parsePolicy('{"gold":{}}'));
  assert.deepEqual(parsePolicy(''), {});
});
test('ingestor: validates, applies policy, publishes only accepted', () => {
  const store = createStore(), bus = createMemoryBus(), got: PriceRecord[][] = [];
  bus.subscribe((r) => got.push(r));
  const ing = new Ingestor({ adapters: [fake('p', async () => [])], policy: singleProviderPolicy('p'), store, bus, defaultIntervalSec: 20, now: () => 5000 });
  const res = ing.ingestBatch('p', [rec(), rec({ assetId: 'nope' }), rec({ assetId: 'coin-half', price: -5 }), rec({ assetId: 'coin-half', unit: 'piece', price: 5, updatedAt: 1 })]);
  assert.deepEqual(res, { accepted: 2, rejected: 2 });
  assert.equal(got.length, 1);
  assert.equal(got[0]!.length, 2);
  const other = ing.ingestBatch('unknown-provider', [rec({ assetId: 'gold-24', updatedAt: 2000 })]);
  assert.equal(other.accepted, 0);
});
test('ingestor: failures tracked, recovery resets, errors surfaced', async () => {
  const store = createStore(), errs: string[] = [];
  let fail = true;
  const a = fake('p', async () => { if (fail) throw new ProviderError('TIMEOUT', 'slow'); return [rec()]; });
  const ing = new Ingestor({ adapters: [a], policy: singleProviderPolicy('p'), store, bus: createMemoryBus(), defaultIntervalSec: 20, onError: (id, m) => errs.push(`${id}:${m}`) });
  const sig = new AbortController().signal;
  assert.equal(await ing.pollOnce(a, sig), false);
  assert.equal(await ing.pollOnce(a, sig), false);
  assert.equal(ing.health()[0]!.consecutiveFailures, 2);
  assert.match(errs[0]!, /TIMEOUT/);
  fail = false;
  assert.equal(await ing.pollOnce(a, sig), true);
  assert.equal(ing.health()[0]!.consecutiveFailures, 0);
  assert.equal(store.get('gold-18')?.price, 1000);
});
test('nextDelayMs: min interval, backoff cap, jitter bounds', () => {
  assert.equal(nextDelayMs(5, 20, 0, () => 0.5), 20000);
  assert.equal(nextDelayMs(20, 1, 2, () => 0.5), 80000);
  assert.equal(nextDelayMs(20, 1, 99, () => 0.5), 320000);
  assert.ok(nextDelayMs(20, 1, 0, () => 0) >= 18000 && nextDelayMs(20, 1, 0, () => 1) <= 22000);
});
test('demo adapter is labelled, deterministic enough, and can simulate silence', async () => {
  const d = createDemoAdapter(() => 0.5, () => 42);
  const recs = await d.poll(new AbortController().signal);
  assert.ok(recs.length > 20);
  assert.ok(recs.every((r) => r.source === DEMO_SOURCE && r.updatedAt === 42 && r.price! > 0));
  assert.ok(recs.some((r) => r.assetId === 'fx-usd-free') && !recs.some((r) => r.assetId === 'fx-chf-ex'));
  d.outage = true;
  assert.deepEqual(await d.poll(new AbortController().signal), []);
});
test('rbac matrix', () => {
  assert.equal(can('admin', 'users:manage'), true);
  assert.equal(can('editor', 'providers:manage'), false);
  assert.equal(can('operator', 'providers:manage'), true);
  assert.equal(can('operator', 'news:publish'), false);
  assert.equal(can(undefined, 'providers:view'), false);
  assert.equal(isRole('root'), false);
});
test('password hashing + auth', async () => {
  const h = await hashPassword('s3cret!');
  assert.ok(h.startsWith('scrypt$'));
  assert.equal(await verifyPassword('s3cret!', h), true);
  assert.equal(await verifyPassword('wrong', h), false);
  assert.equal(await verifyPassword('x', 'garbage'), false);
  const users = parseUsers(JSON.stringify([{ email: 'A@Example.com', hash: h, role: 'operator' }, { email: 'bad', hash: 'x', role: 'admin' }, { email: 'x@y.co', hash: h, role: 'root' }]));
  assert.equal(users.length, 1);
  const r = await authenticate(users, ' a@example.com ', 's3cret!');
  assert.ok(r.status === 'ok' && r.user.role === 'operator');
  assert.equal((await authenticate(users, 'a@example.com', 'nope')).status, 'invalid');
  assert.equal((await authenticate(users, 'ghost@example.com', 's3cret!')).status, 'invalid');
});
test('rate limiter + audit', () => {
  let t = 0;
  const rl = createRateLimiter(2, 1000, () => t);
  assert.equal(rl.check('ip').ok, true); assert.equal(rl.check('ip').ok, true);
  const third = rl.check('ip');
  assert.equal(third.ok, false); assert.equal(third.retryAfterSec, 1);
  t = 1500; assert.equal(rl.check('ip').ok, true);
  const au = createMemoryAudit(2, () => 7);
  au.record({ actor: 'a', action: 'x', target: '1' }); au.record({ actor: 'a', action: 'y', target: '2' }); au.record({ actor: 'a', action: 'z', target: '3' });
  assert.deepEqual(au.list().map((e) => e.action), ['z', 'y']);
});
