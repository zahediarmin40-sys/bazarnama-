import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createConfigStore } from './config/store.ts';
import { sanitizeArticle, sanitizeConfig, ValidationError } from './config/sanitize.ts';
import { defaultConfig } from './config/defaults.ts';
import { base32Decode, base32Encode, generateTotpSecret, hotp, verifyTotp } from './auth/totp.ts';
import { authenticate, parseUsers } from './auth/users.ts';
import { hashPassword } from './auth/password.ts';
import { sameOrigin } from './auth/origin.ts';
import { createActivityMeter } from './ingest/activity.ts';

const art = (o: Record<string, unknown> = {}) => ({ title: 'تیتر', summary: 'خلاصه', body: 'متن\n\nبند دوم', category: 'اقتصاد', source: 'منبع', published: true, ...o });

test('config: strict whitelist sanitization', () => {
  const c = sanitizeConfig({ announcement: { enabled: true, tone: 'warning', text: 'بروزرسانی', href: '/data' }, evil: '<script>' });
  assert.equal(c.announcement.tone, 'warning');
  assert.ok(!('evil' in c));
  assert.throws(() => sanitizeConfig({ announcement: { enabled: true, text: '' } }), ValidationError);
  assert.throws(() => sanitizeConfig({ announcement: { enabled: true, text: 'x', href: 'javascript:alert(1)' } }), ValidationError);
  assert.throws(() => sanitizeConfig({ announcement: { enabled: true, text: 'x', href: '//evil.com' } }), ValidationError);
  assert.throws(() => sanitizeConfig({ snapshotIds: ['gold-18', 'nope', 'fx-usd-free'] }), ValidationError);
  assert.throws(() => sanitizeConfig({ snapshotIds: ['gold-18'] }), ValidationError);
  assert.throws(() => sanitizeConfig({ nav: [{ href: 'https://evil.com', label: 'x', visible: true }] }), ValidationError);
  assert.throws(() => sanitizeConfig({ homeModules: [{ id: 'news' }, { id: 'news' }] }), ValidationError);
  const adConfig = sanitizeConfig({ ads: [{ id: 'campaign_1', title: 'تبلیغ نمونه', description: 'متن کوتاه', href: 'https://example.com/offer', imageUrl: '/banner.webp', placement: 'home', enabled: true }] });
  assert.equal(adConfig.ads[0]?.enabled, true);
  assert.equal(adConfig.ads[0]?.placement, 'home');
  assert.throws(() => sanitizeConfig({ ads: [{ id: 'unsafe', title: 'تبلیغ', href: 'javascript:alert(1)' }] }), ValidationError);
});
test('config: modules/nav keep all entries, home link cannot be hidden, order respected', () => {
  const c = sanitizeConfig({ homeModules: [{ id: 'snapshot', enabled: false }, { id: 'news', enabled: true }], nav: [{ href: '/', label: 'خانه', visible: false }] });
  assert.deepEqual(c.homeModules.map((m) => m.id), ['snapshot', 'news']);
  assert.equal(c.homeModules.length, 2);
  assert.equal(c.homeModules[0]!.enabled, false);
  assert.equal(c.nav[0]!.visible, true);
  assert.equal(c.nav.length, defaultConfig().nav.length);
});
test('articles: validation and slug rules', () => {
  assert.throws(() => sanitizeArticle(art({ category: 'x' })), ValidationError);
  assert.throws(() => sanitizeArticle(art({ title: '' })), ValidationError);
  assert.throws(() => sanitizeArticle(art({ slug: 'Bad Slug!' })), ValidationError);
  assert.match(sanitizeArticle(art(), undefined, 1000).slug, /^n-/);
  assert.equal(sanitizeArticle(art({ slug: 'my-news-1' })).slug, 'my-news-1');
});
test('store: persistence, atomic file, CRUD, public visibility', () => {
  const dir = mkdtempSync(join(tmpdir(), 'bz-'));
  const file = join(dir, 'site.json');
  let t = 1_000_000;
  const s = createConfigStore(file, () => t);
  const a = s.createArticle(art({ slug: 'first-news', published: true, publishedAt: 500 }));
  const draft = s.createArticle(art({ slug: 'draft-news', published: false }));
  const future = s.createArticle(art({ slug: 'future-news', published: true, publishedAt: t + 10_000 }));
  assert.throws(() => s.createArticle(art({ slug: 'first-news' })), ValidationError);
  assert.deepEqual(s.listArticles({ publishedOnly: true }).map((x) => x.slug), ['first-news']);
  assert.equal(s.getArticleBySlug('draft-news'), null);
  assert.equal(s.getArticleBySlug('draft-news', false)?.id, draft.id);
  assert.equal(s.getArticleBySlug('future-news'), null);
  t += 20_000; assert.ok(s.getArticleBySlug('future-news'));
  assert.equal(s.updateArticle(a.id, art({ title: 'جدید', slug: 'first-news' }))?.title, 'جدید');
  assert.equal(s.updateArticle('nope', art()), null);
  assert.throws(() => s.updateArticle(a.id, art({ slug: 'draft-news' })), ValidationError);
  s.updateConfig({ ...s.getConfig(), footerNote: 'یادداشت', ads: [{ id: 'banner_1', title: 'حامی بازارنما', description: 'تبلیغ نمونه', href: 'https://example.com', imageUrl: '', placement: 'home', enabled: true, startsAt: null, endsAt: null }] });
  assert.ok(!existsSync(`${file}.tmp`));
  const s2 = createConfigStore(file, () => t);
  assert.equal(s2.getConfig().footerNote, 'یادداشت');
  assert.equal(s2.getConfig().ads[0]?.title, 'حامی بازارنما');
  assert.equal(s2.listArticles().length, 3);
  assert.equal(s2.deleteArticle(draft.id), true);
  assert.equal(s2.deleteArticle(draft.id), false);
  s2.resetConfig(); assert.equal(s2.getConfig().footerNote, defaultConfig().footerNote);
  assert.ok(JSON.parse(readFileSync(file, 'utf8')).articles.length === 2);
});
test('store: corrupt file is quarantined, defaults used', () => {
  const dir = mkdtempSync(join(tmpdir(), 'bz-'));
  const file = join(dir, 'site.json'); writeFileSync(file, '{not json');
  const s = createConfigStore(file, () => 5);
  assert.deepEqual(s.getConfig(), defaultConfig());
  assert.ok(readdirSync(dir).some((f) => f.includes('.corrupt-')));
});
test('totp: RFC 6238 vector, window, rejects junk', () => {
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(secret, 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
  assert.equal(hotp(secret, Math.floor(59 / 30), 8), '94287082');
  assert.equal(verifyTotp(secret, '287082', 59_000), true);
  assert.equal(verifyTotp(secret, '287082', 59_000 + 30_000), true);  // +1 step tolerated
  assert.equal(verifyTotp(secret, '287082', 59_000 + 120_000), false);
  assert.equal(verifyTotp(secret, 'abcdef', 59_000), false);
  assert.equal(base32Decode(base32Encode(Buffer.from('hi!'))).toString(), 'hi!');
  assert.match(generateTotpSecret(), /^[A-Z2-7]{32}$/);
});
test('owner email is always admin; 2FA flow', async () => {
  const h = await hashPassword('pw-123456');
  const secret = generateTotpSecret();
  const users = parseUsers(JSON.stringify([{ email: 'Zahediarmin40@gmail.com', hash: h, role: 'editor', totpSecret: secret }, { email: 'ed@x.io', hash: h, role: 'editor' }]), 'zahediarmin40@gmail.com');
  assert.equal(users[0]!.role, 'admin');
  assert.equal(users[1]!.role, 'editor');
  const now = 90_000;
  assert.equal((await authenticate(users, 'zahediarmin40@gmail.com', 'pw-123456', undefined, now)).status, 'totp-required');
  assert.equal((await authenticate(users, 'zahediarmin40@gmail.com', 'pw-123456', '000000', now)).status, 'invalid');
  const good = hotp(secret, Math.floor(now / 30000));
  const ok = await authenticate(users, 'ZAHEDIARMIN40@gmail.com', 'pw-123456', good, now);
  assert.ok(ok.status === 'ok' && ok.user.role === 'admin');
  assert.equal((await authenticate(users, 'zahediarmin40@gmail.com', 'wrong', good, now)).status, 'invalid');
  assert.equal((await authenticate(users, 'someone@else.com', 'pw-123456')).status, 'invalid'); // email alone / unknown email never works
});
test('same-origin guard', () => {
  assert.equal(sameOrigin('https://a.com', 'a.com'), true);
  assert.equal(sameOrigin('https://evil.com', 'a.com'), false);
  assert.equal(sameOrigin(null, 'a.com'), false);
  assert.equal(sameOrigin('not a url', 'a.com'), false);
});
test('activity meter buckets and expiry', () => {
  let t = 0; const m = createActivityMeter(10, 3, () => t);
  m.record(5); t = 10; m.record(2); assert.deepEqual(m.series(), [0, 5, 2]);
  t = 45; assert.deepEqual(m.series(), [0, 0, 0]);
});
