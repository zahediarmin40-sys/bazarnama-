import type { PriceGroup } from '../../core/types.ts';

export interface GroupPolicy { primary: string; fallback?: readonly string[] }
export type PolicyMap = Partial<Record<PriceGroup, GroupPolicy>>;
export type LastSeen = (provider: string, group: PriceGroup) => number | undefined;

export const GROUPS: readonly PriceGroup[] = ['usd-free', 'fx-free', 'fx-exchange', 'gold', 'coin', 'world-metals'];

/**
 * A provider's record is accepted only if it is the group's primary, or a fallback whose
 * every higher-priority provider has been silent (or stale) longer than staleAfterMs.
 * No policy for a group => nothing is accepted. We never average or blend providers.
 */
export function acceptFrom(provider: string, group: PriceGroup, policy: PolicyMap, lastSeen: LastSeen, now: number, staleAfterMs: number): boolean {
  const p = policy[group];
  if (!p) return false;
  if (p.primary === provider) return true;
  const chain = [p.primary, ...(p.fallback ?? [])];
  const idx = chain.indexOf(provider);
  if (idx < 1) return false;
  for (let i = 0; i < idx; i++) {
    const t = lastSeen(chain[i] as string, group);
    if (t !== undefined && now - t <= staleAfterMs) return false;
  }
  return true;
}

export const singleProviderPolicy = (id: string): PolicyMap => Object.fromEntries(GROUPS.map((g) => [g, { primary: id }])) as PolicyMap;

export function parsePolicy(json: string): PolicyMap {
  let raw: unknown;
  try { raw = JSON.parse(json || '{}'); } catch { throw new Error('PRICE_POLICY is not valid JSON'); }
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) throw new Error('PRICE_POLICY must be an object');
  const out: PolicyMap = {};
  for (const [g, v] of Object.entries(raw)) {
    if (!GROUPS.includes(g as PriceGroup)) throw new Error(`PRICE_POLICY: unknown group "${g}"`);
    const p = v as { primary?: unknown; fallback?: unknown };
    if (typeof p.primary !== 'string' || !p.primary) throw new Error(`PRICE_POLICY.${g}.primary missing`);
    if (p.fallback !== undefined && !(Array.isArray(p.fallback) && p.fallback.every((x) => typeof x === 'string'))) throw new Error(`PRICE_POLICY.${g}.fallback invalid`);
    out[g as PriceGroup] = { primary: p.primary, fallback: p.fallback as string[] | undefined };
  }
  return out;
}
