import type { PriceRecord } from '../../core/types.ts';
import type { PriceStore } from '../../core/store.ts';
import { getAsset } from '../../domain/catalog.ts';
import type { ProviderAdapter } from '../providers/types.ts';
import type { PriceBus } from './bus.ts';
import { acceptFrom, type PolicyMap } from './policy.ts';

export interface ProviderHealth {
  id: string; label: string; kind: string; note?: string; configured: boolean; enabled: boolean;
  lastOkAt?: number; lastErrorAt?: number; lastError?: string; consecutiveFailures: number; accepted: number; rejected: number;
}
export interface IngestorOptions {
  adapters: ProviderAdapter[]; policy: PolicyMap; store: PriceStore; bus: PriceBus;
  now?: () => number; staleAfterMs?: number; defaultIntervalSec: number; onError?: (id: string, msg: string) => void;
}

/** Delay before the next poll: interval, exponential backoff on failures (cap 16x), +-10% jitter, never below the provider minimum. */
export function nextDelayMs(intervalSec: number, minIntervalSec: number, failures: number, rnd: () => number = Math.random): number {
  const base = Math.max(intervalSec, minIntervalSec) * 1000;
  const backoff = Math.min(2 ** Math.max(0, failures), 16);
  return Math.round(base * backoff * (0.9 + rnd() * 0.2));
}

export class Ingestor {
  private readonly o: IngestorOptions;
  private readonly now: () => number;
  private readonly staleAfterMs: number;
  private readonly seen = new Map<string, number>();
  private readonly hs = new Map<string, ProviderHealth>();
  private readonly ctl = new Map<string, AbortController>();
  private running = false;

  constructor(o: IngestorOptions) {
    this.o = o;
    this.now = o.now ?? Date.now;
    this.staleAfterMs = o.staleAfterMs ?? o.defaultIntervalSec * 3000;
    for (const a of o.adapters) this.hs.set(a.id, { id: a.id, label: a.label, kind: a.kind, note: a.note, configured: a.isConfigured(), enabled: true, consecutiveFailures: 0, accepted: 0, rejected: 0 });
  }

  health(): ProviderHealth[] { return [...this.hs.values()].map((h) => ({ ...h })); }
  intervalSec(): number { return this.o.defaultIntervalSec; }
  /** Credit lines required by the terms of the providers that are currently enabled. */
  attributions(): Array<{ name: string; url: string }> {
    return this.o.adapters.filter((a) => a.attribution && this.hs.get(a.id)?.enabled).map((a) => a.attribution as { name: string; url: string });
  }

  /** Applies policy + validation, stores, then publishes only what was actually accepted. */
  ingestBatch(providerId: string, records: PriceRecord[]): { accepted: number; rejected: number } {
    const h = this.hs.get(providerId);
    const now = this.now();
    const accepted: PriceRecord[] = [];
    let rejected = 0;
    for (const rec of records) {
      const asset = getAsset(rec.assetId);
      if (!asset) { rejected++; continue; }
      if (!acceptFrom(providerId, asset.group, this.o.policy, (p, g) => this.seen.get(`${p}:${g}`), now, this.staleAfterMs)) { rejected++; continue; }
      const r = this.o.store.ingest(rec);
      if (r === 'ok') { accepted.push(rec); this.seen.set(`${providerId}:${asset.group}`, rec.updatedAt); } else rejected++;
    }
    if (h) { h.accepted += accepted.length; h.rejected += rejected; }
    if (accepted.length) this.o.bus.publish(accepted);
    return { accepted: accepted.length, rejected };
  }

  async pollOnce(adapter: ProviderAdapter, signal: AbortSignal): Promise<boolean> {
    const h = this.hs.get(adapter.id);
    try {
      const recs = await adapter.poll(signal);
      this.ingestBatch(adapter.id, recs);
      if (h) { h.lastOkAt = this.now(); h.consecutiveFailures = 0; h.lastError = undefined; }
      return true;
    } catch (e) {
      const msg = e instanceof Error ? `${(e as { code?: string }).code ?? 'ERROR'}: ${e.message}` : 'unknown error';
      if (h) { h.lastErrorAt = this.now(); h.lastError = msg; h.consecutiveFailures++; }
      this.o.onError?.(adapter.id, msg);
      return false;
    }
  }

  setEnabled(id: string, enabled: boolean): boolean {
    const h = this.hs.get(id); const a = this.o.adapters.find((x) => x.id === id);
    if (!h || !a) return false;
    h.enabled = enabled;
    if (!enabled) this.ctl.get(id)?.abort();
    else if (this.running) void this.loop(a);
    return true;
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    for (const a of this.o.adapters) void this.loop(a);
  }
  stop(): void { this.running = false; for (const c of this.ctl.values()) c.abort(); this.ctl.clear(); }

  private async loop(a: ProviderAdapter): Promise<void> {
    const h = this.hs.get(a.id);
    if (!h || this.ctl.has(a.id)) return;
    const ctl = new AbortController();
    this.ctl.set(a.id, ctl);
    while (this.running && h.enabled && !ctl.signal.aborted) {
      await this.pollOnce(a, ctl.signal);
      const delay = nextDelayMs(a.capabilities.preferredIntervalSec ?? this.o.defaultIntervalSec, a.capabilities.minIntervalSec, h.consecutiveFailures);
      await new Promise<void>((res) => { const t = setTimeout(res, delay); ctl.signal.addEventListener('abort', () => { clearTimeout(t); res(); }, { once: true }); });
    }
    this.ctl.delete(a.id);
  }
}
