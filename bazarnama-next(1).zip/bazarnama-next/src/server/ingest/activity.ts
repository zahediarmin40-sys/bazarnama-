/** Counts accepted price records in fixed time buckets (for the admin sparkline). */
export function createActivityMeter(bucketMs = 10_000, buckets = 60, now: () => number = Date.now) {
  const counts = new Map<number, number>();
  const key = () => Math.floor(now() / bucketMs);
  return {
    record(n: number): void {
      const k = key(); counts.set(k, (counts.get(k) ?? 0) + n);
      for (const old of counts.keys()) if (old <= k - buckets) counts.delete(old);
    },
    series(): number[] { const k = key(); return Array.from({ length: buckets }, (_, i) => counts.get(k - buckets + 1 + i) ?? 0); },
    bucketMs: () => bucketMs,
  };
}
