import { createStore } from '../../core/store.ts';
import type { PriceStore } from '../../core/store.ts';
import type { PricesMode } from '../../core/types.ts';
import { createMemoryAudit, type AuditSink } from '../audit.ts';
import { env } from '../env.ts';
import { createDemoAdapter } from '../providers/demo.ts';
import { createTalasanj } from '../providers/talasanj.ts';
import { createArzhaam } from '../providers/arzhaam.ts';
import { createNerkhAra } from '../providers/nerkhara.ts';
import type { ProviderAdapter } from '../providers/types.ts';
import { createRateLimiter } from '../rate-limit.ts';
import { createConfigStore, type ConfigStore } from '../config/store.ts';
import { createActivityMeter } from './activity.ts';
import { join } from 'node:path';
import { createMemoryBus, type PriceBus } from './bus.ts';
import { Ingestor } from './ingestor.ts';
import { parsePolicy, singleProviderPolicy } from './policy.ts';

export interface Runtime {
  mode: PricesMode; store: PriceStore; bus: PriceBus; ingestor: Ingestor; audit: AuditSink;
  demo?: ReturnType<typeof createDemoAdapter>;
  loginLimiter: ReturnType<typeof createRateLimiter>;
  sse: { open: number };
  config: ConfigStore;
  meter: ReturnType<typeof createActivityMeter>;
}

/** One runtime per Node process (survives HMR). Requires a long-running server; for serverless run the ingestor as a worker + shared bus. */
const g = globalThis as unknown as { __bz?: Runtime };

export function getRuntime(): Runtime {
  if (g.__bz) return g.__bz;
  const e = env();
  const store = createStore();
  const bus = createMemoryBus();
  const audit = createMemoryAudit();
  const processEnv = process.env as Record<string, string | undefined>;
  let adapters: ProviderAdapter[] = [];
  let demo: ReturnType<typeof createDemoAdapter> | undefined;
  let policy = parsePolicy(e.PRICE_POLICY);

  if (e.PRICE_MODE === 'demo') {
    demo = createDemoAdapter();
    adapters = [demo];
    policy = singleProviderPolicy('demo');
  } else if (e.PRICE_MODE === 'live') {
    const enabled = new Set(e.PROVIDERS_ENABLED.split(',').map((s) => s.trim()).filter(Boolean));
    adapters = [createTalasanj(processEnv), createArzhaam(processEnv), createNerkhAra(processEnv)].filter((a) => enabled.has(a.id));
    // One provider and no explicit policy: it is primary for every group (still no blending).
    if (adapters.length === 1 && Object.keys(policy).length === 0) policy = singleProviderPolicy((adapters[0] as ProviderAdapter).id);
  }
  const meter = createActivityMeter();
  bus.subscribe((r) => meter.record(r.length));
  const ingestor = new Ingestor({ adapters, policy, store, bus, defaultIntervalSec: e.DEFAULT_INTERVAL_SEC, onError: (id, msg) => audit.record({ actor: 'system', action: 'provider.error', target: id, detail: msg }) });
  ingestor.start();
  return (g.__bz = { mode: e.PRICE_MODE, store, bus, ingestor, audit, demo, loginLimiter: createRateLimiter(5, 60_000), sse: { open: 0 }, config: createConfigStore(join(e.DATA_DIR, 'site.json')), meter });
}
