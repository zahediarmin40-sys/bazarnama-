import type { PriceRecord } from '../../core/types.ts';

export type BusListener = (records: PriceRecord[]) => void;
/** Swap for a Redis/NATS implementation when running more than one server instance. */
export interface PriceBus {
  publish(records: PriceRecord[]): void;
  subscribe(fn: BusListener): () => void;
  listenerCount(): number;
}
export function createMemoryBus(): PriceBus {
  const subs = new Set<BusListener>();
  return {
    publish(records) { for (const f of [...subs]) { try { f(records); } catch { /* one bad subscriber must not break others */ } } },
    subscribe(fn) { subs.add(fn); return () => { subs.delete(fn); }; },
    listenerCount: () => subs.size,
  };
}
