import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.string().default('development'),
  PRICE_MODE: z.enum(['none', 'demo', 'live']).default('none'),
  ALLOW_DEMO_IN_PRODUCTION: z.string().optional(),
  PROVIDERS_ENABLED: z.string().default(''),
  PRICE_POLICY: z.string().default('{}'),
  DEFAULT_INTERVAL_SEC: z.coerce.number().int().min(3).max(600).default(20),
  MAX_SSE_CONNECTIONS: z.coerce.number().int().min(1).default(2000),
  TALASANJ_BASE_URL: z.string().optional(), TALASANJ_API_KEY: z.string().optional(),
  ARZHAAM_BASE_URL: z.string().optional(), ARZHAAM_API_KEY: z.string().optional(),
  NERKHARA_BASE_URL: z.string().optional(), NERKHARA_API_KEY: z.string().optional(),
  ADMIN_JWT_SECRET: z.string().min(32).optional(),
  ADMIN_USERS: z.string().default('[]'),
  ADMIN_OWNER_EMAIL: z.string().email().optional(),
  DATA_DIR: z.string().default('./data'),
  DATABASE_URL: z.string().optional(),
});
export type Env = z.infer<typeof schema>;

let cached: Env | undefined;
export function env(): Env {
  if (cached) return cached;
  const e = schema.parse(process.env);
  if (e.NODE_ENV === 'production' && e.PRICE_MODE === 'demo' && e.ALLOW_DEMO_IN_PRODUCTION !== '1') {
    throw new Error('PRICE_MODE=demo is refused in production (fake prices must never look real). Set PRICE_MODE=none or live.');
  }
  return (cached = e);
}
