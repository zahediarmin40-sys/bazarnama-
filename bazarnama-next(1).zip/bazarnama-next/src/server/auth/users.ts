import { isRole, type Role } from './rbac.ts';
import { verifyPassword } from './password.ts';
import { verifyTotp } from './totp.ts';

export interface AdminUser { email: string; hash: string; role: Role; totpSecret?: string }
export type AuthResult = { status: 'ok'; user: AdminUser } | { status: 'totp-required' } | { status: 'invalid' };

export const normalizeEmail = (e: string): string => e.trim().toLowerCase();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** The owner email (ADMIN_OWNER_EMAIL) is always full admin, whatever role the JSON says. */
export function parseUsers(json: string, ownerEmail?: string): AdminUser[] {
  let raw: unknown;
  try { raw = JSON.parse(json || '[]'); } catch { return []; }
  if (!Array.isArray(raw)) return [];
  const owner = ownerEmail ? normalizeEmail(ownerEmail) : undefined;
  const users: AdminUser[] = [];
  for (const u of raw as Array<Record<string, unknown>>) {
    if (typeof u?.email !== 'string' || typeof u?.hash !== 'string' || !EMAIL.test(u.email.trim())) continue;
    const email = normalizeEmail(u.email);
    const role = email === owner ? 'admin' : u.role;
    if (!isRole(role)) continue;
    users.push({ email, hash: u.hash, role, totpSecret: typeof u.totpSecret === 'string' && u.totpSecret ? u.totpSecret : undefined });
  }
  return users;
}

const DUMMY = 'scrypt$16384$AAAAAAAAAAAAAAAAAAAAAA==$' + 'AA=='.repeat(22);
/** Always burns one password verification (dummy hash for unknown emails) to keep timing uniform. */
export async function authenticate(users: AdminUser[], email: string, password: string, totp?: string, now: number = Date.now()): Promise<AuthResult> {
  const u = users.find((x) => x.email === normalizeEmail(email));
  const ok = await verifyPassword(password, u?.hash ?? DUMMY).catch(() => false);
  if (!u || !ok) return { status: 'invalid' };
  if (u.totpSecret) {
    if (!totp) return { status: 'totp-required' };
    if (!verifyTotp(u.totpSecret, totp.trim(), now)) return { status: 'invalid' };
  }
  return { status: 'ok', user: u };
}
