import { NextResponse, type NextRequest } from 'next/server';
import { can, type Permission } from './rbac.ts';
import { sameOrigin } from './origin.ts';
import { SESSION_COOKIE, verifySession, type Session } from './session.ts';

export type Guard = { ok: true; session: Session } | { ok: false; res: NextResponse };

/** Session + permission + (for mutations) same-origin check. Every admin handler starts with this. */
export async function requireAdmin(req: NextRequest, perm: Permission): Promise<Guard> {
  const session = await verifySession(req.cookies.get(SESSION_COOKIE)?.value, process.env.ADMIN_JWT_SECRET);
  if (!session) return { ok: false, res: NextResponse.json({ error: 'unauthorized' }, { status: 401 }) };
  if (!can(session.role, perm)) return { ok: false, res: NextResponse.json({ error: 'forbidden' }, { status: 403 }) };
  if (req.method !== 'GET' && !sameOrigin(req.headers.get('origin'), req.headers.get('host'))) return { ok: false, res: NextResponse.json({ error: 'bad-origin' }, { status: 403 }) };
  return { ok: true, session };
}
export function errorResponse(e: unknown): NextResponse {
  const err = e as { name?: string; field?: string; message?: string };
  if (err?.name === 'ValidationError') return NextResponse.json({ error: 'validation', field: err.field, message: err.message }, { status: 400 });
  return NextResponse.json({ error: 'server-error' }, { status: 500 });
}
