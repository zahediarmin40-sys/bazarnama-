import { SignJWT, jwtVerify } from 'jose';
import { isRole, type Role } from './rbac.ts';

export const SESSION_COOKIE = 'bz_session';
export const SESSION_TTL_SEC = 60 * 60 * 8;
export interface Session { sub: string; role: Role }

const key = (secret: string) => new TextEncoder().encode(secret);

export async function signSession(s: Session, secret: string): Promise<string> {
  return new SignJWT({ role: s.role }).setProtectedHeader({ alg: 'HS256' }).setSubject(s.sub).setIssuedAt().setExpirationTime(`${SESSION_TTL_SEC}s`).sign(key(secret));
}
export async function verifySession(token: string | undefined, secret: string | undefined): Promise<Session | null> {
  if (!token || !secret) return null;
  try {
    const { payload } = await jwtVerify(token, key(secret), { algorithms: ['HS256'] });
    return payload.sub && isRole(payload.role) ? { sub: payload.sub, role: payload.role } : null;
  } catch { return null; }
}
