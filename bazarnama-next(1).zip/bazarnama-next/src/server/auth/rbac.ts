export type Role = 'admin' | 'editor' | 'operator';
export type Permission = 'providers:view' | 'providers:manage' | 'content:edit' | 'news:publish' | 'audit:view' | 'users:manage';

const MATRIX: Record<Role, readonly Permission[]> = {
  admin: ['providers:view', 'providers:manage', 'content:edit', 'news:publish', 'audit:view', 'users:manage'],
  editor: ['content:edit', 'news:publish', 'providers:view'],
  operator: ['providers:view', 'providers:manage', 'audit:view'],
};
export const isRole = (r: unknown): r is Role => r === 'admin' || r === 'editor' || r === 'operator';
export const can = (role: Role | undefined, perm: Permission): boolean => (role ? MATRIX[role].includes(perm) : false);
