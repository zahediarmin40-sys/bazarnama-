import { randomBytes, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';

const N = 16384, KEYLEN = 64;
const scrypt = (pw: string, salt: Buffer, n: number): Promise<Buffer> =>
  new Promise((res, rej) => scryptCb(pw, salt, KEYLEN, { N: n }, (e, k) => (e ? rej(e) : res(k))));

/** Format: scrypt$N$saltB64$hashB64 */
export async function hashPassword(pw: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scrypt(pw, salt, N);
  return `scrypt$${N}$${salt.toString('base64')}$${key.toString('base64')}`;
}
export async function verifyPassword(pw: string, stored: string): Promise<boolean> {
  const [alg, n, s, h] = stored.split('$');
  if (alg !== 'scrypt' || !n || !s || !h) return false;
  const expected = Buffer.from(h, 'base64');
  const key = await scrypt(pw, Buffer.from(s, 'base64'), Number(n));
  return key.length === expected.length && timingSafeEqual(key, expected);
}
