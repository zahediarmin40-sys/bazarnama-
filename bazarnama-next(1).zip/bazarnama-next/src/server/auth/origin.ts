/** CSRF defence in depth (cookies are already SameSite=Strict): mutating requests must come from our own origin. */
export function sameOrigin(origin: string | null, host: string | null): boolean {
  if (!origin || !host) return false;
  try { return new URL(origin).host === host; } catch { return false; }
}
