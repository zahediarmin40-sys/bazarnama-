import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function base32Encode(buf: Uint8Array): string {
  let bits = 0, value = 0, out = '';
  for (const b of buf) { value = (value << 8) | b; bits += 8; while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
export function base32Decode(s: string): Buffer {
  const clean = s.replace(/=+$/g, '').replace(/\s+/g, '').toUpperCase();
  let bits = 0, value = 0; const out: number[] = [];
  for (const ch of clean) { const i = B32.indexOf(ch); if (i < 0) throw new Error('invalid base32'); value = (value << 5) | i; bits += 5; if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
export const generateTotpSecret = (): string => base32Encode(randomBytes(20));

export function hotp(secret: string, counter: number, digits = 6): string {
  const msg = Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(counter));
  const h = createHmac('sha1', base32Decode(secret)).update(msg).digest();
  const off = (h[h.length - 1] as number) & 15;
  const code = (((h[off] as number) & 0x7f) << 24) | ((h[off + 1] as number) << 16) | ((h[off + 2] as number) << 8) | (h[off + 3] as number);
  return String(code % 10 ** digits).padStart(digits, '0');
}
/** RFC 6238, 30s step, +-1 step tolerance. Constant-time compare. */
export function verifyTotp(secret: string, code: string, nowMs: number = Date.now(), window = 1): boolean {
  if (!/^\d{6}$/.test(code)) return false;
  const step = Math.floor(nowMs / 30000);
  let ok = false;
  for (let w = -window; w <= window; w++) {
    const exp = Buffer.from(hotp(secret, step + w)); const got = Buffer.from(code);
    if (exp.length === got.length && timingSafeEqual(exp, got)) ok = true;
  }
  return ok;
}
export const otpauthUri = (email: string, secret: string, issuer = 'Bazarnama'): string =>
  `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(email)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&digits=6&period=30`;
