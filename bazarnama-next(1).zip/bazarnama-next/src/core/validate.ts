import type { Currency, DataStatus, MarketType, PriceMeta, PriceRecord, Unit } from './types.ts';

const CURRENCIES: readonly Currency[] = ['IRT', 'IRR', 'USD'];
const STATUSES: readonly DataStatus[] = ['live', 'delayed', 'stale', 'indicative', 'unavailable'];
export type ValidationResult = { ok: true; rec: PriceRecord } | { ok: false; reason: string };

const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const numOrNull = (v: unknown): number | null | 'bad' => (v === null || v === undefined ? null : num(v) ? v : 'bad');

/** Last line of defence for ALL external data. Rejects instead of repairing. */
export function validateRecord(r: unknown): ValidationResult {
  if (typeof r !== 'object' || r === null) return { ok: false, reason: 'not-object' };
  const x = r as Record<string, unknown>;
  if (typeof x.assetId !== 'string' || !x.assetId) return { ok: false, reason: 'assetId' };
  if (x.price !== null && !(num(x.price) && x.price > 0)) return { ok: false, reason: 'price' };
  if (!CURRENCIES.includes(x.currency as Currency)) return { ok: false, reason: 'currency' };
  if (!num(x.updatedAt)) return { ok: false, reason: 'updatedAt' };
  const f = { change: numOrNull(x.change), changePercent: numOrNull(x.changePercent), low: numOrNull(x.low), high: numOrNull(x.high) };
  for (const [k, v] of Object.entries(f)) if (v === 'bad') return { ok: false, reason: k };
  const price = x.price as number | null;
  if (x.expectedIntervalSec !== undefined && !(num(x.expectedIntervalSec) && x.expectedIntervalSec > 0)) return { ok: false, reason: 'expectedIntervalSec' };
  const m = (typeof x.meta === 'object' && x.meta !== null ? x.meta : undefined) as Record<string, unknown> | undefined;
  const meta: PriceMeta | undefined = m ? {
    method: typeof m.method === 'string' ? m.method.slice(0, 40) : undefined,
    sources: num(m.sources) ? m.sources : null,
    spreadPct: num(m.spreadPct) ? m.spreadPct : null,
    asOf: typeof m.asOf === 'string' ? m.asOf.slice(0, 20) : null,
  } : undefined;
  return {
    ok: true,
    rec: {
      expectedIntervalSec: x.expectedIntervalSec as number | undefined,
      meta,
      assetId: x.assetId,
      price,
      unit: x.unit as Unit,
      currency: x.currency as Currency,
      change: f.change as number | null,
      changePercent: f.changePercent as number | null,
      low: f.low as number | null,
      high: f.high as number | null,
      source: typeof x.source === 'string' && x.source ? x.source : '—',
      updatedAt: x.updatedAt,
      marketType: (typeof x.marketType === 'string' ? x.marketType : 'free') as MarketType,
      dataStatus: price === null ? 'unavailable' : STATUSES.includes(x.dataStatus as DataStatus) ? (x.dataStatus as DataStatus) : 'live',
    },
  };
}
