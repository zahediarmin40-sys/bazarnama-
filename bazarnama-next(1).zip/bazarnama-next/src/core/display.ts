import type { Asset, Currency, DisplayStatus, PriceRecord } from './types.ts';
import { computeStatus } from './status.ts';
import { convertIran, massFactor, type MassUnit } from './units.ts';

export interface DisplayPrefs { currency: 'IRT' | 'IRR'; goldUnit: 'gram' | 'mesghal' | 'kilogram' }
export interface DisplayRow {
  asset: Asset;
  record: PriceRecord | null;
  status: DisplayStatus;
  currency: Currency;
  unit: Asset['unit'];
  price: number | null;
  change: number | null;
  changePercent: number | null;
  low: number | null;
  high: number | null;
}

/** The only place where unit/currency display conversion happens. */
export function toDisplay(asset: Asset, rec: PriceRecord | null, prefs: DisplayPrefs, now: number, intervalSec: number): DisplayRow {
  const status = computeStatus(rec, now, intervalSec);
  if (!rec || rec.price === null) {
    return { asset, record: null, status, currency: asset.currency === 'USD' ? 'USD' : prefs.currency, unit: asset.unit, price: null, change: null, changePercent: null, low: null, high: null };
  }
  const goldUnit: MassUnit | null = asset.category === 'gold' ? prefs.goldUnit : null;
  const f = goldUnit ? massFactor(goldUnit) : 1;
  const conv = (v: number | null): number | null => {
    if (v === null) return null;
    const x = v * f;
    return rec.currency === 'USD' ? x : convertIran(x, rec.currency, prefs.currency);
  };
  return {
    asset, record: rec, status,
    currency: rec.currency === 'USD' ? 'USD' : prefs.currency,
    unit: goldUnit ?? asset.unit,
    price: conv(rec.price), change: conv(rec.change), changePercent: rec.changePercent,
    low: conv(rec.low), high: conv(rec.high),
  };
}
