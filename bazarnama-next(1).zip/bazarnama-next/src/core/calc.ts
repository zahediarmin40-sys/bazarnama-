import { massFactor, type MassUnit } from './units.ts';

export const goldValue = (weight: number, unit: MassUnit, pricePerGram: number): number => weight * massFactor(unit) * pricePerGram;

/** Converts via Toman. Result is a CALCULATED value and must be labelled as such in the UI. */
export function convertViaToman(amount: number, fromTomanPerUnit: number, toTomanPerUnit: number): number {
  if (!(fromTomanPerUnit > 0) || !(toTomanPerUnit > 0)) throw new Error('invalid rate');
  return (amount * fromTomanPerUnit) / toTomanPerUnit;
}
