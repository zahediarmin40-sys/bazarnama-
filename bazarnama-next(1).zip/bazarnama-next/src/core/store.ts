import type { PriceRecord } from './types.ts';
import { validateRecord } from './validate.ts';

export type IngestResult = 'ok' | 'out-of-order' | 'null-ignored' | `invalid:${string}`;
export interface HistoryPoint { t: number; p: number }

/** In-memory price book. Keeps the last valid value + its own timestamp so stale data is never disguised as live. */
export function createStore(maxHistory = 400) {
  const records = new Map<string, PriceRecord>();
  const history = new Map<string, HistoryPoint[]>();
  return {
    ingest(raw: unknown): IngestResult {
      const v = validateRecord(raw);
      if (!v.ok) return `invalid:${v.reason}`;
      const rec = v.rec;
      const cur = records.get(rec.assetId);
      if (cur && rec.updatedAt < cur.updatedAt) return 'out-of-order';
      if (rec.price === null && cur && cur.price !== null) return 'null-ignored';
      records.set(rec.assetId, rec);
      if (rec.price !== null) {
        const a = history.get(rec.assetId) ?? [];
        if (!a.length || a[a.length - 1]!.t !== rec.updatedAt) {
          a.push({ t: rec.updatedAt, p: rec.price });
          if (a.length > maxHistory) a.shift();
          history.set(rec.assetId, a);
        }
      }
      return 'ok';
    },
    get: (id: string): PriceRecord | null => records.get(id) ?? null,
    all: (): PriceRecord[] => [...records.values()],
    history: (id: string): readonly HistoryPoint[] => history.get(id) ?? [],
    clear(): void { records.clear(); history.clear(); },
    size: (): number => records.size,
  };
}
export type PriceStore = ReturnType<typeof createStore>;

/** Client-side merge: newer wins, older is dropped. */
export function mergeRecords(base: ReadonlyMap<string, PriceRecord>, incoming: readonly PriceRecord[]): Map<string, PriceRecord> {
  const next = new Map(base);
  for (const r of incoming) {
    const cur = next.get(r.assetId);
    if (!cur || r.updatedAt >= cur.updatedAt) next.set(r.assetId, r);
  }
  return next;
}
