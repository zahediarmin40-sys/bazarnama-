import { toLatin } from './format.ts';

/** Normalizes Persian/Arabic variants, digits, ZWNJ and spaces so "سكه", "سکه", "سکه " all match. */
export function normText(s: string): string {
  return toLatin(s || '')
    .replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/ؤ/g, 'و').replace(/[أإآ]/g, 'ا').replace(/[ۀة]/g, 'ه')
    .replace(/[\u064B-\u0652\u0640]/g, '')
    .replace(/[\u200c\u200f\u200e\s]+/g, '')
    .toLowerCase();
}

export interface Searchable { name: string; tag?: string; code?: string; aliases: readonly string[] }
export function matches(a: Searchable, q: string): boolean {
  const n = normText(q);
  if (!n) return false;
  return [a.name, a.tag ?? '', a.code ?? '', ...a.aliases].some((x) => normText(x).includes(n));
}
