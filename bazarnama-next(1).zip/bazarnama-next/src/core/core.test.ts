import test from 'node:test';
import assert from 'node:assert/strict';
import { convertIran, convertMass, goldValue, fmt, fmtSigned, parseNum, computeStatus, worstStatus, createStore, mergeRecords, validateRecord, matches, normText, toDisplay, convertViaToman } from './index.ts';
import type { Asset, PriceRecord } from './index.ts';

const rec = (o: Partial<PriceRecord> = {}): PriceRecord => ({ assetId: 'x', price: 100, unit: 'gram', currency: 'IRT', change: 1, changePercent: 1, low: null, high: null, source: 's', updatedAt: 1000, marketType: 'free-local', dataStatus: 'live', ...o });

test('toman/rial', () => {
  assert.equal(convertIran(1000, 'IRT', 'IRR'), 10000);
  assert.equal(convertIran(10000, 'IRR', 'IRT'), 1000);
  assert.throws(() => convertIran(1, 'USD', 'IRT'));
});
test('formatting and parsing', () => {
  assert.equal(fmt(1234567), '۱٬۲۳۴٬۵۶۷');
  assert.equal(fmt(1234.5, { digits: 'en', min: 2 }), '1,234.50');
  assert.equal(fmt(null), '—');
  assert.equal(fmtSigned(-5, { digits: 'en' }), '−5');
  assert.equal(parseNum('۱٬۲۰۰٫۵'), 1200.5);
  assert.ok(Number.isNaN(parseNum('abc')));
});
test('mass units', () => {
  assert.ok(Math.abs(convertMass(1, 'mesghal', 'gram') - 4.6083) < 1e-9);
  assert.ok(Math.abs(goldValue(2, 'mesghal', 100) - 921.66) < 1e-6);
});
test('status derives staleness from the clock', () => {
  const r = rec({ updatedAt: 100000 });
  assert.equal(computeStatus(r, 105000, 5), 'live');
  assert.equal(computeStatus(r, 125000, 5), 'delayed');
  assert.equal(computeStatus(r, 200000, 5), 'stale');
  assert.equal(computeStatus(null, 0, 5), 'unavailable');
  assert.equal(computeStatus(rec({ updatedAt: 100000, dataStatus: 'delayed' }), 100000, 5), 'delayed');
  assert.equal(worstStatus(['live', 'stale']), 'stale');
});
test('validation rejects bad external data', () => {
  assert.ok(validateRecord(rec()).ok);
  for (const bad of [{ price: -1 }, { price: NaN }, { price: 0 }, { currency: 'EUR' }, { updatedAt: 'x' }, { change: Infinity }]) {
    assert.equal(validateRecord(rec(bad as Partial<PriceRecord>)).ok, false, JSON.stringify(bad));
  }
  const n = validateRecord(rec({ price: null }));
  assert.ok(n.ok && n.rec.dataStatus === 'unavailable');
  assert.equal(validateRecord(null).ok, false);
});
test('store: out-of-order, null price, history', () => {
  const s = createStore();
  assert.equal(s.ingest(rec()), 'ok');
  assert.equal(s.ingest(rec({ updatedAt: 500, price: 50 })), 'out-of-order');
  assert.equal(s.get('x')?.price, 100);
  assert.equal(s.ingest(rec({ updatedAt: 2000, price: null })), 'null-ignored');
  assert.equal(s.get('x')?.updatedAt, 1000);
  assert.equal(s.ingest(rec({ updatedAt: 3000, price: 110 })), 'ok');
  assert.equal(s.history('x').length, 2);
  assert.ok(s.ingest(rec({ price: 0 })).startsWith('invalid'));
});
test('mergeRecords: newer wins', () => {
  const m = mergeRecords(new Map([['x', rec({ updatedAt: 10, price: 1 })]]), [rec({ updatedAt: 5, price: 9 }), rec({ assetId: 'y', updatedAt: 1 })]);
  assert.equal(m.get('x')?.price, 1);
  assert.ok(m.has('y'));
});
test('search normalization', () => {
  assert.ok(matches({ name: 'دلار آمریکا', aliases: ['dollar'] }, 'دلار'));
  assert.ok(matches({ name: 'سکه امامی', aliases: [] }, 'سكه'));
  assert.ok(matches({ name: 'طلای ۱۸ عیار', tag: '18K', aliases: [] }, '18'));
  assert.ok(matches({ name: 'نیم سکه', aliases: ['نیم‌سکه'] }, 'نیم سکه'));
  assert.ok(!matches({ name: 'یورو', aliases: [] }, ''));
  assert.equal(normText('سكه'), normText('سکه'));
});
test('toDisplay converts currency + gold unit explicitly', () => {
  const asset: Asset = { id: 'gold-18', category: 'gold', group: 'gold', name: 'طلا', unit: 'gram', currency: 'IRT', marketType: 'free-local', aliases: [] };
  const r = rec({ assetId: 'gold-18', price: 1000, change: 10, updatedAt: 1000 });
  const a = toDisplay(asset, r, { currency: 'IRR', goldUnit: 'mesghal' }, 1000, 20);
  assert.ok(Math.abs((a.price ?? 0) - 1000 * 10 * 4.6083) < 1e-6);
  assert.equal(a.unit, 'mesghal');
  assert.equal(a.changePercent, 1);
  const none = toDisplay(asset, null, { currency: 'IRT', goldUnit: 'gram' }, 0, 20);
  assert.equal(none.status, 'unavailable');
});
test('convertViaToman', () => {
  assert.equal(convertViaToman(2, 100, 50), 4);
  assert.throws(() => convertViaToman(1, 0, 1));
});

test('status: per-record cadence, provider stale flag, provenance metadata', () => {
  const slow = rec({ updatedAt: 0, expectedIntervalSec: 600, dataStatus: 'delayed' });
  assert.equal(computeStatus(slow, 100_000, 20), 'delayed');          // 10-min feed is never shown as live
  assert.equal(computeStatus({ ...slow, dataStatus: 'live' }, 100_000, 20), 'live'); // same age is fine for a 10-min cadence
  assert.equal(computeStatus({ ...slow, dataStatus: 'live' }, 3_000_000, 20), 'delayed');
  assert.equal(computeStatus({ ...slow, dataStatus: 'live' }, 5_000_000, 20), 'stale');
  assert.equal(computeStatus(rec({ dataStatus: 'stale', updatedAt: 1000 }), 1000, 20), 'stale');
  const v = validateRecord(rec({ meta: { method: 'average', sources: 2, spreadPct: 0.1, asOf: null }, expectedIntervalSec: 600 }));
  assert.ok(v.ok && v.rec.meta?.sources === 2 && v.rec.expectedIntervalSec === 600);
  assert.equal(validateRecord(rec({ expectedIntervalSec: -1 })).ok, false);
  assert.equal(validateRecord(rec({ dataStatus: 'stale' })).ok && true, true);
});
