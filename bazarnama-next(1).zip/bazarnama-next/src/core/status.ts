import type { DisplayStatus, PriceRecord } from './types.ts';

export const LIVE_FACTOR = 2;
export const DELAYED_FACTOR = 6;

/** live <= 2x interval, delayed <= 6x, otherwise stale. Provider flags can only make the status worse. */
export function computeStatus(rec: PriceRecord | null | undefined, now: number, intervalSec: number): DisplayStatus {
  if (!rec || rec.price === null || rec.dataStatus === 'unavailable') return 'unavailable';
  if (rec.dataStatus === 'stale') return 'stale'; // the provider itself says the figure is too old
  if (rec.dataStatus === 'indicative') return 'indicative';
  const interval = rec.expectedIntervalSec ?? intervalSec;
  const age = (now - rec.updatedAt) / 1000;
  let s: DisplayStatus = age <= LIVE_FACTOR * interval ? 'live' : age <= DELAYED_FACTOR * interval ? 'delayed' : 'stale';
  if (s === 'live' && rec.dataStatus === 'delayed') s = 'delayed';
  return s;
}

const RANK: DisplayStatus[] = ['unavailable', 'stale', 'delayed', 'indicative', 'live'];
export const worstStatus = (list: DisplayStatus[]): DisplayStatus => RANK.find((s) => list.includes(s)) ?? 'live';
