export type Digits = 'fa' | 'en';
const FA = '۰۱۲۳۴۵۶۷۸۹';
const AR = '٠١٢٣٤٥٦٧٨٩';

export const toFa = (s: string | number): string => String(s).replace(/\d/g, (d) => FA[Number(d)] ?? d);
export const toLatin = (s: string): string =>
  s.replace(/[۰-۹]/g, (d) => String(FA.indexOf(d))).replace(/[٠-٩]/g, (d) => String(AR.indexOf(d)));

export interface FmtOptions { digits?: Digits; min?: number; max?: number }

export function fmt(n: number | null | undefined, o: FmtOptions = {}): string {
  const { digits = 'fa', min = 0, max = min } = o;
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  let s = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: min, maximumFractionDigits: max });
  if (digits === 'fa') s = toFa(s).replace(/,/g, '٬').replace(/\./g, '٫');
  return (n < 0 ? '−' : '') + s;
}

export function fmtSigned(n: number | null | undefined, o: FmtOptions = {}): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  const s = fmt(Math.abs(n), o);
  return n > 0 ? '+' + s : n < 0 ? '−' + s : s;
}

/** Parses user input that may contain Persian/Arabic digits and separators. NaN when invalid. */
export function parseNum(s: string): number {
  const t = toLatin(s).replace(/[٬,\s]/g, '').replace(/٫/g, '.');
  if (!/^-?\d*\.?\d+$/.test(t)) return NaN;
  return Number(t);
}
