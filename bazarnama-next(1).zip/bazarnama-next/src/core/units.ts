import type { Currency } from './types.ts';

export const MESGHAL_G = 4.6083;
export const OUNCE_G = 31.1034768; // troy ounce
export type MassUnit = 'gram' | 'mesghal' | 'ounce' | 'kilogram';
const GRAMS: Record<MassUnit, number> = { gram: 1, mesghal: MESGHAL_G, ounce: OUNCE_G, kilogram: 1000 };

export const massFactor = (u: MassUnit): number => GRAMS[u];
export const convertMass = (v: number, from: MassUnit, to: MassUnit): number => (v * GRAMS[from]) / GRAMS[to];

/** 1 Toman = 10 Rials. Explicit conversion only; any other pair throws instead of guessing. */
export function convertIran(v: number, from: Currency, to: Currency): number {
  if (from === to) return v;
  if (from === 'IRT' && to === 'IRR') return v * 10;
  if (from === 'IRR' && to === 'IRT') return v / 10;
  throw new Error(`convertIran: unsupported ${from}->${to}`);
}
