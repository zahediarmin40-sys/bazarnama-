export type Currency = 'IRT' | 'IRR' | 'USD';
export type Unit = 'gram' | 'mesghal' | 'ounce' | 'kilogram' | 'piece' | 'fx';
export type MarketType = 'free-local' | 'free' | 'exchange' | 'official' | 'transfer' | 'cash' | 'world' | 'calculated';
/** What the provider claims. "stale" is never claimed by a provider: it is derived from the clock. */
export type DataStatus = 'live' | 'delayed' | 'stale' | 'indicative' | 'unavailable';
export type DisplayStatus = DataStatus;

/** Normalized record. Every provider adapter must produce exactly this shape. */
export interface PriceRecord {
  assetId: string;
  price: number | null;
  unit: Unit;
  currency: Currency;
  change: number | null;
  changePercent: number | null;
  low: number | null;
  high: number | null;
  source: string;
  /** epoch ms of the provider's own timestamp (not our receive time) */
  updatedAt: number;
  marketType: MarketType;
  dataStatus: DataStatus;
  /** How often the provider really refreshes this figure. Status windows scale from it (default: site interval). */
  expectedIntervalSec?: number;
  /** Provenance details shown to the reader (how the number was made). */
  meta?: PriceMeta;
}
export interface PriceMeta { method?: string; sources?: number | null; spreadPct?: number | null; asOf?: string | null }

export type PriceGroup = 'usd-free' | 'fx-free' | 'fx-exchange' | 'gold' | 'coin' | 'world-metals';
export type AssetCategory = 'gold' | 'coin' | 'fx' | 'world';

export interface Asset {
  id: string;
  category: AssetCategory;
  group: PriceGroup;
  name: string;
  tag?: string;
  unit: Unit;
  currency: Currency;
  marketType: MarketType;
  aliases: readonly string[];
  code?: string;
  fxName?: string;
  purity?: number;
  /** reference specification; must be verified against an authoritative source before publishing */
  spec?: { weightG: number; purity: number; fineG: number };
}

export type PricesMode = 'none' | 'demo' | 'live';
export interface PricesPayload {
  mode: PricesMode;
  intervalSec: number;
  serverTime: number;
  records: PriceRecord[];
}
