import Link from 'next/link';
export function NotConnected() {
  return (
    <div className="panel empty">
      <b>قیمت‌های زنده هنوز متصل نشده است.</b>
      <p>هیچ عدد نمونه‌ای به‌جای قیمت واقعی نمایش داده نمی‌شود. ارائه‌دهنده را در <Link href="/admin">تنظیمات داده</Link> فعال کنید.</p>
    </div>
  );
}
