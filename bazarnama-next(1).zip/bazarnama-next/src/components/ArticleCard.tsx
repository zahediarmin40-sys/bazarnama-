import Link from 'next/link';
import type { Article } from '@/server/config/types';

export const faDate = (t: number): string => new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Tehran' }).format(new Date(t));
export function ArticleCard({ a }: { a: Article }) {
  return (
    <article className="panel" style={{ padding: 16 }}>
      <div className="mini" style={{ marginTop: 0 }}><span className="chip">{a.category}</span><time dateTime={new Date(a.publishedAt).toISOString()}>{faDate(a.publishedAt)}</time><span>· {a.source}</span></div>
      <h3 style={{ margin: '.5rem 0 .2rem', fontSize: '1.1rem' }}><Link href={`/news/${a.slug}`} style={{ textDecoration: 'none' }}>{a.title}</Link></h3>
      <p style={{ margin: 0, color: 'var(--mute)' }}>{a.summary}</p>
    </article>
  );
}
