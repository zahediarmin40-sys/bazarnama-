'use client';
import { useEffect, useState } from 'react';

function parts(now: Date) {
  return {
    date: new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full', timeZone: 'Asia/Tehran' }).format(now),
    time: new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Tehran' }).format(now),
  };
}
export function MarketClock({ date, time }: { date: string; time: string }) {
  const [clock, setClock] = useState({ date, time });
  useEffect(() => {
    const tick = () => setClock(parts(new Date()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return <div className="market-clock"><span>{clock.date}</span><strong>{clock.time}</strong></div>;
}
