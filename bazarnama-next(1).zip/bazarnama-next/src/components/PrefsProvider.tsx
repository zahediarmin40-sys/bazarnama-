'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { PREFS_COOKIE, serializePrefs, type Prefs } from '@/lib/prefs';

interface Ctx { prefs: Prefs; set: (p: Partial<Prefs>) => void }
const PrefsCtx = createContext<Ctx | null>(null);

export function PrefsProvider({ initial, children }: { initial: Prefs; children: ReactNode }) {
  const [prefs, setPrefs] = useState(initial);
  const set = useCallback((p: Partial<Prefs>) => {
    setPrefs((cur) => {
      const next = { ...cur, ...p };
      document.cookie = `${PREFS_COOKIE}=${serializePrefs(next)}; path=/; max-age=31536000; samesite=lax`;
      return next;
    });
  }, []);
  useEffect(() => {
    const r = document.documentElement;
    if (prefs.theme === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', prefs.theme);
  }, [prefs.theme]);
  const value = useMemo(() => ({ prefs, set }), [prefs, set]);
  return <PrefsCtx.Provider value={value}>{children}</PrefsCtx.Provider>;
}
export function usePrefs(): Ctx {
  const c = useContext(PrefsCtx);
  if (!c) throw new Error('usePrefs outside PrefsProvider');
  return c;
}
