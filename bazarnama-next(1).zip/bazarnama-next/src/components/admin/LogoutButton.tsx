'use client';
import { useRouter } from 'next/navigation';
import { Icon } from './icons';
export function LogoutButton() {
  const r = useRouter();
  return (
    <button type="button" className="adm-btn" onClick={async () => { await fetch('/api/admin/logout', { method: 'POST' }); r.push('/admin/login'); r.refresh(); }}>
      <Icon name="out" size={18} />خروج
    </button>
  );
}
