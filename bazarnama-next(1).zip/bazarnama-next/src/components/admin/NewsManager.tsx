'use client';
import { useState } from 'react';
import { NEWS_CATEGORIES, type Article } from '@/server/config/types';
import { Toggle } from './Toggle';

type Draft = { id?: string; title: string; slug: string; summary: string; body: string; category: string; source: string; published: boolean };
const EMPTY: Draft = { title: '', slug: '', summary: '', body: '', category: NEWS_CATEGORIES[0], source: '', published: false };
const fa = (t: number) => new Date(t).toLocaleString('fa-IR', { timeZone: 'Asia/Tehran' });

export function NewsManager({ initial, canPublish }: { initial: Article[]; canPublish: boolean }) {
  const [list, setList] = useState(initial);
  const [d, setD] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function save() {
    if (!d) return;
    setBusy(true); setMsg(null);
    try {
      const r = await fetch(d.id ? `/api/admin/news/${d.id}` : '/api/admin/news', { method: d.id ? 'PUT' : 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(d) });
      const j = (await r.json()) as { article?: Article; message?: string };
      if (r.ok && j.article) { const a = j.article; setList((l) => [a, ...l.filter((x) => x.id !== a.id)].sort((x, y) => y.publishedAt - x.publishedAt)); setD(null); setMsg({ ok: true, text: a.published ? 'خبر منتشر شد.' : 'پیش‌نویس ذخیره شد.' }); }
      else setMsg({ ok: false, text: j.message ?? (r.status === 403 ? 'اجازه‌ی انتشار ندارید.' : `خطا (${r.status})`) });
    } finally { setBusy(false); }
  }
  async function del(a: Article) {
    if (!confirm(`«${a.title}» حذف شود؟`)) return;
    const r = await fetch(`/api/admin/news/${a.id}`, { method: 'DELETE' });
    if (r.ok) { setList((l) => l.filter((x) => x.id !== a.id)); setMsg({ ok: true, text: 'حذف شد.' }); } else setMsg({ ok: false, text: 'حذف نشد.' });
  }
  const f = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((x) => (x ? { ...x, [k]: v } : x));

  return (
    <div className="adm-grid">
      {msg && <div className={`adm-msg ${msg.ok ? 'ok' : 'err'}`} role="status">{msg.text}</div>}
      {!d && <div><button className="adm-btn pri" type="button" onClick={() => setD(EMPTY)}>＋ خبر تازه</button></div>}
      {d && (
        <div className="adm-card">
          <h2>{d.id ? 'ویرایش خبر' : 'خبر تازه'}</h2>
          <div className="adm-field"><label htmlFor="nt">تیتر</label><input id="nt" value={d.title} maxLength={150} onChange={(e) => f('title', e.target.value)} /></div>
          <div className="adm-row" style={{ alignItems: 'start' }}>
            <div className="adm-field" style={{ flex: 1, minWidth: 180 }}><label htmlFor="nc">دسته‌بندی</label><select id="nc" value={d.category} onChange={(e) => f('category', e.target.value)}>{NEWS_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
            <div className="adm-field" style={{ flex: 1, minWidth: 180 }}><label htmlFor="ns">منبع خبر</label><input id="ns" value={d.source} maxLength={80} onChange={(e) => f('source', e.target.value)} /></div>
            <div className="adm-field" style={{ flex: 1, minWidth: 180 }}><label htmlFor="nl">نشانی (لاتین، اختیاری)</label><input id="nl" dir="ltr" value={d.slug} maxLength={60} placeholder="auto" onChange={(e) => f('slug', e.target.value)} /></div>
          </div>
          <div className="adm-field"><label htmlFor="nm">خلاصه (حداکثر ۳۰۰ نویسه)</label><input id="nm" value={d.summary} maxLength={300} onChange={(e) => f('summary', e.target.value)} /></div>
          <div className="adm-field"><label htmlFor="nb">متن خبر (بندها را با یک خط خالی جدا کنید؛ HTML پذیرفته نمی‌شود)</label><textarea id="nb" value={d.body} onChange={(e) => f('body', e.target.value)} /></div>
          <div className="adm-row"><Toggle checked={d.published} label="منتشر شود" disabled={!canPublish} onChange={(v) => f('published', v)} /><span>{d.published ? 'منتشر می‌شود' : 'پیش‌نویس'}</span>{!canPublish && <span className="note">نقش شما اجازه‌ی انتشار ندارد.</span>}</div>
          <div className="adm-row" style={{ marginTop: 14 }}><button className="adm-btn pri" type="button" disabled={busy} onClick={save}>ذخیره</button><button className="adm-btn" type="button" disabled={busy} onClick={() => setD(null)}>انصراف</button></div>
        </div>
      )}
      <div className="adm-card" style={{ overflowX: 'auto' }}>
        <h2>همه‌ی خبرها <span className="adm-pill">{list.length}</span></h2>
        {list.length === 0 ? <p className="note">هنوز خبری ثبت نشده است.</p> : (
          <table className="adm-table"><thead><tr><th>تیتر</th><th>دسته</th><th>وضعیت</th><th>تاریخ</th><th /></tr></thead><tbody>
            {list.map((a) => (
              <tr key={a.id}><td><b>{a.title}</b><div className="note num" style={{ margin: 0 }}>/news/{a.slug}</div></td><td>{a.category}</td>
                <td><span className="adm-pill"><span className={`adm-dot ${a.published ? 'ok' : ''}`} />{a.published ? 'منتشرشده' : 'پیش‌نویس'}</span></td><td>{fa(a.publishedAt)}</td>
                <td><div className="adm-row"><button className="adm-btn" type="button" onClick={() => setD({ id: a.id, title: a.title, slug: a.slug, summary: a.summary, body: a.body, category: a.category, source: a.source, published: a.published })}>ویرایش</button>{canPublish && <button className="adm-btn danger" type="button" onClick={() => del(a)}>حذف</button>}</div></td></tr>
            ))}
          </tbody></table>
        )}
      </div>
    </div>
  );
}
