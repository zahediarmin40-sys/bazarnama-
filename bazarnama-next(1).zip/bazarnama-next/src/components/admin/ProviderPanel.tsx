'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Toggle } from './Toggle';

export interface ProviderRow { id: string; label: string; note?: string; configured: boolean; enabled: boolean; lastOkAt?: number; lastError?: string; consecutiveFailures: number; accepted: number; rejected: number }
const when = (t?: number) => (t ? new Date(t).toLocaleString('fa-IR', { timeZone: 'Asia/Tehran' }) : '—');

export function ProviderPanel({ rows, canManage, hasDemo, outage }: { rows: ProviderRow[]; canManage: boolean; hasDemo: boolean; outage: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const post = async (body: unknown) => {
    setBusy(true); setMsg(null);
    try { const r = await fetch('/api/admin/providers', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); if (!r.ok) setMsg({ ok: false, text: `خطا (${r.status})` }); else { setMsg({ ok: true, text: 'ذخیره شد' }); router.refresh(); } }
    finally { setBusy(false); }
  };
  return (
    <>
      {msg && <div className={`adm-msg ${msg.ok ? 'ok' : 'err'}`} role="status">{msg.text}</div>}
      {rows.length === 0 ? <div className="adm-card"><b>هیچ ارائه‌دهنده‌ای فعال نیست.</b><p className="note">PRICE_MODE و PROVIDERS_ENABLED را در تنظیمات سرور بگذارید (مثلاً <span className="num">PROVIDERS_ENABLED=nerkhara</span>).</p></div> : (
        <div className="adm-card" style={{ overflowX: 'auto' }}>
          <table className="adm-table"><thead><tr><th>فعال</th><th>ارائه‌دهنده</th><th>وضعیت</th><th>آخرین دریافت موفق</th><th>خطای اخیر</th><th>پذیرفته / ردشده</th></tr></thead><tbody>
            {rows.map((h) => (
              <tr key={h.id}>
                <td><Toggle checked={h.enabled} label={`فعال‌سازی ${h.label}`} disabled={!canManage || busy} onChange={(v) => post({ id: h.id, enabled: v })} /></td>
                <td><b>{h.label}</b><div className="note" style={{ margin: 0 }}>{h.note}</div></td>
                <td><span className="adm-pill"><span className={`adm-dot ${!h.enabled ? '' : !h.configured || h.consecutiveFailures > 0 ? 'bad' : h.lastOkAt ? 'ok' : 'warn'}`} />{!h.enabled ? 'غیرفعال' : !h.configured ? 'پیکربندی نشده' : h.consecutiveFailures > 0 ? 'خطا' : h.lastOkAt ? 'سالم' : 'در انتظار'}</span></td>
                <td>{when(h.lastOkAt)}</td><td>{h.lastError ? `${h.lastError} (${h.consecutiveFailures}×)` : '—'}</td><td className="num">{h.accepted} / {h.rejected}</td>
              </tr>
            ))}
          </tbody></table>
        </div>
      )}
      {canManage && hasDemo && (
        <div className="adm-card" style={{ marginTop: 16 }}>
          <h2>آزمون قطعی فید (فقط حالت نمایشی)</h2>
          <p className="note" style={{ marginTop: 0 }}>فید را ساکت می‌کند تا ببینید ردیف‌ها به «با تأخیر» و «قدیمی» می‌روند.</p>
          <div className="adm-row"><button className="adm-btn" type="button" disabled={busy || outage} onClick={() => post({ id: 'demo', outage: true })}>شبیه‌سازی قطعی</button><button className="adm-btn" type="button" disabled={busy || !outage} onClick={() => post({ id: 'demo', outage: false })}>پایان قطعی</button>{outage && <span className="adm-pill"><span className="adm-dot bad" />فید قطع است</span>}</div>
        </div>
      )}
    </>
  );
}
