const P: Record<string, string> = {
  dash: 'M3 13h8V3H3zm10 8h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z',
  site: 'M4 5h16v4H4zM4 11h10v8H4zM16 11h4v8h-4z',
  news: 'M5 4h12a2 2 0 0 1 2 2v13H7a2 2 0 0 1-2-2zM9 8h6M9 12h6M9 16h4',
  feed: 'M4 12h4l3-8 4 16 3-8h2',
  audit: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4',
  out: 'M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
};
export function Icon({ name, size = 20 }: { name: keyof typeof P; size?: number }) {
  return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={P[name]} /></svg>);
}
