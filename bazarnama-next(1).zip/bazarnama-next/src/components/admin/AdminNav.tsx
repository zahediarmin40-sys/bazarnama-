'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Icon } from './icons';

const ITEMS = [
  ['/admin', 'داشبورد', 'dash'], ['/admin/site', 'ظاهر و محتوای سایت', 'site'], ['/admin/ads', 'مدیریت تبلیغات', 'news'], ['/admin/news', 'اخبار', 'news'],
  ['/admin/providers', 'منابع قیمت', 'feed'], ['/admin/audit', 'گزارش رویدادها', 'audit'],
] as const;

export function AdminNav() {
  const p = usePathname();
  return (
    <nav className="adm-nav" aria-label="مدیریت">
      {ITEMS.map(([h, l, i]) => (<Link key={h} href={h} aria-current={p === h ? 'page' : undefined}><Icon name={i} />{l}</Link>))}
      <Link href="/" target="_blank"><Icon name="eye" />مشاهده سایت</Link>
    </nav>
  );
}
