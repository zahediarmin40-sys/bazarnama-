'use client';
import { useEffect, useState } from 'react';
import { fmt } from '@/core/format';

export interface Stats { mode: string; records: number; sse: number; bucketSec: number; activity: number[]; feedsOk: number; feedsTotal: number; articles: number; time: number }
const MODE: Record<string, string> = { none: 'متصل نیست', demo: 'نمایشی', live: 'منبع واقعی' };

export function StatsPanel({ initial }: { initial: Stats }) {
  const [s, setS] = useState(initial);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let off = false;
    const tick = async () => { try { const r = await fetch('/api/admin/stats', { cache: 'no-store' }); if (r.ok && !off) { setS((await r.json()) as Stats); setErr(false); } else if (!off) setErr(true); } catch { if (!off) setErr(true); } };
    const t = setInterval(tick, 5000);
    return () => { off = true; clearInterval(t); };
  }, []);
  const ok = s.feedsTotal > 0 && s.feedsOk === s.feedsTotal;
  const total = s.activity.reduce((a, b) => a + b, 0);
  return <>
    <div className="adm-grid adm-kpis">
      <div className="adm-card adm-kpi"><div className="l">حالت قیمت‌ها</div><div className="v" style={{ fontSize: '1.4rem' }}>{MODE[s.mode] ?? s.mode}</div><div className="s">PRICE_MODE</div></div>
      <div className="adm-card adm-kpi"><div className="l">قیمت‌های ذخیره‌شده</div><div className="v">{fmt(s.records)}</div><div className="s">دارایی با قیمت معتبر</div></div>
      <div className="adm-card adm-kpi"><div className="l">بازدیدکننده‌ی زنده</div><div className="v">{fmt(s.sse)}</div><div className="s">اتصال فعال</div></div>
      <div className="adm-card adm-kpi"><div className="l">منابع سالم</div><div className="v">{fmt(s.feedsOk)} / {fmt(s.feedsTotal)}</div><div className="s"><span className={`adm-dot ${s.feedsTotal === 0 ? '' : ok ? 'ok' : 'bad'}`} /> {s.feedsTotal === 0 ? 'منبعی فعال نیست' : ok ? 'همه‌چیز عادی' : 'نیاز به بررسی'}</div></div>
    </div>
    <div className="adm-card" style={{ marginTop: 16 }}>
      <h2>خلاصه فعالیت سامانه <span className="adm-pill">{fmt(total)} رکورد پذیرفته‌شده در {fmt(Math.round((s.bucketSec * s.activity.length) / 60))} دقیقه‌ی اخیر</span></h2>
      <div className="adm-row" style={{ marginTop: 12 }}><span className="note">آخرین بررسی پنل: {new Date(s.time).toLocaleTimeString('fa-IR')}</span><span className={`adm-pill ${err ? 'bad' : 'ok'}`}>{err ? 'اتصال به آمار قطع است؛ تلاش دوباره…' : 'به‌روزرسانی خودکار هر ۵ ثانیه'}</span></div>
      <p className="note">تعداد رکوردها بر اساس پاسخ‌های معتبر منبع محاسبه می‌شود؛ بازه‌های بدون داده به‌عنوان قیمت جدید ثبت نمی‌شوند.</p>
    </div>
  </>;
}
