'use client';
import { useState } from 'react';
import type { SiteAd, SiteConfig } from '@/server/config/types';
import { Toggle } from './Toggle';

const emptyAd = (): SiteAd => ({ id: crypto.randomUUID(), title: '', description: '', href: '', imageUrl: '', placement: 'home', enabled: false, startsAt: null, endsAt: null });
const dateValue = (value: number | null) => value === null ? '' : new Date(value).toISOString().slice(0, 16);
export function AdsManager({ initial, canEdit }: { initial: SiteConfig; canEdit: boolean }) {
  const [config, setConfig] = useState(initial);
  const [draft, setDraft] = useState<SiteAd | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [showExpired, setShowExpired] = useState(false);
  const now = Date.now();
  const visible = config.ads.filter((ad) => showExpired || ad.endsAt === null || ad.endsAt >= now);

  function patch(p: Partial<SiteAd>) { setDraft((x) => x ? { ...x, ...p } : x); }
  function saveDraft() {
    if (!draft) return;
    if (!draft.title.trim() || !draft.href.trim()) { setMessage({ ok: false, text: 'عنوان و پیوند تبلیغ الزامی است.' }); return; }
    setConfig((c) => ({ ...c, ads: c.ads.some((a) => a.id === draft.id) ? c.ads.map((a) => a.id === draft.id ? draft : a) : [...c.ads, draft] }));
    setDraft(null); setMessage({ ok: true, text: 'پیش‌نویس تبلیغ در فرم آماده ذخیره شد؛ برای انتشار، «ذخیره و انتشار» را بزنید.' });
  }
  async function publish() {
    setBusy(true); setMessage(null);
    try {
      const response = await fetch('/api/admin/config', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(config) });
      const result = await response.json() as { config?: SiteConfig; message?: string };
      if (!response.ok || !result.config) throw new Error(result.message || `خطا (${response.status})`);
      setConfig(result.config); setMessage({ ok: true, text: 'تبلیغات ذخیره و منتشر شدند.' });
    } catch (error) { setMessage({ ok: false, text: error instanceof Error ? error.message : 'ذخیره تبلیغات ناموفق بود.' }); }
    finally { setBusy(false); }
  }
  function remove(id: string) { if (!confirm('این تبلیغ حذف شود؟')) return; setConfig((c) => ({ ...c, ads: c.ads.filter((a) => a.id !== id) })); }
  const placeLabel = (p: SiteAd['placement']) => p === 'top' ? 'بالای سایت' : p === 'footer' ? 'پایین صفحه' : 'صفحه اصلی';

  return <div className="adm-grid ads-admin">
    {message && <div className={`adm-msg ${message.ok ? 'ok' : 'err'}`} role="status">{message.text}</div>}
    <div className="adm-card">
      <div className="adm-row ads-title-row"><h2>جایگاه‌های تبلیغاتی</h2><button type="button" className="adm-btn pri" disabled={!canEdit} onClick={() => setDraft(emptyAd())}>＋ افزودن تبلیغ</button></div>
      <p className="note">تبلیغ‌ها بدون کد اجرایی یا اسکریپت نمایش داده می‌شوند. فقط عنوان، متن، لینک و تصویر HTTPS یا تصویر داخلی سایت پذیرفته می‌شود.</p>
      <div className="adm-row" style={{ marginTop: 12 }}><Toggle checked={showExpired} label="نمایش تبلیغ‌های منقضی‌شده" onChange={setShowExpired}/><span className="note">{config.ads.length} تبلیغ ثبت‌شده</span></div>
      <div className="ads-list">
        {visible.length ? visible.map((ad) => <div className="ads-item" key={ad.id}>
          <div className="ads-item-main">{ad.imageUrl ? <span className="ads-thumb" style={{ backgroundImage: `url("${ad.imageUrl.replaceAll('"', '')}")` }}/> : <span className="ads-thumb ads-no-thumb">▧</span>}<span><b>{ad.title}</b><small>{placeLabel(ad.placement)} · {ad.enabled ? 'فعال' : 'غیرفعال'}</small>{ad.description && <small>{ad.description}</small>}</span></div>
          <div className="ads-item-actions"><button type="button" className="adm-mini" disabled={!canEdit} onClick={() => setDraft({ ...ad })}>ویرایش</button><button type="button" className="adm-mini" disabled={!canEdit} onClick={() => setConfig((c) => ({ ...c, ads: c.ads.map((a) => a.id === ad.id ? { ...a, enabled: !a.enabled } : a) }))}>{ad.enabled ? 'خاموش‌کردن' : 'فعال‌سازی'}</button><button type="button" className="adm-mini danger" disabled={!canEdit} onClick={() => remove(ad.id)}>حذف</button></div>
        </div>) : <div className="empty">هنوز تبلیغی ثبت نشده است.</div>}
      </div>
    </div>
    {draft && <div className="adm-card">
      <h2>{config.ads.some((a) => a.id === draft.id) ? 'ویرایش تبلیغ' : 'تبلیغ جدید'}</h2>
      <div className="ads-form-grid">
        <div className="adm-field"><label>عنوان تبلیغ</label><input maxLength={100} value={draft.title} disabled={!canEdit} onChange={(e) => patch({ title: e.target.value })}/></div>
        <div className="adm-field"><label>متن کوتاه</label><input maxLength={220} value={draft.description} disabled={!canEdit} onChange={(e) => patch({ description: e.target.value })}/></div>
        <div className="adm-field"><label>پیوند مقصد (با / یا https://)</label><input dir="ltr" value={draft.href} disabled={!canEdit} onChange={(e) => patch({ href: e.target.value })}/></div>
        <div className="adm-field"><label>آدرس تصویر (اختیاری، HTTPS یا مسیر داخلی)</label><input dir="ltr" value={draft.imageUrl} disabled={!canEdit} onChange={(e) => patch({ imageUrl: e.target.value })}/></div>
        <div className="adm-field"><label>جایگاه نمایش</label><select value={draft.placement} disabled={!canEdit} onChange={(e) => patch({ placement: e.target.value as SiteAd['placement'] })}><option value="top">بالای سایت</option><option value="home">صفحه اصلی</option><option value="footer">پایین صفحه</option></select></div>
        <div className="adm-field"><label>وضعیت</label><Toggle checked={draft.enabled} label={draft.enabled ? 'فعال' : 'غیرفعال'} disabled={!canEdit} onChange={(enabled) => patch({ enabled })}/></div>
        <div className="adm-field"><label>شروع نمایش (اختیاری)</label><input type="datetime-local" value={dateValue(draft.startsAt)} disabled={!canEdit} onChange={(e) => patch({ startsAt: e.target.value ? Date.parse(e.target.value) : null })}/></div>
        <div className="adm-field"><label>پایان نمایش (اختیاری)</label><input type="datetime-local" value={dateValue(draft.endsAt)} disabled={!canEdit} onChange={(e) => patch({ endsAt: e.target.value ? Date.parse(e.target.value) : null })}/></div>
      </div>
      <div className="adm-row" style={{ marginTop: 14 }}><button type="button" className="adm-btn pri" disabled={!canEdit} onClick={saveDraft}>افزودن به فهرست</button><button type="button" className="adm-btn" onClick={() => setDraft(null)}>انصراف</button></div>
    </div>}
    {canEdit && <div className="adm-row" style={{ position: 'sticky', bottom: 14, background: 'var(--sf)', border: '1px solid var(--line)', borderRadius: 14, padding: 12, boxShadow: '0 8px 30px rgba(0,0,0,.14)' }}><button type="button" className="adm-btn pri" disabled={busy} onClick={publish}>{busy ? 'در حال ذخیره…' : 'ذخیره و انتشار تبلیغات'}</button></div>}
  </div>;
}
