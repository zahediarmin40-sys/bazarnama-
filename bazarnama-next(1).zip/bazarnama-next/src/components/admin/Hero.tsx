import type { ReactNode } from 'react';
export function Hero({ title, text, children }: { title: string; text?: string; children?: ReactNode }) {
  return (
    <header className="adm-hero">
      <h1>{title}</h1>{text && <p>{text}</p>}{children}
      <svg className="motif" viewBox="0 0 800 90" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 70 L60 55 L110 62 L170 38 L230 48 L290 22 L350 36 L410 18 L470 40 L530 28 L590 46 L650 20 L720 34 L800 12" fill="none" stroke="#D9AA45" strokeWidth="2.4" strokeLinejoin="round" />
        <path d="M0 80 L70 70 L130 74 L190 58 L250 64 L310 44 L370 54 L430 40 L490 58 L550 48 L610 62 L670 40 L740 52 L800 36" fill="none" stroke="#6B7C95" strokeWidth="1.4" opacity=".6" />
      </svg>
    </header>
  );
}
