import Link from 'next/link';
import type { ReactNode } from 'react';
export function Section({ title, href, children }: { title: string; href?: string; children: ReactNode }) {
  return (<section className="blk"><div className="hd"><h2>{title}</h2>{href && <Link className="all" href={href}>مشاهده همه</Link>}</div>{children}</section>);
}
