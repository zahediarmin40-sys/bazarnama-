'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMemo, useRef, useState } from 'react';
import { matches, normText } from '@/core/search';
import { ASSETS } from '@/domain/catalog';
import { MARKET_LABEL } from '@/domain/sections';

const GROUPS: ReadonlyArray<[string, (c: string, m: string) => boolean]> = [
  ['قیمت‌ها', (c) => c === 'gold' || c === 'coin' || c === 'world'],
  ['ارزها', (c, m) => c === 'fx' && m === 'free'],
];

export function SearchBox({ availableIds }: { availableIds: readonly string[] }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [recent, setRecent] = useState<string[]>([]); // memory only: no personal data is stored
  const router = useRouter();
  const box = useRef<HTMLDivElement>(null);
  const remember = (s: string) => { const t = s.trim(); if (t) setRecent((r) => [t, ...r.filter((x) => x !== t)].slice(0, 5)); };

  const available = useMemo(() => new Set(availableIds), [availableIds]);
  const results = useMemo(() => GROUPS.map(([title, fn]) => ({ title, items: ASSETS.filter((a) => available.has(a.id) && fn(a.category, a.marketType) && matches(a, q)).slice(0, 6) })).filter((g) => g.items.length), [q, available]);

  return (
    <div className="sw" role="search" ref={box} onBlur={(e) => { if (!box.current?.contains(e.relatedTarget as Node)) setOpen(false); }}>
      <input type="search" value={q} autoComplete="off" aria-label="جستجو" aria-expanded={open} placeholder="جستجوی قیمت، ارز یا محصول (مثلاً دلار، ۱۸ عیار، امامی)"
        onFocus={() => setOpen(true)} onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={(e) => {
          if (e.key === 'Escape') setOpen(false);
          if (e.key === 'Enter') { const first = results[0]?.items[0]; if (first) { remember(q); setOpen(false); router.push(`/asset/${first.id}`); } }
        }} />
      {open && (
        <div className="sr">
          {!normText(q) ? (
            recent.length ? (<><div className="rc"><b style={{ fontSize: '.8rem', color: 'var(--mute)' }}>جستجوهای اخیر</b><button type="button" onClick={() => setRecent([])}>پاک‌کردن</button></div>{recent.map((r) => (<a key={r} href="#" onClick={(e) => { e.preventDefault(); setQ(r); }}>{r}</a>))}</>) : <div className="rc" style={{ color: 'var(--mute)' }}>نام طلا، سکه، ارز یا فلز را بنویسید.</div>
          ) : results.length ? results.map((g) => (
            <div key={g.title}><h4>{g.title}</h4>{g.items.map((a) => (<Link key={a.id} href={`/asset/${a.id}`} onClick={() => { remember(q); setOpen(false); }}><span>{a.name}{a.tag ? ` ${a.tag}` : ''}</span><span className="sub" style={{ color: 'var(--mute)', fontSize: '.78rem' }}>{MARKET_LABEL[a.marketType]}</span></Link>))}</div>
          )) : <div className="rc" style={{ color: 'var(--mute)' }}>نتیجه‌ای پیدا نشد. محصولات و اخبار در فاز ۲ جستجو می‌شوند.</div>}
        </div>
      )}
    </div>
  );
}
