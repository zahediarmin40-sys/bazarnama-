import type { DisplayStatus } from '@/core/types';
import { STATUS_LABEL } from '@/domain/sections';

/** Status is always text + dot, never colour alone. */
export function StatusPill({ status }: { status: DisplayStatus }) {
  return <span className={`st st-${status}`}><i aria-hidden="true" />{STATUS_LABEL[status]}</span>;
}
