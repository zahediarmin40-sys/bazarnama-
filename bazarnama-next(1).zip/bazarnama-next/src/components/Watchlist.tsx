'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getAsset } from '@/domain/catalog';

const KEY = 'bazarnama-favorites';
export function Watchlist({ availableIds }: { availableIds: readonly string[] }) {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    const sync = () => {
      try {
        const value: unknown = JSON.parse(localStorage.getItem(KEY) ?? '[]');
        setIds(Array.isArray(value) ? value.filter((id): id is string => typeof id === 'string' && availableIds.includes(id)).slice(0, 30) : []);
      } catch { setIds([]); }
    };
    sync();
    window.addEventListener('storage', sync);
    window.addEventListener('bazarnama:favorites', sync);
    return () => { window.removeEventListener('storage', sync); window.removeEventListener('bazarnama:favorites', sync); };
  }, [availableIds]);
  if (!ids.length) return null;
  return <section className="watchlist panel" aria-label="دیده‌بان قیمت‌های من">
    <div className="panel-head"><h2>★ دیده‌بان قیمت‌های من</h2><span className="market-hint">دسترسی سریع به موارد ذخیره‌شده</span></div>
    <div className="watchlist-items">{ids.map((id) => {
      const asset = getAsset(id);
      return asset ? <Link href={`/asset/${id}`} key={id}><b>{asset.name}</b><span>مشاهده قیمت ←</span></Link> : null;
    })}</div>
  </section>;
}
