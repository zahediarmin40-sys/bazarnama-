import type { SiteAd, AdPlacement } from '@/server/config/types';

export function Advertisement({ ads, placement }: { ads: SiteAd[]; placement: AdPlacement }) {
  const now = Date.now();
  const active = ads.filter((a) => a.enabled && a.placement === placement && (a.startsAt === null || a.startsAt <= now) && (a.endsAt === null || a.endsAt >= now));
  if (!active.length) return null;
  return <div className={`ad-slot ad-slot-${placement}`} aria-label="تبلیغات">
    {active.map((ad) => <a className="ad-card" key={ad.id} href={ad.href} target={ad.href.startsWith('/') ? undefined : '_blank'} rel={ad.href.startsWith('/') ? undefined : 'noopener noreferrer'}>
      {ad.imageUrl && <span className="ad-art" role="img" aria-label={ad.title} style={{ backgroundImage: `url("${ad.imageUrl.replaceAll('"', '')}")` }} />}
      <span className="ad-copy"><small>تبلیغات</small><b>{ad.title}</b>{ad.description && <span>{ad.description}</span>}</span>
      <span className="ad-go">مشاهده ←</span>
    </a>)}
  </div>;
}
