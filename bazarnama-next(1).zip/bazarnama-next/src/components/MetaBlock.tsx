import { fmt } from '@/core/format';
import type { Digits } from '@/core/format';
import type { PriceRecord } from '@/core/types';
import { METHOD_LABEL } from '@/domain/sections';
import { Num } from './Num';

/** Provenance: how the figure was made. Shown wherever a provider supplies it. */
export function MetaBlock({ record, digits }: { record: PriceRecord; digits: Digits }) {
  const m = record.meta;
  if (!m) return null;
  return (
    <>
      {m.method && <div><dt>روش تعیین قیمت</dt><dd>{METHOD_LABEL[m.method] ?? m.method}</dd></div>}
      {m.sources != null && <div><dt>تعداد منبع</dt><dd><Num>{fmt(m.sources, { digits })}</Num></dd></div>}
      {m.spreadPct != null && <div><dt>پراکندگی منابع</dt><dd><Num>{fmt(m.spreadPct, { digits, min: 2, max: 2 })}٪</Num></dd></div>}
      {m.asOf && <div><dt>مربوط به روز</dt><dd><Num>{digits === 'fa' ? m.asOf.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)] ?? d) : m.asOf}</Num></dd></div>}
    </>
  );
}
