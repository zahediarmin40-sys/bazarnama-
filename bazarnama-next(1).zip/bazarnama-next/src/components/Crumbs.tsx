import Link from 'next/link';
export function Crumbs({ trail }: { trail: ReadonlyArray<[href: string | null, label: string]> }) {
  return (
    <nav className="crumbs" aria-label="مسیر">
      <Link href="/">خانه</Link>
      {trail.map(([h, l]) => (<span key={l}> / {h ? <Link href={h}>{l}</Link> : <span>{l}</span>}</span>))}
    </nav>
  );
}
