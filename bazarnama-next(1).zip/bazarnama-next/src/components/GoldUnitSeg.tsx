'use client';
import { usePrefs } from './PrefsProvider';
const O = [['gram', 'گرم'], ['mesghal', 'مثقال'], ['kilogram', 'کیلوگرم']] as const;
export function GoldUnitSeg() {
  const { prefs, set } = usePrefs();
  return (
    <div className="ctl"><div><label>واحد وزن</label>
      <div className="seg" role="group" aria-label="واحد وزن">{O.map(([k, l]) => <button key={k} type="button" aria-pressed={prefs.goldUnit === k} onClick={() => set({ goldUnit: k })}>{l}</button>)}</div>
    </div></div>
  );
}
