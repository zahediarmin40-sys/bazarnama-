import Link from 'next/link';
import type { SiteConfig } from '@/server/config/types';

export function Announcement({ a }: { a: SiteConfig['announcement'] }) {
  if (!a.enabled || !a.text) return null;
  const inner = <>{a.text}{a.href && <span className="ann-go"> ←</span>}</>;
  return (
    <div className={`ann ann-${a.tone}`} role="status"><div className="wrap">
      {!a.href ? inner : a.href.startsWith('/') ? <Link href={a.href}>{inner}</Link> : <a href={a.href} rel="noopener noreferrer">{inner}</a>}
    </div></div>
  );
}
