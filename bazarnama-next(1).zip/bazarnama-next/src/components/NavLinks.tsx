'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const group = (p: string): string => {
  if (p === '/coins') return p;
  if (p.startsWith('/asset/')) return p.includes('coin-') ? '/coins' : p.includes('fx-') ? '/currency' : '/gold';
  if (p === '/') return '/';
  if (p.startsWith('/news/')) return '/news';
  return p;
};
const ICONS: Record<string, string> = {
  '/': 'M3 10.8 12 3l9 7.8v9.1a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  '/gold': 'm4 17 4-9h8l4 9-8 4zM8 8l2-4h4l2 4',
  '/coins': 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 4v10m-3-7h6m-6 4h6',
  '/currency': 'M4 8h14l-3-3m5 11H6l3 3',
  '/all': 'M4 5h16M4 12h16M4 19h16M8 3v4m8-4v4m-8 7v4m8-4v4',
  '/guide': 'M12 18h.01M9.5 9a2.5 2.5 0 1 1 4.5 1.7c-1.1.8-2 1.2-2 2.8M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z',
  '/news': 'M4 5h16v14H4zM7 9h10M7 12h10M7 15h6',
  '/about': 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zm0-13h.01M11 11h1v5h1',
};

export function NavLinks({ items }: { items: ReadonlyArray<{ href: string; label: string }> }) {
  const cur = group(usePathname());
  return (
    <ul>{items.map((n) => (
      <li key={n.href}>
        <Link href={n.href} aria-current={n.href === cur ? 'page' : undefined}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d={ICONS[n.href] ?? ICONS['/all']} /></svg>
          <span>{n.label}</span>
        </Link>
      </li>
    ))}</ul>
  );
}
