'use client';
import { useState } from 'react';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { MARKET_LABEL } from '@/domain/sections';
import { useLivePrices } from '@/hooks/useLivePrices';
import { copyToClipboard } from '@/lib/clipboard';
import { NotConnected } from './NotConnected';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { SpecBlock } from './SpecBlock';
import { MetaBlock } from './MetaBlock';
import { FavoriteButton } from './FavoriteButton';
import { StatusPill } from './StatusPill';
import { agoText, Change, decimals, Percent, timeText, unitText } from './view-helpers';

export function AssetView({ id, initial }: { id: string; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, mode, intervalSec, now } = useLivePrices([id], initial);
  const [toast, setToast] = useState('');
  if (mode === 'none') return <NotConnected />;
  const asset = mustAsset(id);
  const rec = records.get(id) ?? null;
  const r = toDisplay(asset, rec, prefs, now, intervalSec);
  const d = prefs.digits;
  const say = (m: string) => { setToast(m); setTimeout(() => setToast(''), 1800); };
  if (!rec || r.price === null) return <div className="panel empty"><b>این قیمت در دسترس نیست.</b><p>از منبع داده‌ای برای این دارایی دریافت نشده است.</p></div>;
  return (
    <>
      <div className="panel" style={{ padding: 16 }}>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'baseline' }}>
          <span style={{ fontSize: '2rem', fontWeight: 800, opacity: r.status === 'stale' ? 0.6 : 1 }}><Num>{fmt(r.price, { digits: d, ...decimals(r) })}</Num></span>
          <span>{unitText(r, d)}</span><StatusPill status={r.status} />
        </div>
        <div style={{ marginTop: 6 }}><Change value={r.change} row={r} digits={d} /> &nbsp; <Percent value={r.changePercent} digits={d} /></div>
        <dl className="dg" style={{ marginTop: 14 }}>
          <div><dt>نوع بازار / نرخ</dt><dd>{MARKET_LABEL[rec.marketType]}</dd></div>
          <div><dt>منبع</dt><dd>{rec.source}</dd></div>
          <div><dt>آخرین بروزرسانی</dt><dd>{timeText(rec.updatedAt, d)} <span className="sub">({agoText(rec.updatedAt, now, d)})</span></dd></div>
          <SpecBlock row={r} prefs={prefs} /><MetaBlock record={rec} digits={d} />
        </dl>
        {r.status === 'stale' && <p className="note down">این فید بروزرسانی نشده است؛ آخرین مقدار معتبر با زمان خودش نمایش داده می‌شود.</p>}
        <div className="acts">
          <button className="btn" type="button" onClick={async () => say((await copyToClipboard(`${asset.name}: ${fmt(r.price, { digits: d, ...decimals(r) })} ${unitText(r, d)} — ${MARKET_LABEL[rec.marketType]} — ${timeText(rec.updatedAt, d)}${mode === 'demo' ? ' — نمایشی' : ''}`)) ? 'کپی شد' : 'کپی انجام نشد')}>کپی قیمت</button>
          <button className="btn" type="button" onClick={async () => say((await copyToClipboard(`${location.origin}/asset/${id}`)) ? 'کپی شد' : 'کپی انجام نشد')}>کپی پیوند اشتراک‌گذاری</button>
          <FavoriteButton assetId={id} />
        </div>
      </div>
      {toast && <div className="toast" role="status">{toast}</div>}
    </>
  );
}
