'use client';
import Link from 'next/link';
import { fmt } from '@/core/format';
import { toDisplay } from '@/core/display';
import type { PricesPayload } from '@/core/types';
import { mustAsset } from '@/domain/catalog';
import { useLivePrices } from '@/hooks/useLivePrices';
import { Num } from './Num';
import { usePrefs } from './PrefsProvider';
import { StatusPill } from './StatusPill';
import { decimals, Percent, unitText } from './view-helpers';

export function Snapshot({ ids, initial }: { ids: readonly string[]; initial: PricesPayload }) {
  const { prefs } = usePrefs();
  const { records, intervalSec, now } = useLivePrices(ids, initial);
  const d = prefs.digits;
  return <div className="snap">{ids.map((id) => {
    const row = toDisplay(mustAsset(id), records.get(id) ?? null, prefs, now, intervalSec);
    const badge = row.asset.category === 'coin' ? 'سکه' : row.asset.category === 'fx' ? (row.asset.code ?? 'ارز') : id === 'gold-ounce' ? 'XAU' : row.asset.tag ?? 'Au';
    return <Link key={id} href={`/asset/${id}`}><div className="snap-name"><div className="n">{row.asset.name}</div><span className="snap-icon">{badge}</span></div><div className="p" style={row.status === 'stale' ? { opacity: .6 } : undefined}>{row.record ? <Num>{fmt(row.price, { digits: d, ...decimals(row) })}</Num> : '—'}</div><div className="u">{row.record ? unitText(row, d) : '—'}</div><div className="c"><Percent value={row.changePercent} digits={d}/><StatusPill status={row.status}/></div></Link>;
  })}</div>;
}
