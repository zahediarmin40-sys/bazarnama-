'use client';
import { useRouter } from 'next/navigation';
import { useState, type FormEvent } from 'react';

export function LoginForm() {
  const router = useRouter();
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [needCode, setNeedCode] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: fd.get('email'), password: fd.get('password'), code: fd.get('code') || undefined }) });
      if (r.ok) { router.push('/admin'); router.refresh(); return; }
      const j = (await r.json().catch(() => ({}))) as { error?: string };
      if (j.error === 'totp-required') { setNeedCode(true); setErr('کد ۶ رقمی برنامه‌ی احراز هویت را وارد کنید.'); }
      else setErr(r.status === 429 ? 'تلاش‌های زیاد؛ کمی بعد دوباره امتحان کنید.' : r.status === 503 ? 'ورود مدیران غیرفعال است (ADMIN_JWT_SECRET تنظیم نشده).' : r.status === 403 ? 'درخواست از مبدأ نامعتبر.' : 'ایمیل، گذرواژه یا کد نادرست است.');
    } finally { setBusy(false); }
  }
  return (
    <form className="f" onSubmit={submit} noValidate>
      <div className="adm-field"><label htmlFor="em">ایمیل مدیر</label><input id="em" name="email" type="email" dir="ltr" autoComplete="username" required /></div>
      <div className="adm-field"><label htmlFor="pw">گذرواژه</label><input id="pw" name="password" type="password" dir="ltr" autoComplete="current-password" required /></div>
      {needCode && <div className="adm-field"><label htmlFor="cd">کد دومرحله‌ای</label><input id="cd" name="code" inputMode="numeric" pattern="\d{6}" maxLength={6} dir="ltr" autoComplete="one-time-code" autoFocus /></div>}
      {err && <div className="adm-msg err" role="alert">{err}</div>}
      <button className="adm-btn pri" type="submit" disabled={busy} style={{ justifyContent: 'center', width: '100%' }}>{busy ? 'در حال ورود…' : 'ورود به پنل'}</button>
    </form>
  );
}
