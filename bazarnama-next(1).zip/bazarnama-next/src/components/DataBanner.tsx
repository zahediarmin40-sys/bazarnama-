import type { PricesMode } from '@/core/types';
export function DataBanner({ mode }: { mode: PricesMode; hasData?: boolean }) {
  if (mode === 'demo') return <div className="banner"><div className="wrap"><b>حالت نمایشی:</b> اعداد ساختگی‌اند و قیمت واقعی بازار نیستند.</div></div>;
  return null;
}
