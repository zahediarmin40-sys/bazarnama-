import type { ReactNode } from 'react';
export const Num = ({ children }: { children: ReactNode }) => <span className="num">{children}</span>;
