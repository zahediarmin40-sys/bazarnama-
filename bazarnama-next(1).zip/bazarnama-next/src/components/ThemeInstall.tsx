'use client';
import { useEffect, useState } from 'react';

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };
export function ThemeToggle() {
  const [dark, setDark] = useState(true);
  useEffect(() => {
    const saved = localStorage.getItem('bazarnama-theme');
    const next = saved ? saved === 'dark' : true;
    document.documentElement.dataset.theme = next ? 'dark' : 'light';
    setDark(next);
  }, []);
  function toggle() {
    const next = !dark;
    document.documentElement.dataset.theme = next ? 'dark' : 'light';
    localStorage.setItem('bazarnama-theme', next ? 'dark' : 'light');
    setDark(next);
  }
  return <button className="icon-action" type="button" onClick={toggle} aria-label={dark ? 'فعال‌کردن پوسته روشن' : 'فعال‌کردن پوسته تاریک'} title={dark ? 'پوسته روشن' : 'پوسته تاریک'}>{dark ? '☾' : '☀'}</button>;
}
export function InstallButton() {
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [done, setDone] = useState(false);
  useEffect(() => {
    const handler = (event: Event) => { event.preventDefault(); setPrompt(event as InstallPrompt); };
    window.addEventListener('beforeinstallprompt', handler);
    const installed = () => setDone(true);
    window.addEventListener('appinstalled', installed);
    return () => { window.removeEventListener('beforeinstallprompt', handler); window.removeEventListener('appinstalled', installed); };
  }, []);
  async function install() {
    if (!prompt) {
      alert('برای افزودن بازارنما به صفحه اصلی، از منوی مرورگر گزینه «افزودن به صفحه اصلی» را انتخاب کنید.');
      return;
    }
    await prompt.prompt();
    const result = await prompt.userChoice;
    if (result.outcome === 'accepted') setDone(true);
    setPrompt(null);
  }
  return <button className="install-action" type="button" onClick={install} disabled={done}>{done ? '✓ نصب شد' : '⬇ دانلود اپلیکیشن'}</button>;
}
