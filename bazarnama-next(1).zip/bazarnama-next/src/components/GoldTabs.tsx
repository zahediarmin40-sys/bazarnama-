import Link from 'next/link';
export function GoldTabs({ current }: { current: 'gold' | 'coins' }) {
  const tabs: ReadonlyArray<['gold' | 'coins', string]> = [['gold', 'طلا و عیارها'], ['coins', 'انواع سکه']];
  return <div className="tabs" role="navigation" aria-label="بخش‌های طلا و سکه">{tabs.map(([key, label]) => <Link key={key} href={`/${key}`} aria-current={key === current ? 'page' : undefined}>{label}</Link>)}</div>;
}
