import { fmt } from '@/core/format';
import type { DisplayPrefs, DisplayRow } from '@/core/display';
import type { Digits } from '@/core/format';
import { Num } from './Num';

/** Descriptive coin reference details only; no intrinsic-value calculator is exposed. */
export function SpecBlock({ row, prefs }: { row: DisplayRow; prefs: DisplayPrefs & { digits: Digits } }) {
  const spec = row.asset.spec;
  if (!spec) return null;
  const d = prefs.digits;
  return <><div><dt>وزن مرجع</dt><dd><Num>{fmt(spec.weightG, { digits: d, max: 5 })}</Num> گرم</dd></div><div><dt>عیار مرجع</dt><dd><Num>{fmt(spec.purity, { digits: d })}</Num></dd></div><div><dt>طلای خالص مرجع</dt><dd><Num>{fmt(spec.fineG, { digits: d, max: 4 })}</Num> گرم</dd></div></>;
}
