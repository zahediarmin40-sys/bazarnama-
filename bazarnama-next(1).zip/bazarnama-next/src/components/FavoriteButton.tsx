'use client';
import { useEffect, useState } from 'react';

const KEY = 'bazarnama-favorites';
function read(): string[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    return Array.isArray(value) ? value.filter((x): x is string => typeof x === 'string').slice(0, 30) : [];
  } catch { return []; }
}
export function FavoriteButton({ assetId }: { assetId: string }) {
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    const sync = () => setSaved(read().includes(assetId));
    sync();
    window.addEventListener('storage', sync);
    window.addEventListener('bazarnama:favorites', sync);
    return () => { window.removeEventListener('storage', sync); window.removeEventListener('bazarnama:favorites', sync); };
  }, [assetId]);
  function toggle() {
    const current = read();
    const next = current.includes(assetId) ? current.filter((x) => x !== assetId) : [...current, assetId].slice(-30);
    localStorage.setItem(KEY, JSON.stringify(next));
    setSaved(next.includes(assetId));
    window.dispatchEvent(new Event('bazarnama:favorites'));
  }
  return <button className={`btn favorite-toggle ${saved ? 'is-saved' : ''}`} type="button" aria-pressed={saved} onClick={toggle}>{saved ? '★ در دیده‌بان من' : '☆ افزودن به دیده‌بان'}</button>;
}
