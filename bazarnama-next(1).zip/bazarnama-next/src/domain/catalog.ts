import type { Asset } from '../core/types.ts';

/** Static catalog: names, units, specs. It contains NO prices. Demo seeds live in server/providers/demo.ts. */
const gold: Asset[] = [
  ...([[24, '۲۴ عیار'], [22, '۲۲ عیار'], [21, '۲۱ عیار'], [18, '۱۸ عیار'], [17, '۱۷ عیار'], [14, '۱۴ عیار']] as const).map(([k, l]) => ({
    id: `gold-${k}`, category: 'gold' as const, group: 'gold' as const, name: `طلای ${l}`, tag: `${k}K`, purity: k, unit: 'gram' as const, currency: 'IRT' as const, marketType: 'free-local' as const,
    aliases: ['طلا', 'gold', `طلا${k}`, `${k}عیار`, `${k}k`, 'گرم طلا'],
  })),
  { id: 'gold-melt', category: 'gold', group: 'gold', name: 'طلای آب‌شده', tag: 'آبشده', purity: 18, unit: 'gram', currency: 'IRT', marketType: 'free-local', aliases: ['آبشده', 'طلای آب شده', 'مظنه آبشده', 'melted gold'] },
];

const coinDefs: ReadonlyArray<[string, string, number, readonly string[]]> = [
  ['emami', 'سکه امامی (طرح جدید)', 8.133, ['تمام سکه', 'امامی', 'emami', 'سکه']],
  ['old', 'تمام سکه (طرح قدیم)', 8.133, ['تمام سکه', 'طرح قدیم', 'سکه']],
  ['half', 'نیم سکه', 4.0665, ['نیم', 'نیمسکه', 'سکه']],
  ['quarter', 'ربع سکه', 2.03325, ['ربع', 'ربعسکه', 'سکه']],
  ['gram', 'سکه گرمی', 1, ['گرمی', 'سکه']],
];
const coins: Asset[] = coinDefs.map(([k, name, w, aliases]) => ({
  id: `coin-${k}`, category: 'coin', group: 'coin', name, unit: 'piece', currency: 'IRT', marketType: 'free-local', aliases,
  spec: { weightG: w, purity: 900, fineG: (w * 900) / 1000 },
}));

export const FX_CURRENCIES: ReadonlyArray<[string, string, readonly string[]]> = [
  ['USD', 'دلار آمریکا', ['dollar', 'دلار', 'usd', '$']], ['EUR', 'یورو', ['euro', 'یورو']], ['GBP', 'پوند انگلیس', ['pound', 'پوند', 'gbp']],
  ['AED', 'درهم امارات', ['dirham', 'درهم', 'aed']], ['TRY', 'لیر ترکیه', ['lira', 'لیر', 'try']], ['CAD', 'دلار کانادا', ['cad']],
  ['AUD', 'دلار استرالیا', ['aud']], ['CHF', 'فرانک سوئیس', ['franc', 'فرانک', 'chf']], ['JPY', 'ین ژاپن', ['yen', 'ین', 'jpy']], ['CNY', 'یوان چین', ['yuan', 'یوان', 'cny']],
];
const fx: Asset[] = FX_CURRENCIES.flatMap(([code, name, aliases]) => [
  { id: `fx-${code.toLowerCase()}-free`, category: 'fx', group: code === 'USD' ? 'usd-free' : 'fx-free', name, code, fxName: name, unit: 'fx', currency: 'IRT', marketType: 'free', aliases } as Asset,
  { id: `fx-${code.toLowerCase()}-ex`, category: 'fx', group: 'fx-exchange', name, code, fxName: name, unit: 'fx', currency: 'IRT', marketType: 'exchange', aliases } as Asset,
]);

const world: Asset[] = [{
  id: 'gold-ounce', category: 'world', group: 'world-metals', name: 'اونس جهانی طلا', unit: 'ounce', currency: 'USD', marketType: 'world', aliases: ['gold ounce', 'xau', 'اونس طلا', 'اونس'],
}];

export const ASSETS: readonly Asset[] = [...gold, ...coins, ...fx, ...world];
const index = new Map(ASSETS.map((a) => [a.id, a]));
export const getAsset = (id: string): Asset | undefined => index.get(id);
export const mustAsset = (id: string): Asset => { const a = index.get(id); if (!a) throw new Error(`unknown asset ${id}`); return a; };

export const GOLD_IDS = gold.map((a) => a.id);
export const COIN_IDS = coins.map((a) => a.id);
export const METAL_IDS = world.map((a) => a.id);
export const fxIds = (type: 'free' | 'exchange'): string[] => FX_CURRENCIES.map(([c]) => `fx-${c.toLowerCase()}-${type === 'free' ? 'free' : 'ex'}`);
export const SNAPSHOT_IDS = ['gold-18', 'coin-emami', 'fx-usd-free', 'fx-eur-free', 'gold-24'];
