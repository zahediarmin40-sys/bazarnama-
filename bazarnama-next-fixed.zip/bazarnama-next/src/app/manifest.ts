import type { MetadataRoute } from 'next';
export default function manifest(): MetadataRoute.Manifest {
  return { name: 'بازارنما | قیمت زنده طلا و دلار', short_name: 'بازارنما', description: 'مرجع قیمت زنده طلا، سکه و ارز', start_url: '/', display: 'standalone', background_color: '#061020', theme_color: '#071225', lang: 'fa', dir: 'rtl', icons: [{ src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }] };
}
